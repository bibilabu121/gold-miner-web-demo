"""
Shop screen: Shopkeeper character, item purchasing (Dynamite, Strength Drink, Lucky Clover, etc.),
and progression to next level with clean UI consistency and Unicode fonts.
Rendered on 1280x720 Virtual Canvas with Unicode font support.
"""
import random
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER, COLOR_PANEL_BG,
    COLOR_PANEL_BORDER, GameStates, get_font
)
from sound_manager import SoundManager

class ShopItem:
    """Represents a purchasable item in the shop."""
    def __init__(self, key: str, name: str, description: str, price: int, icon_type: str):
        self.key = key
        self.name = name
        self.description = description
        self.price = price
        self.icon_type = icon_type
        self.is_purchased = False

class ShopScreen:
    """Manages the between-level Shop interface."""
    def __init__(self):
        self.font_title = get_font(42, bold=True)
        self.font_item_name = get_font(21, bold=True)
        self.font_desc = get_font(16)
        self.font_btn = get_font(22, bold=True)
        
        self.available_items = []
        self.next_level_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 170, 615, 340, 58)
        self.item_buy_rects = []
        self.sound = SoundManager.get_instance()

    def generate_shop_inventory(self, game_state):
        """Prepares a fresh random catalog of 3-4 shop items."""
        all_catalog = [
            ("dynamite", "Thuốc Nổ (Dynamite)", "+1 Quả bom dự trữ (Chuột phải để ném bom hủy vật nặng)", random.randint(120, 220), "dynamite"),
            ("strength_drink", "Nước Tăng Lực (Strength Drink)", "Lưu vào HUD, bấm phím R để kích hoạt kéo siêu tốc!", random.randint(260, 420), "drink"),
            ("lucky_clover", "Cỏ 4 Lá (Lucky Clover)", "Tăng may mắn & phần thưởng lớn từ túi bí ẩn", random.randint(110, 190), "clover"),
            ("diamond_polish", "Đánh Bóng Kim Cương", "Tăng thêm +$150 cho mỗi viên kim cương nhặt được", random.randint(180, 280), "polish"),
            ("rock_book", "Sách Sưu Tập Đá", "Tăng giá trị của các tảng đá lên gấp 3 lần (x3)", random.randint(130, 240), "book"),
        ]
        
        # Select 3 or 4 random items
        sample_count = min(4, len(all_catalog))
        chosen = random.sample(all_catalog, sample_count)
        self.available_items = [ShopItem(k, n, d, p, ic) for k, n, d, p, ic in chosen]
        self._calculate_rects()

    def _calculate_rects(self):
        """Pre-calculates UI bounds for buy buttons."""
        self.item_buy_rects.clear()
        start_y = 175
        item_h = 92
        for i in range(len(self.available_items)):
            y = start_y + i * (item_h + 14)
            btn_rect = pygame.Rect(VIRTUAL_WIDTH - 290, y + 22, 170, 48)
            self.item_buy_rects.append(btn_rect)

    def handle_event(self, event, game_state) -> str:
        """Processes shop purchases and next level navigation."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                self.sound.play('click')
                game_state.next_level()
                return GameStates.PLAYING

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos

            # Check Buy Item Clicks
            for idx, btn_rect in enumerate(self.item_buy_rects):
                if idx < len(self.available_items) and btn_rect.collidepoint(mouse_pos):
                    item = self.available_items[idx]
                    if not item.is_purchased and game_state.total_money >= item.price:
                        # Purchase transaction
                        game_state.spend_money(item.price)
                        item.is_purchased = True
                        self._apply_purchase(item.key, game_state)
                        self.sound.play('shop_buy')
                        return GameStates.SHOP

            # Check Next Level Click
            if self.next_level_btn.collidepoint(mouse_pos):
                self.sound.play('click')
                game_state.next_level()
                return GameStates.PLAYING

        return GameStates.SHOP

    def _apply_purchase(self, key: str, game_state):
        """Applies the purchased buff to GameState."""
        if key == "dynamite":
            game_state.add_bomb(1)
        elif key == "strength_drink":
            game_state.purchased_strength_drink = True
        elif key == "lucky_clover":
            game_state.has_clover = True
        elif key == "diamond_polish":
            game_state.has_diamond_polish = True
        elif key == "rock_book":
            game_state.has_rock_book = True

    def draw(self, surface: pygame.Surface, game_state, virtual_mouse_pos=(0, 0)):
        # 1. Warm Wood Shop Background
        for y in range(VIRTUAL_HEIGHT):
            ratio = y / VIRTUAL_HEIGHT
            r = int(50 - ratio * 20)
            g = int(35 - ratio * 15)
            b = int(22 - ratio * 10)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        # 2. Shop Title Header
        title_surf = self.font_title.render("CỬA HÀNG MỎ VÀNG", True, COLOR_GOLD_TEXT)
        surface.blit(title_surf, (VIRTUAL_WIDTH // 2 - title_surf.get_width() // 2, 25))

        # Current Money Badge
        money_text = f"TIỀN HIỆN CÓ: ${game_state.total_money:,}   |   BOM DỰ TRỮ: x{game_state.bombs_count}"
        money_surf = self.font_item_name.render(money_text, True, (255, 235, 120))
        surface.blit(money_surf, (VIRTUAL_WIDTH // 2 - money_surf.get_width() // 2, 85))

        # Dialogue prompt
        dialogue = "Hãy chọn mua các vật phẩm đắc lực để chuẩn bị cho màn chơi tiếp theo!"
        d_surf = self.font_desc.render(dialogue, True, (210, 210, 220))
        surface.blit(d_surf, (VIRTUAL_WIDTH // 2 - d_surf.get_width() // 2, 122))

        # 3. Item Cards
        start_y = 165
        item_h = 92

        for idx, item in enumerate(self.available_items):
            y = start_y + idx * (item_h + 14)
            card_rect = pygame.Rect(100, y, VIRTUAL_WIDTH - 200, item_h)

            # Card background
            card_surf = pygame.Surface((card_rect.width, card_rect.height), pygame.SRCALPHA)
            card_surf.fill((25, 18, 14, 220))
            surface.blit(card_surf, card_rect.topleft)
            pygame.draw.rect(surface, (140, 95, 45), card_rect, 2, border_radius=8)

            # Draw Item Icon
            self._draw_item_icon(surface, item.icon_type, card_rect.x + 42, card_rect.centery)

            # Item Name & Description
            name_surf = self.font_item_name.render(item.name, True, COLOR_GOLD_TEXT if not item.is_purchased else (140, 140, 140))
            desc_surf = self.font_desc.render(item.description, True, (200, 200, 200) if not item.is_purchased else (120, 120, 120))
            surface.blit(name_surf, (card_rect.x + 85, card_rect.y + 18))
            surface.blit(desc_surf, (card_rect.x + 85, card_rect.y + 52))

            # Buy Button
            btn_rect = self.item_buy_rects[idx]
            can_afford = (game_state.total_money >= item.price) and not item.is_purchased
            
            if item.is_purchased:
                pygame.draw.rect(surface, (60, 60, 60), btn_rect, border_radius=8)
                btn_txt = self.font_btn.render("ĐÃ MUA", True, (160, 160, 160))
            elif can_afford:
                is_hover = btn_rect.collidepoint(virtual_mouse_pos)
                btn_col = COLOR_GREEN_BTN_HOVER if is_hover else COLOR_GREEN_BTN
                pygame.draw.rect(surface, btn_col, btn_rect, border_radius=8)
                pygame.draw.rect(surface, (255, 255, 255), btn_rect, 2, border_radius=8)
                btn_txt = self.font_btn.render(f"${item.price:,}", True, COLOR_WHITE)
            else:
                pygame.draw.rect(surface, (90, 40, 40), btn_rect, border_radius=8)
                btn_txt = self.font_btn.render(f"${item.price:,}", True, (200, 120, 120))

            surface.blit(btn_txt, (btn_rect.centerx - btn_txt.get_width() // 2, btn_rect.centery - btn_txt.get_height() // 2))

        # 4. Next Level Button
        is_next_hover = self.next_level_btn.collidepoint(virtual_mouse_pos)
        next_col = (41, 128, 185) if is_next_hover else (52, 152, 219)
        
        pygame.draw.rect(surface, next_col, self.next_level_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.next_level_btn, 2, border_radius=8)

        next_txt = self.font_btn.render(f"TIẾP TỤC LEVEL {game_state.current_level + 1}", True, COLOR_WHITE)
        surface.blit(next_txt, (self.next_level_btn.centerx - next_txt.get_width() // 2, self.next_level_btn.centery - next_txt.get_height() // 2))

    def _draw_item_icon(self, surface: pygame.Surface, icon_type: str, x: int, y: int):
        """Renders stylized icon for shop items."""
        if icon_type == "dynamite":
            pygame.draw.circle(surface, (220, 40, 30), (x, y), 16)
            pygame.draw.line(surface, (240, 200, 50), (x, y - 16), (x + 7, y - 22), 2)
        elif icon_type == "drink":
            pygame.draw.rect(surface, (170, 50, 220), (x - 9, y - 7, 18, 22), border_radius=4)
            pygame.draw.rect(surface, (220, 180, 100), (x - 5, y - 13, 10, 6))
        elif icon_type == "clover":
            for dx, dy in [(-6, -6), (6, -6), (-6, 6), (6, 6)]:
                pygame.draw.circle(surface, (46, 204, 113), (x + dx, y + dy), 7)
            pygame.draw.line(surface, (39, 174, 96), (x, y + 2), (x, y + 16), 2)
        elif icon_type == "polish":
            pygame.draw.polygon(surface, (90, 225, 255), [(x, y - 14), (x - 12, y), (x, y + 14), (x + 12, y)])
        elif icon_type == "book":
            pygame.draw.rect(surface, (160, 110, 50), (x - 14, y - 14, 28, 28), border_radius=2)
            pygame.draw.line(surface, (240, 240, 240), (x - 14, y), (x + 14, y), 2)
