"""
Item entities for Gold Miner: Gold, Diamond, Rock, Mystery Bag, Boar, and TNT.
Strictly configured with the specified Mass & Value properties from context.
"""
import math
import random
import pygame
from constants import (
    COLOR_GOLD_MAIN, COLOR_GOLD_LIGHT, COLOR_GOLD_DARK, COLOR_GOLD_SHINE,
    COLOR_DIAMOND_MAIN, COLOR_DIAMOND_LIGHT, COLOR_DIAMOND_DARK,
    COLOR_ROCK_MAIN, COLOR_ROCK_LIGHT, COLOR_ROCK_DARK,
    COLOR_TNT_MAIN, COLOR_TNT_BAND, COLOR_TNT_DARK,
    COLOR_BAG_MAIN, COLOR_BAG_STRING, COLOR_BAG_QUESTION,
    COLOR_BOAR_BODY, COLOR_BOAR_SNOUT, COLOR_BOAR_TUSK,
    VIRTUAL_WIDTH, GROUND_Y, get_font
)

class Item:
    """Base class for all mineable objects and underground entities."""
    def __init__(self, x: float, y: float, radius: float, mass: float, value: int, item_type: str):
        self.x = x
        self.y = y
        self.radius = radius
        self.mass = mass
        self.base_value = value
        self.value = value
        self.item_type = item_type
        self.is_alive = True
        self.is_caught = False
        self.rotation_angle = random.uniform(0, 360)

    def update(self, dt: float):
        """Default entity update (static items do not move on their own)."""
        pass

    def get_collision_circle(self) -> tuple:
        """Returns (x, y, radius) for distance-based collision detection."""
        return (self.x, self.y, self.radius)

    def draw(self, surface: pygame.Surface):
        """Draws the item on the surface."""
        pass

class GoldItem(Item):
    """
    Gold nugget entity:
    - Small: 100đ, Mass = 1 (Fast pull)
    - Medium: 250đ, Mass = 4 (Medium pull)
    - Large: 500đ, Mass = 9 (Heavy pull)
    """
    def __init__(self, x: float, y: float, size_type: str = "medium"):
        if size_type == "small":
            radius, mass, val = 16.0, 1.0, 100
        elif size_type == "medium":
            radius, mass, val = 26.0, 4.0, 250
        else:  # large
            radius, mass, val = 39.0, 9.0, 500

        super().__init__(x, y, radius, mass, val, "gold")
        self.size_type = size_type
        
        # Pre-compute irregular polygon vertices for organic nugget shape
        self.points = []
        num_points = 10 if size_type != "large" else 14
        random.seed(int(x * 100 + y))
        for i in range(num_points):
            ang = (i / num_points) * 2 * math.pi
            r = self.radius * random.uniform(0.82, 1.18)
            self.points.append((math.cos(ang) * r, math.sin(ang) * r))
        random.seed()

    def draw(self, surface: pygame.Surface):
        poly = [(self.x + px, self.y + py) for px, py in self.points]
        
        # Shadow
        shadow_poly = [(self.x + px + 2, self.y + py + 3) for px, py in self.points]
        pygame.draw.polygon(surface, (80, 50, 5), shadow_poly)
        
        # Main gold body
        pygame.draw.polygon(surface, COLOR_GOLD_MAIN, poly)
        pygame.draw.polygon(surface, COLOR_GOLD_DARK, poly, 2)
        
        # Highlights & facets
        inner_points = [(self.x + px * 0.55 - self.radius * 0.15, self.y + py * 0.55 - self.radius * 0.15) for px, py in self.points[:5]]
        if len(inner_points) >= 3:
            pygame.draw.polygon(surface, COLOR_GOLD_LIGHT, inner_points)
            
        # Shiny glint dot
        glint_x = self.x - self.radius * 0.35
        glint_y = self.y - self.radius * 0.35
        pygame.draw.circle(surface, COLOR_GOLD_SHINE, (int(glint_x), int(glint_y)), max(2, int(self.radius * 0.18)))

class DiamondItem(Item):
    """
    Diamond entity: 500đ, Mass = 1 (Extremely fast pull).
    """
    def __init__(self, x: float, y: float):
        super().__init__(x, y, radius=13.0, mass=1.0, value=500, item_type="diamond")
        self.shine_timer = random.uniform(0, 3.0)

    def update(self, dt: float):
        self.shine_timer += dt

    def draw(self, surface: pygame.Surface):
        r = self.radius
        cx, cy = self.x, self.y

        # Diamond geometry
        top = (cx, cy - r)
        bottom = (cx, cy + r * 1.1)
        left = (cx - r * 0.9, cy - r * 0.2)
        right = (cx + r * 0.9, cy - r * 0.2)
        mid_left = (cx - r * 0.45, cy - r * 0.2)
        mid_right = (cx + r * 0.45, cy - r * 0.2)
        top_left = (cx - r * 0.4, cy - r)
        top_right = (cx + r * 0.4, cy - r)

        # Glow / Shadow
        glow_size = int(r * 2.6)
        glow_surf = pygame.Surface((glow_size, glow_size), pygame.SRCALPHA)
        pulse = 0.5 + 0.5 * math.sin(self.shine_timer * 4.0)
        pygame.draw.circle(glow_surf, (120, 235, 255, int(40 + 35 * pulse)), (glow_size // 2, glow_size // 2), int(r * 1.25))
        surface.blit(glow_surf, (cx - glow_size // 2, cy - glow_size // 2))

        # Facets
        pygame.draw.polygon(surface, COLOR_DIAMOND_DARK, [bottom, left, right])
        pygame.draw.polygon(surface, COLOR_DIAMOND_MAIN, [bottom, mid_left, mid_right])
        pygame.draw.polygon(surface, COLOR_DIAMOND_LIGHT, [top, left, mid_left, top_left])
        pygame.draw.polygon(surface, (235, 255, 255), [top, top_left, top_right])
        pygame.draw.polygon(surface, COLOR_DIAMOND_LIGHT, [top, right, mid_right, top_right])
        
        # Facet outlines
        pygame.draw.polygon(surface, (255, 255, 255), [top, left, bottom, right], 1)
        pygame.draw.line(surface, (255, 255, 255), left, right, 1)

        # Sparkling flare
        if pulse > 0.7:
            flare_len = int(r * 0.75 * pulse)
            pygame.draw.line(surface, (255, 255, 255), (cx - flare_len, cy - r * 0.2), (cx + flare_len, cy - r * 0.2), 1)
            pygame.draw.line(surface, (255, 255, 255), (cx, cy - r * 0.2 - flare_len), (cx, cy - r * 0.2 + flare_len), 1)

class RockItem(Item):
    """
    Rock boulder:
    - Small: 10đ, Mass = 9 (Heavy pull equivalent to large gold)
    - Large: 20đ, Mass = 9 (Heavy pull equivalent to large gold)
    """
    def __init__(self, x: float, y: float, size_type: str = "medium"):
        if size_type == "small":
            radius, val = 21.0, 10
        else:  # large
            radius, val = 35.0, 20

        # Both Small and Large rocks have Mass = 9 as specified
        super().__init__(x, y, radius, mass=9.0, value=val, item_type="rock")
        self.size_type = size_type

        # Pre-compute rock craggy edges
        self.points = []
        num_points = 8 if size_type == "small" else 11
        random.seed(int(x * 77 + y))
        for i in range(num_points):
            ang = (i / num_points) * 2 * math.pi
            r = self.radius * random.uniform(0.85, 1.15)
            self.points.append((math.cos(ang) * r, math.sin(ang) * r))
        random.seed()

    def draw(self, surface: pygame.Surface):
        poly = [(self.x + px, self.y + py) for px, py in self.points]
        
        # Shadow
        shadow_poly = [(self.x + px + 2, self.y + py + 3) for px, py in self.points]
        pygame.draw.polygon(surface, (40, 40, 45), shadow_poly)
        
        # Base rock
        pygame.draw.polygon(surface, COLOR_ROCK_MAIN, poly)
        pygame.draw.polygon(surface, COLOR_ROCK_DARK, poly, 2)
        
        # Cracks / Texture
        p1 = (self.x - self.radius * 0.3, self.y - self.radius * 0.2)
        p2 = (self.x + self.radius * 0.2, self.y + self.radius * 0.3)
        pygame.draw.line(surface, COLOR_ROCK_DARK, p1, p2, 2)
        
        # Top-left highlight
        highlight_points = [(self.x + px * 0.6 - self.radius * 0.1, self.y + py * 0.6 - self.radius * 0.1) for px, py in self.points[:4]]
        if len(highlight_points) >= 3:
            pygame.draw.polygon(surface, COLOR_ROCK_LIGHT, highlight_points)

class MysteryBagItem(Item):
    """Mystery grab bag containing random prizes (high cash, bomb, strength). Mass = 3."""
    def __init__(self, x: float, y: float):
        super().__init__(x, y, radius=22.0, mass=3.0, value=0, item_type="mystery_bag")
        self.font = get_font(22, bold=True)

    def draw(self, surface: pygame.Surface):
        cx, cy = int(self.x), int(self.y)
        r = int(self.radius)

        # Shadow
        pygame.draw.circle(surface, (50, 35, 20), (cx + 2, cy + 3), r)
        
        # Sack pouch
        pygame.draw.circle(surface, COLOR_BAG_MAIN, (cx, cy + 3), r)
        pygame.draw.circle(surface, (150, 105, 50), (cx, cy + 3), r, 2)
        
        # Sack tied top
        top_rect = pygame.Rect(cx - r * 0.55, cy - r * 0.95, r * 1.1, r * 0.5)
        pygame.draw.ellipse(surface, COLOR_BAG_MAIN, top_rect)
        pygame.draw.line(surface, COLOR_BAG_STRING, (cx - r * 0.6, cy - r * 0.5), (cx + r * 0.6, cy - r * 0.5), 3)

        # Question mark "?" in center
        q_surf = self.font.render("?", True, COLOR_BAG_QUESTION)
        surface.blit(q_surf, (cx - q_surf.get_width() // 2, cy - q_surf.get_height() // 2 + 3))

class BoarItem(Item):
    """Wild boar that trots horizontally. May carry a diamond! Mass = 2."""
    def __init__(self, x: float, y: float, carries_diamond: bool = False, min_x: float = 60, max_x: float = VIRTUAL_WIDTH - 60):
        super().__init__(x, y, radius=19.0, mass=2.0, value=2, item_type="boar")
        self.carries_diamond = carries_diamond
        if self.carries_diamond:
            self.value = 502
        self.min_x = min_x
        self.max_x = max_x
        self.speed = random.uniform(55.0, 95.0)
        self.direction = 1 if random.random() > 0.5 else -1
        self.anim_timer = 0.0

    def update(self, dt: float):
        if not self.is_caught:
            self.x += self.direction * self.speed * dt
            if self.x <= self.min_x:
                self.x = self.min_x
                self.direction = 1
            elif self.x >= self.max_x:
                self.x = self.max_x
                self.direction = -1
            self.anim_timer += dt * 8.0

    def draw(self, surface: pygame.Surface):
        cx, cy = int(self.x), int(self.y)
        d = self.direction

        # Boar Body (ellipse)
        body_rect = pygame.Rect(cx - 18, cy - 11, 36, 22)
        pygame.draw.ellipse(surface, COLOR_BOAR_BODY, body_rect)
        pygame.draw.ellipse(surface, (80, 45, 25), body_rect, 2)

        # Legs with running animation
        leg_offset = math.sin(self.anim_timer) * 4 if not self.is_caught else 0
        pygame.draw.rect(surface, (70, 40, 20), (cx - 10 + leg_offset, cy + 8, 4, 8))
        pygame.draw.rect(surface, (70, 40, 20), (cx + 6 - leg_offset, cy + 8, 4, 8))

        # Snout / Head
        snout_x = cx + d * 14
        pygame.draw.circle(surface, COLOR_BOAR_SNOUT, (snout_x, cy - 2), 6)
        
        # Eye
        eye_x = cx + d * 7
        pygame.draw.circle(surface, (255, 255, 255), (eye_x, cy - 6), 3)
        pygame.draw.circle(surface, (0, 0, 0), (eye_x + d * 1, cy - 6), 1)

        # Tusk
        tusk_x = snout_x + d * 3
        pygame.draw.polygon(surface, COLOR_BOAR_TUSK, [(tusk_x, cy), (tusk_x + d * 4, cy - 5), (tusk_x, cy - 2)])

        # Diamond on back if carrying
        if self.carries_diamond:
            diamond_x = cx - d * 3
            diamond_y = cy - 14
            pygame.draw.polygon(surface, COLOR_DIAMOND_MAIN, [
                (diamond_x, diamond_y - 7),
                (diamond_x - 6, diamond_y),
                (diamond_x, diamond_y + 6),
                (diamond_x + 6, diamond_y)
            ])
            pygame.draw.polygon(surface, COLOR_DIAMOND_LIGHT, [
                (diamond_x, diamond_y - 7),
                (diamond_x - 6, diamond_y),
                (diamond_x, diamond_y)
            ])

class TNTItem(Item):
    """TNT Explosive barrel: triggers a massive chain explosion upon hook contact. Mass = 1."""
    def __init__(self, x: float, y: float):
        super().__init__(x, y, radius=21.0, mass=1.0, value=1, item_type="tnt")
        self.font = get_font(14, bold=True)

    def draw(self, surface: pygame.Surface):
        cx, cy = int(self.x), int(self.y)
        w, h = 30, 36
        rect = pygame.Rect(cx - w // 2, cy - h // 2, w, h)

        # Shadow
        pygame.draw.rect(surface, (60, 15, 10), (rect.x + 2, rect.y + 3, w, h), border_radius=4)
        
        # Barrel body
        pygame.draw.rect(surface, COLOR_TNT_MAIN, rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_TNT_DARK, rect, 2, border_radius=4)

        # Metal / Yellow hoops
        pygame.draw.line(surface, COLOR_TNT_BAND, (rect.left + 2, rect.top + 7), (rect.right - 2, rect.top + 7), 3)
        pygame.draw.line(surface, COLOR_TNT_BAND, (rect.left + 2, rect.bottom - 7), (rect.right - 2, rect.bottom - 7), 3)

        # "TNT" text in center
        tnt_surf = self.font.render("TNT", True, (255, 255, 255))
        surface.blit(tnt_surf, (cx - tnt_surf.get_width() // 2, cy - tnt_surf.get_height() // 2))

        # Fuse on top
        pygame.draw.line(surface, (60, 40, 20), (cx, rect.top), (cx + 3, rect.top - 6), 2)
        pygame.draw.circle(surface, (255, 200, 50), (cx + 3, rect.top - 6), 2)
