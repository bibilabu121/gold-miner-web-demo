"""
Sound & Audio Controller: Manages procedurally synthesized sound effects (SFX)
and looping background music (BGM) using pure Python byte buffers.
100% compatible with both Desktop and WebAssembly (Pygbag / Emscripten) without external dependencies.
"""
import math
import struct
import random
import pygame

class SoundManager:
    """Manages audio playback, volume controls, and synthesized SFX/BGM."""
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.enabled = False
        self.sounds = {}
        self.sample_rate = 22050  # Lightweight 22.05 kHz for instant WASM loading
        
        # Audio configuration
        self.volume_level = 0.75  # 0.0 to 1.0 (75%)
        self.is_bgm_muted = False
        self.is_sfx_muted = False
        
        self.bgm_sound = None
        self.bgm_channel = None

        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=self.sample_rate, size=-16, channels=2, buffer=512)
            self.enabled = True
            try:
                self.bgm_channel = pygame.mixer.Channel(0)
            except Exception:
                self.bgm_channel = None
            self._generate_sounds()
            self._generate_bgm()
        except Exception as e:
            print(f"[SoundManager] Audio initialization failed or skipped: {e}")
            self.enabled = False

    def _create_sound_from_samples(self, samples: list) -> pygame.mixer.Sound:
        """Converts float sample list (-1.0 to 1.0) into stereo 16-bit pygame Sound buffer."""
        raw = bytearray()
        for s in samples:
            val = int(max(-1.0, min(1.0, s)) * 32767)
            # Stereo 16-bit little-endian (left, right)
            packed = struct.pack('<hh', val, val)
            raw.extend(packed)
        return pygame.mixer.Sound(buffer=bytes(raw))

    def _generate_sounds(self):
        """Pre-computes all sound effects (SFX) using pure math formulas."""
        try:
            sr = self.sample_rate

            # 1. SHOOT SOUND (whistle / swoosh)
            dur = 0.20
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                freq = 800 - (500 * (i / total_samples))
                env = math.exp(-4 * t / dur)
                s = 0.5 * math.sin(2 * math.pi * freq * t) * env
                samples.append(s)
            self.sounds['shoot'] = self._create_sound_from_samples(samples)

            # 2. GRAB SOUND (thud / latch)
            dur = 0.12
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                noise = (random.random() * 2 - 1) * 0.4
                env = math.exp(-25 * t)
                s = (0.7 * math.sin(2 * math.pi * 140 * t) + noise) * env
                samples.append(s)
            self.sounds['grab'] = self._create_sound_from_samples(samples)

            # 3. MONEY / GOLD COLLECT (bright two-tone coin chime)
            dur = 0.30
            total_samples = int(sr * dur)
            half = total_samples // 2
            samples = []
            for i in range(total_samples):
                if i < half:
                    t = i / sr
                    s = 0.45 * math.sin(2 * math.pi * 987.77 * t) * math.exp(-12 * t)
                else:
                    t = (i - half) / sr
                    s = 0.55 * math.sin(2 * math.pi * 1318.51 * t) * math.exp(-8 * t)
                samples.append(s)
            self.sounds['money'] = self._create_sound_from_samples(samples)

            # 4. DIAMOND COLLECT (sparkling triple chime)
            dur = 0.40
            total_samples = int(sr * dur)
            third = total_samples // 3
            samples = []
            for i in range(total_samples):
                if i < third:
                    t = i / sr
                    s = 0.4 * math.sin(2 * math.pi * 1046.50 * t) * math.exp(-8 * t)
                elif i < third * 2:
                    t = (i - third) / sr
                    s = 0.45 * math.sin(2 * math.pi * 1318.51 * t) * math.exp(-8 * t)
                else:
                    t = (i - third * 2) / sr
                    s = 0.6 * math.sin(2 * math.pi * 1760.00 * t) * math.exp(-6 * t)
                samples.append(s)
            self.sounds['diamond'] = self._create_sound_from_samples(samples)

            # 5. EXPLOSION (deep booming rumble)
            dur = 0.60
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                noise = (random.random() * 2 - 1)
                low_freq = 90 - (65 * (i / total_samples))
                low_sine = math.sin(2 * math.pi * low_freq * t)
                env = math.exp(-4.5 * t)
                s = (0.75 * noise + 0.55 * low_sine) * env
                samples.append(s)
            self.sounds['explosion'] = self._create_sound_from_samples(samples)

            # 6. BOMB THROW / FIZZ
            dur = 0.25
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                noise = (random.random() * 2 - 1) * 0.4
                pitch = 350 + (400 * (i / total_samples))
                s = (math.sin(2 * math.pi * pitch * t) * 0.4 + noise) * math.exp(-3 * t / dur)
                samples.append(s)
            self.sounds['bomb_throw'] = self._create_sound_from_samples(samples)

            # 7. SHOP PURCHASE (Cash register bell)
            dur = 0.35
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                s = 0.5 * (math.sin(2 * math.pi * 1567.98 * t) + 0.5 * math.sin(2 * math.pi * 3135.96 * t)) * math.exp(-9 * t)
                samples.append(s)
            self.sounds['shop_buy'] = self._create_sound_from_samples(samples)

            # 8. LEVEL WIN (Celebratory fanfare)
            dur = 0.8
            total_samples = int(sr * dur)
            seg = total_samples // 4
            notes = [523.25, 659.25, 783.99, 1046.50]
            samples = []
            for i in range(total_samples):
                idx = min(3, i // seg)
                sub_t = (i % seg) / sr
                env = math.exp(-4 * sub_t) if idx < 3 else math.exp(-2.5 * sub_t)
                s = (0.5 * math.sin(2 * math.pi * notes[idx] * sub_t) + 0.2 * math.sin(2 * math.pi * notes[idx] * 2 * sub_t)) * env
                samples.append(s)
            self.sounds['level_win'] = self._create_sound_from_samples(samples)

            # 9. GAME OVER (Sad descending jingle)
            dur = 0.9
            total_samples = int(sr * dur)
            seg = total_samples // 3
            notes = [440.0, 392.0, 329.63]
            samples = []
            for i in range(total_samples):
                idx = min(2, i // seg)
                sub_t = (i % seg) / sr
                env = math.exp(-3.5 * sub_t)
                s = (0.5 * math.sin(2 * math.pi * notes[idx] * sub_t)) * env
                samples.append(s)
            self.sounds['game_over'] = self._create_sound_from_samples(samples)

            # 10. CLICK (UI Button)
            dur = 0.05
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                s = 0.3 * math.sin(2 * math.pi * 800 * t) * math.exp(-40 * t)
                samples.append(s)
            self.sounds['click'] = self._create_sound_from_samples(samples)

            # 11. BOAR SQUEAK
            dur = 0.18
            total_samples = int(sr * dur)
            samples = []
            for i in range(total_samples):
                t = i / sr
                freq = 400 + 200 * math.sin(2 * math.pi * 25 * t)
                s = 0.4 * math.sin(2 * math.pi * freq * t) * math.exp(-6 * t)
                samples.append(s)
            self.sounds['boar'] = self._create_sound_from_samples(samples)

        except Exception as e:
            print(f"[SoundManager] Error generating procedural audio: {e}")

    def _generate_bgm(self):
        """Generates a pleasant, melodic 8-bar arcade background music loop."""
        try:
            sr = self.sample_rate
            bpm = 120
            beat_dur = 60.0 / bpm  # 0.5s per beat
            total_beats = 16  # 8 seconds loop
            total_samples = int(sr * beat_dur * total_beats)
            step = int(sr * beat_dur)

            melody_notes = [
                261.63, 329.63, 392.00, 523.25,
                392.00, 329.63, 293.66, 329.63,
                261.63, 392.00, 440.00, 523.25,
                392.00, 293.66, 261.63, 261.63
            ]

            bass_notes = [
                130.81, 130.81, 164.81, 164.81,
                196.00, 196.00, 146.83, 146.83,
                130.81, 130.81, 174.61, 174.61,
                196.00, 196.00, 130.81, 130.81
            ]

            full_samples = [0.0] * total_samples

            for b in range(total_beats):
                start = b * step
                end = min(total_samples, (b + 1) * step)
                seg_len = end - start

                m_freq = melody_notes[b]
                b_freq = bass_notes[b]

                for i in range(seg_len):
                    t = i / sr
                    m_env = math.exp(-3.0 * t)
                    m_wave = 0.22 * math.sin(2 * math.pi * m_freq * t) * m_env + \
                             0.08 * math.sin(4 * math.pi * m_freq * t) * m_env

                    b_env = math.exp(-2.2 * t)
                    b_wave = 0.25 * math.sin(2 * math.pi * b_freq * t) * b_env

                    p_noise = (random.random() * 2 - 1) * 0.06 * math.exp(-40 * t)

                    full_samples[start + i] = m_wave + b_wave + p_noise

            self.bgm_sound = self._create_sound_from_samples(full_samples)
        except Exception as e:
            print(f"[SoundManager] Error generating procedural BGM: {e}")

    def start_bgm(self):
        """Starts looping background music."""
        if not self.enabled or self.bgm_sound is None or self.is_bgm_muted:
            return
        try:
            effective_vol = 0.45 * self.volume_level
            self.bgm_sound.set_volume(effective_vol)
            if self.bgm_channel and not self.bgm_channel.get_busy():
                self.bgm_channel.play(self.bgm_sound, loops=-1)
        except Exception:
            pass

    def stop_bgm(self):
        """Stops background music."""
        if self.enabled and self.bgm_channel:
            try:
                self.bgm_channel.stop()
            except Exception:
                pass

    def toggle_bgm(self) -> bool:
        """Toggles BGM mute state. Returns current state."""
        self.is_bgm_muted = not self.is_bgm_muted
        if self.is_bgm_muted:
            self.stop_bgm()
        else:
            self.start_bgm()
        return not self.is_bgm_muted

    def toggle_sfx(self) -> bool:
        """Toggles SFX mute state. Returns current state."""
        self.is_sfx_muted = not self.is_sfx_muted
        return not self.is_sfx_muted

    def set_volume(self, level: float):
        """Sets master volume level (0.0 to 1.0)."""
        self.volume_level = max(0.0, min(1.0, level))
        if self.bgm_sound and not self.is_bgm_muted:
            self.bgm_sound.set_volume(0.45 * self.volume_level)

    def increase_volume(self, delta: float = 0.1):
        """Increases volume by delta."""
        self.set_volume(self.volume_level + delta)

    def decrease_volume(self, delta: float = 0.1):
        """Decreases volume by delta."""
        self.set_volume(self.volume_level - delta)

    def play(self, sound_name: str, volume: float = 0.8):
        """Plays SFX with volume scaling and mute check."""
        if not self.enabled or self.is_sfx_muted or sound_name not in self.sounds:
            return
        try:
            sound = self.sounds[sound_name]
            sound.set_volume(volume * self.volume_level)
            sound.play()
        except Exception:
            pass
