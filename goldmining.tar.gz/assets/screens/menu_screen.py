"""
Menu screen: Title, high score, standardized controls guide, clean uppercase buttons,
"CHƠI MỚI", "TIẾP TỤC TRÒ CHƠI" (when active session exists), Audio controls,
Aspect Ratio presets, and clean Quit option.
Rendered on 1280x720 Virtual Canvas with Unicode font support.
"""
import sys
import math
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER, COLOR_RED_BTN,
    COLOR_RED_BTN_HOVER, COLOR_BLUE_BTN, COLOR_BLUE_BTN_HOVER,
    COLOR_PANEL_BG, COLOR_PANEL_BORDER, GameStates, get_font,
    ASPECT_RATIO_PRESETS
)
from sound_manager import SoundManager

class MenuScreen:
    """Renders the main menu interface with Aspect Ratio, Fullscreen, and Sound configuration."""
    def __init__(self):
        self.font_title = get_font(56, bold=True)
        self.font_sub = get_font(22, bold=True)
        self.font_btn = get_font(21, bold=True)
        self.font_btn_sm = get_font(16, bold=True)
        self.font_info = get_font(18)
        self.font_info_bold = get_font(18, bold=True)
        
        self.anim_time = 0.0
        
        # Primary Action Buttons
        self.start_btn_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 370, 420, 230, 56)
        self.resume_btn_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 125, 420, 250, 56)
        self.quit_btn_rect  = pygame.Rect(VIRTUAL_WIDTH // 2 + 140, 420, 230, 56)
        
        # Audio row buttons
        self.bgm_btn_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 270, 500, 140, 42)
        self.sfx_btn_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 120, 500, 140, 42)
        self.vol_down_rect = pygame.Rect(VIRTUAL_WIDTH // 2 + 30, 500, 45, 42)
        self.vol_up_rect   = pygame.Rect(VIRTUAL_WIDTH // 2 + 225, 500, 45, 42)

        # Aspect Ratio preset buttons
        self.preset_btn_16_9 = pygame.Rect(VIRTUAL_WIDTH // 2 - 320, 615, 150, 44)
        self.preset_btn_9_16 = pygame.Rect(VIRTUAL_WIDTH // 2 - 160, 615, 150, 44)
        self.preset_btn_3_4  = pygame.Rect(VIRTUAL_WIDTH // 2 + 0, 615, 150, 44)
        self.fullscreen_btn  = pygame.Rect(VIRTUAL_WIDTH // 2 + 160, 615, 160, 44)

        self.sound = SoundManager.get_instance()

    def handle_event(self, event, game_state, screen_manager=None, play_screen=None) -> str:
        """Handles keyboard and mouse clicks in menu, including aspect ratio and audio settings."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                self.sound.play('click')
                if game_state.has_saved_session:
                    # Resume existing game
                    return GameStates.PLAYING
                else:
                    # Start fresh game
                    game_state.start_game()
                    if play_screen:
                        play_screen.start_level(game_state)
                    return GameStates.PLAYING
            elif event.key == pygame.K_q:
                pygame.quit()
                sys.exit()
            elif event.key == pygame.K_F11 and screen_manager:
                self.sound.play('click')
                screen_manager.toggle_fullscreen()
            elif event.key == pygame.K_1 and screen_manager:
                self.sound.play('click')
                screen_manager.set_aspect_ratio_preset(0)
            elif event.key == pygame.K_2 and screen_manager:
                self.sound.play('click')
                screen_manager.set_aspect_ratio_preset(1)
            elif event.key == pygame.K_3 and screen_manager:
                self.sound.play('click')
                screen_manager.set_aspect_ratio_preset(2)
            elif event.key == pygame.K_m:
                self.sound.toggle_bgm()
            elif event.key == pygame.K_s:
                self.sound.toggle_sfx()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos

            # Start Fresh Game ("CHƠI MỚI")
            if self.start_btn_rect.collidepoint(mouse_pos):
                self.sound.play('click')
                game_state.start_game()
                if play_screen:
                    play_screen.start_level(game_state)
                return GameStates.PLAYING

            # Resume Ongoing Game ("TIẾP TỤC TRÒ CHƠI")
            if game_state.has_saved_session and self.resume_btn_rect.collidepoint(mouse_pos):
                self.sound.play('click')
                return GameStates.PLAYING

            # Quit Game ("THOÁT GAME")
            if self.quit_btn_rect.collidepoint(mouse_pos):
                pygame.quit()
                sys.exit()

            # Audio Controls
            if self.bgm_btn_rect.collidepoint(mouse_pos):
                self.sound.toggle_bgm()
                self.sound.play('click')
                return GameStates.MENU
            elif self.sfx_btn_rect.collidepoint(mouse_pos):
                self.sound.toggle_sfx()
                self.sound.play('click')
                return GameStates.MENU
            elif self.vol_down_rect.collidepoint(mouse_pos):
                self.sound.decrease_volume(0.1)
                self.sound.play('click')
                return GameStates.MENU
            elif self.vol_up_rect.collidepoint(mouse_pos):
                self.sound.increase_volume(0.1)
                self.sound.play('click')
                return GameStates.MENU

            # Aspect Ratio / Fullscreen Controls
            if screen_manager:
                if self.preset_btn_16_9.collidepoint(mouse_pos):
                    self.sound.play('click')
                    screen_manager.set_aspect_ratio_preset(0)
                elif self.preset_btn_9_16.collidepoint(mouse_pos):
                    self.sound.play('click')
                    screen_manager.set_aspect_ratio_preset(1)
                elif self.preset_btn_3_4.collidepoint(mouse_pos):
                    self.sound.play('click')
                    screen_manager.set_aspect_ratio_preset(2)
                elif self.fullscreen_btn.collidepoint(mouse_pos):
                    self.sound.play('click')
                    screen_manager.toggle_fullscreen()

        return GameStates.MENU

    def update(self, dt: float):
        self.anim_time += dt

    def draw(self, surface: pygame.Surface, game_state, screen_manager=None, virtual_mouse_pos=(0, 0)):
        # 1. Gradient Background
        for y in range(VIRTUAL_HEIGHT):
            ratio = y / VIRTUAL_HEIGHT
            r = int(25 + ratio * 35)
            g = int(35 + ratio * 20)
            b = int(60 - ratio * 40)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        # Decorative Underground particles
        for i in range(18):
            px = (i * 89 + 40) % VIRTUAL_WIDTH
            py = (i * 103 + 120) % (VIRTUAL_HEIGHT - 140) + 90
            pulse = 0.5 + 0.5 * math.sin(self.anim_time * 2.0 + i)
            pygame.draw.circle(surface, (255, 215, 0, 50), (px, py), int(7 + 5 * pulse))

        # 2. Main Title
        title_pulse = math.sin(self.anim_time * 3.0) * 4.0
        title_surf = self.font_title.render("GOLD MINER", True, COLOR_GOLD_TEXT)
        title_shadow = self.font_title.render("GOLD MINER", True, (30, 20, 10))
        
        tx = VIRTUAL_WIDTH // 2 - title_surf.get_width() // 2
        ty = 65 + int(title_pulse)
        surface.blit(title_shadow, (tx + 3, ty + 4))
        surface.blit(title_surf, (tx, ty))

        sub_surf = self.font_sub.render("DAO VANG SIEU CAP - CHUAN ARCADE CLASSIC", True, (220, 230, 245))
        surface.blit(sub_surf, (VIRTUAL_WIDTH // 2 - sub_surf.get_width() // 2, ty + 70))

        # 3. High Score Badge
        hs_text = f"KY LUC DIEM CAO: ${game_state.high_score:,}"
        hs_surf = self.font_btn.render(hs_text, True, (255, 235, 120))
        surface.blit(hs_surf, (VIRTUAL_WIDTH // 2 - hs_surf.get_width() // 2, 195))

        # 4. Standardized Controls Guide Panel (Exact format required by context)
        panel_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 340, 245, 680, 150)
        panel_surf = pygame.Surface((panel_rect.width, panel_rect.height), pygame.SRCALPHA)
        panel_surf.fill(COLOR_PANEL_BG)
        surface.blit(panel_surf, panel_rect.topleft)
        pygame.draw.rect(surface, COLOR_PANEL_BORDER, panel_rect, 2, border_radius=8)

        controls = [
            ("Phím [ Chuột trái ] hoặc [ SPACE ] :", "Thả móc ngoắm / Bắn móc"),
            ("Phím [ Chuột phải ] :", "Ném Bom phá hủy vật phẩm khi đang kéo"),
            ("Phím [ ESC ] :", "Tạm dừng trận đấu"),
        ]
        for idx, (lbl, desc) in enumerate(controls):
            l_surf = self.font_info_bold.render(lbl, True, (255, 215, 80))
            d_surf = self.font_info.render(desc, True, COLOR_WHITE)
            surface.blit(l_surf, (panel_rect.x + 20, panel_rect.y + 16 + idx * 42))
            surface.blit(d_surf, (panel_rect.x + 320, panel_rect.y + 16 + idx * 42))

        # 5. Primary Action Buttons ("CHƠI MỚI", "TIẾP TỤC TRÒ CHƠI", "THOÁT GAME")
        # Nút CHƠI MỚI
        is_hover_start = self.start_btn_rect.collidepoint(virtual_mouse_pos)
        start_col = COLOR_GREEN_BTN_HOVER if is_hover_start else COLOR_GREEN_BTN
        pygame.draw.rect(surface, start_col, self.start_btn_rect, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.start_btn_rect, 2, border_radius=8)
        start_txt = self.font_btn.render("CHƠI MỚI", True, COLOR_WHITE)
        surface.blit(start_txt, (self.start_btn_rect.centerx - start_txt.get_width() // 2, self.start_btn_rect.centery - start_txt.get_height() // 2))

        # Nút TIẾP TỤC TRÒ CHƠI (Active when session exists)
        has_session = game_state.has_saved_session
        is_hover_res = self.resume_btn_rect.collidepoint(virtual_mouse_pos) if has_session else False
        if has_session:
            res_col = COLOR_BLUE_BTN_HOVER if is_hover_res else COLOR_BLUE_BTN
            text_col = COLOR_WHITE
            border_col = (255, 255, 255)
        else:
            res_col = (50, 55, 65)
            text_col = (130, 135, 145)
            border_col = (80, 85, 95)

        pygame.draw.rect(surface, res_col, self.resume_btn_rect, border_radius=8)
        pygame.draw.rect(surface, border_col, self.resume_btn_rect, 2, border_radius=8)
        res_txt = self.font_btn.render("TIẾP TỤC TRÒ CHƠI", True, text_col)
        surface.blit(res_txt, (self.resume_btn_rect.centerx - res_txt.get_width() // 2, self.resume_btn_rect.centery - res_txt.get_height() // 2))

        # Nút THOÁT GAME (Q)
        is_hover_quit = self.quit_btn_rect.collidepoint(virtual_mouse_pos)
        quit_col = COLOR_RED_BTN_HOVER if is_hover_quit else COLOR_RED_BTN
        pygame.draw.rect(surface, quit_col, self.quit_btn_rect, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.quit_btn_rect, 2, border_radius=8)
        quit_txt = self.font_btn.render("THOÁT GAME (Q)", True, COLOR_WHITE)
        surface.blit(quit_txt, (self.quit_btn_rect.centerx - quit_txt.get_width() // 2, self.quit_btn_rect.centery - quit_txt.get_height() // 2))

        # 6. Audio Controls Row
        bgm_txt = "NHẠC NỀN: BẬT" if not self.sound.is_bgm_muted else "NHẠC NỀN: TẮT"
        bgm_col = (46, 120, 70) if not self.sound.is_bgm_muted else (110, 50, 50)
        pygame.draw.rect(surface, bgm_col, self.bgm_btn_rect, border_radius=8)
        pygame.draw.rect(surface, (200, 200, 200), self.bgm_btn_rect, 1, border_radius=8)
        b_surf = self.font_btn_sm.render(bgm_txt, True, COLOR_WHITE)
        surface.blit(b_surf, (self.bgm_btn_rect.centerx - b_surf.get_width() // 2, self.bgm_btn_rect.centery - b_surf.get_height() // 2))

        sfx_txt = "HIỆU ỨNG: BẬT" if not self.sound.is_sfx_muted else "HIỆU ỨNG: TẮT"
        sfx_col = (46, 120, 70) if not self.sound.is_sfx_muted else (110, 50, 50)
        pygame.draw.rect(surface, sfx_col, self.sfx_btn_rect, border_radius=8)
        pygame.draw.rect(surface, (200, 200, 200), self.sfx_btn_rect, 1, border_radius=8)
        s_surf = self.font_btn_sm.render(sfx_txt, True, COLOR_WHITE)
        surface.blit(s_surf, (self.sfx_btn_rect.centerx - s_surf.get_width() // 2, self.sfx_btn_rect.centery - s_surf.get_height() // 2))

        # Vol -
        pygame.draw.rect(surface, (50, 60, 80), self.vol_down_rect, border_radius=8)
        vd_txt = self.font_btn_sm.render("-", True, COLOR_WHITE)
        surface.blit(vd_txt, (self.vol_down_rect.centerx - vd_txt.get_width() // 2, self.vol_down_rect.centery - vd_txt.get_height() // 2))

        # Vol %
        vol_pct = int(self.sound.volume_level * 100)
        vol_lbl = self.font_btn_sm.render(f"ÂM LƯỢNG: {vol_pct}%", True, (240, 240, 240))
        surface.blit(vol_lbl, (VIRTUAL_WIDTH // 2 + 82, 510))

        # Vol +
        pygame.draw.rect(surface, (50, 60, 80), self.vol_up_rect, border_radius=8)
        vu_txt = self.font_btn_sm.render("+", True, COLOR_WHITE)
        surface.blit(vu_txt, (self.vol_up_rect.centerx - vu_txt.get_width() // 2, self.vol_up_rect.centery - vu_txt.get_height() // 2))

        # 7. Aspect Ratio / Fullscreen Bar
        if screen_manager:
            ar_lbl = self.font_btn_sm.render("CHẾ ĐỘ MÀN HÌNH (Phím F11 / Phím 1, 2, 3):", True, (255, 215, 120))
            surface.blit(ar_lbl, (VIRTUAL_WIDTH // 2 - ar_lbl.get_width() // 2, 580))

            modes = [
                (self.preset_btn_16_9, "16:9 DESKTOP", screen_manager.current_preset_index == 0 and not screen_manager.is_fullscreen),
                (self.preset_btn_9_16, "9:16 MOBILE", screen_manager.current_preset_index == 1 and not screen_manager.is_fullscreen),
                (self.preset_btn_3_4,  "3:4 TABLET", screen_manager.current_preset_index == 2 and not screen_manager.is_fullscreen),
                (self.fullscreen_btn,  "TOÀN MÀN HÌNH", screen_manager.is_fullscreen)
            ]

            for rect, text, is_active in modes:
                hover = rect.collidepoint(virtual_mouse_pos)
                if is_active:
                    bg_col = (46, 204, 113)
                elif hover:
                    bg_col = (52, 152, 219)
                else:
                    bg_col = (45, 55, 75)
                
                pygame.draw.rect(surface, bg_col, rect, border_radius=8)
                pygame.draw.rect(surface, (200, 200, 220), rect, 1, border_radius=8)
                t_surf = self.font_btn_sm.render(text, True, COLOR_WHITE)
                surface.blit(t_surf, (rect.centerx - t_surf.get_width() // 2, rect.centery - t_surf.get_height() // 2))
