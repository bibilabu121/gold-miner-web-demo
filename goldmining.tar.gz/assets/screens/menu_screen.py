"""
Menu Screen Controller: Main menu UI with New Game, Resume Session, Audio Controls,
and strictly verified keyboard/mouse controls guidance.
Optimized for fixed 16:9 display with all mode/fullscreen buttons completely removed.
"""
import sys
import pygame
from constants import (
    GameStates, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER,
    COLOR_RED_BTN, COLOR_RED_BTN_HOVER,
    COLOR_BLUE_BTN, COLOR_BLUE_BTN_HOVER,
    COLOR_PANEL_BG, COLOR_PANEL_BORDER,
    COLOR_SKY_TOP, COLOR_SKY_BOTTOM,
    COLOR_GROUND_DIRT_TOP, COLOR_GROUND_DIRT_MID,
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, get_font
)
from sound_manager import SoundManager

class MenuScreen:
    """Manages Main Menu layout, Resume Game button, and Audio settings."""
    def __init__(self):
        self.sound_manager = SoundManager.get_instance()
        self.anim_time = 0.0

    def update(self, dt: float):
        self.anim_time += dt

    def handle_event(self, event, game_state, screen_manager, play_screen=None) -> str:
        # Exit on Q key
        if event.type == pygame.KEYDOWN and event.key == pygame.K_q:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            cx = VIRTUAL_WIDTH // 2

            # 1. PLAY BUTTON ("CHƠI MỚI")
            play_btn_rect = pygame.Rect(cx - 150, 240, 300, 52)
            if play_btn_rect.collidepoint((mx, my)):
                self.sound_manager.play('click')
                game_state.reset_to_start()
                return GameStates.PLAYING

            # 2. RESUME BUTTON ("TIẾP TỤC TRÒ CHƠI")
            if game_state.has_saved_session:
                resume_btn_rect = pygame.Rect(cx - 150, 305, 300, 52)
                if resume_btn_rect.collidepoint((mx, my)):
                    self.sound_manager.play('click')
                    return GameStates.PLAYING

            # 3. AUDIO CONTROLS
            # BGM Toggle Button
            bgm_btn_rect = pygame.Rect(cx - 240, 375, 230, 44)
            if bgm_btn_rect.collidepoint((mx, my)):
                self.sound_manager.toggle_bgm()
                self.sound_manager.play('click')
                return GameStates.MENU

            # SFX Toggle Button
            sfx_btn_rect = pygame.Rect(cx + 10, 375, 230, 44)
            if sfx_btn_rect.collidepoint((mx, my)):
                self.sound_manager.toggle_sfx()
                self.sound_manager.play('click')
                return GameStates.MENU

            # Volume Down (-) Button
            vol_down_rect = pygame.Rect(cx - 160, 430, 40, 36)
            if vol_down_rect.collidepoint((mx, my)):
                self.sound_manager.decrease_volume(0.1)
                self.sound_manager.play('click')
                return GameStates.MENU

            # Volume Up (+) Button
            vol_up_rect = pygame.Rect(cx + 120, 430, 40, 36)
            if vol_up_rect.collidepoint((mx, my)):
                self.sound_manager.increase_volume(0.1)
                self.sound_manager.play('click')
                return GameStates.MENU

            # 4. EXIT BUTTON ("THOÁT GAME")
            exit_btn_rect = pygame.Rect(cx - 150, 480, 300, 46)
            if exit_btn_rect.collidepoint((mx, my)):
                self.sound_manager.play('click')
                pygame.quit()
                sys.exit()

        return GameStates.MENU

    def draw(self, surface: pygame.Surface, game_state, screen_manager, mouse_pos: tuple = (0, 0)):
        # Draw Scenery Background
        for y in range(0, 140):
            ratio = y / 140.0
            r = int(COLOR_SKY_TOP[0] * (1 - ratio) + COLOR_SKY_BOTTOM[0] * ratio)
            g = int(COLOR_SKY_TOP[1] * (1 - ratio) + COLOR_SKY_BOTTOM[1] * ratio)
            b = int(COLOR_SKY_TOP[2] * (1 - ratio) + COLOR_SKY_BOTTOM[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        for y in range(140, VIRTUAL_HEIGHT):
            ratio = (y - 140) / (VIRTUAL_HEIGHT - 140)
            r = int(COLOR_GROUND_DIRT_TOP[0] * (1 - ratio) + COLOR_GROUND_DIRT_MID[0] * ratio)
            g = int(COLOR_GROUND_DIRT_TOP[1] * (1 - ratio) + COLOR_GROUND_DIRT_MID[1] * ratio)
            b = int(COLOR_GROUND_DIRT_TOP[2] * (1 - ratio) + COLOR_GROUND_DIRT_MID[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        cx = VIRTUAL_WIDTH // 2
        mx, my = mouse_pos

        # Main Title Banner
        title_font = get_font(54, bold=True)
        title_surf = title_font.render("ĐÀO VÀNG SIÊU CẤP", True, COLOR_GOLD_TEXT)
        title_shadow = title_font.render("ĐÀO VÀNG SIÊU CẤP", True, (40, 25, 10))
        surface.blit(title_shadow, (cx - title_surf.get_width() // 2 + 3, 48 + 3))
        surface.blit(title_surf, (cx - title_surf.get_width() // 2, 48))

        sub_font = get_font(20, bold=False)
        sub_surf = sub_font.render("Phiên bản WebAssembly HTML5 & Desktop", True, COLOR_WHITE)
        surface.blit(sub_surf, (cx - sub_surf.get_width() // 2, 112))

        # Main Menu Central Panel
        panel_rect = pygame.Rect(cx - 300, 160, 600, 520)
        panel_bg = pygame.Surface((panel_rect.width, panel_rect.height), pygame.SRCALPHA)
        panel_bg.fill(COLOR_PANEL_BG)
        surface.blit(panel_bg, panel_rect.topleft)
        pygame.draw.rect(surface, COLOR_PANEL_BORDER, panel_rect, width=2, border_radius=12)

        # 1. BUTTON: "CHƠI MỚI"
        play_btn_rect = pygame.Rect(cx - 150, 185, 300, 50)
        is_hover_play = play_btn_rect.collidepoint((mx, my))
        play_col = COLOR_GREEN_BTN_HOVER if is_hover_play else COLOR_GREEN_BTN
        pygame.draw.rect(surface, play_col, play_btn_rect, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, play_btn_rect, width=2, border_radius=8)

        btn_font = get_font(22, bold=True)
        play_text = btn_font.render("CHƠI MỚI", True, COLOR_WHITE)
        surface.blit(play_text, (cx - play_text.get_width() // 2, play_btn_rect.centery - play_text.get_height() // 2))

        # 2. BUTTON: "TIẾP TỤC TRÒ CHƠI" (Only active when a session is active)
        resume_btn_rect = pygame.Rect(cx - 150, 245, 300, 50)
        has_session = game_state.has_saved_session
        if has_session:
            is_hover_res = resume_btn_rect.collidepoint((mx, my))
            res_col = COLOR_BLUE_BTN_HOVER if is_hover_res else COLOR_BLUE_BTN
            pygame.draw.rect(surface, res_col, resume_btn_rect, border_radius=8)
            pygame.draw.rect(surface, COLOR_WHITE, resume_btn_rect, width=2, border_radius=8)
            res_text = btn_font.render("TIẾP TỤC TRÒ CHƠI", True, COLOR_WHITE)
        else:
            pygame.draw.rect(surface, (70, 70, 75), resume_btn_rect, border_radius=8)
            pygame.draw.rect(surface, (100, 100, 105), resume_btn_rect, width=1, border_radius=8)
            res_text = btn_font.render("TIẾP TỤC TRÒ CHƠI", True, (140, 140, 145))
        surface.blit(res_text, (cx - res_text.get_width() // 2, resume_btn_rect.centery - res_text.get_height() // 2))

        # 3. AUDIO CONTROLS
        audio_title_font = get_font(18, bold=True)
        audio_title = audio_title_font.render("CÀI ĐẶT ÂM THANH:", True, COLOR_GOLD_TEXT)
        surface.blit(audio_title, (cx - audio_title.get_width() // 2, 310))

        # BGM Toggle
        bgm_btn_rect = pygame.Rect(cx - 240, 340, 230, 42)
        is_hover_bgm = bgm_btn_rect.collidepoint((mx, my))
        bgm_col = (50, 120, 80) if not self.sound_manager.is_bgm_muted else (110, 50, 50)
        if is_hover_bgm:
            bgm_col = (65, 150, 100) if not self.sound_manager.is_bgm_muted else (140, 65, 65)
        pygame.draw.rect(surface, bgm_col, bgm_btn_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, bgm_btn_rect, width=1, border_radius=6)
        bgm_status = "BẬT" if not self.sound_manager.is_bgm_muted else "TẮT"
        bgm_txt = get_font(16, bold=True).render(f"NHẠC NỀN (BGM): {bgm_status}", True, COLOR_WHITE)
        surface.blit(bgm_txt, (bgm_btn_rect.centerx - bgm_txt.get_width() // 2, bgm_btn_rect.centery - bgm_txt.get_height() // 2))

        # SFX Toggle
        sfx_btn_rect = pygame.Rect(cx + 10, 340, 230, 42)
        is_hover_sfx = sfx_btn_rect.collidepoint((mx, my))
        sfx_col = (50, 120, 80) if not self.sound_manager.is_sfx_muted else (110, 50, 50)
        if is_hover_sfx:
            sfx_col = (65, 150, 100) if not self.sound_manager.is_sfx_muted else (140, 65, 65)
        pygame.draw.rect(surface, sfx_col, sfx_btn_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, sfx_btn_rect, width=1, border_radius=6)
        sfx_status = "BẬT" if not self.sound_manager.is_sfx_muted else "TẮT"
        sfx_txt = get_font(16, bold=True).render(f"HIỆU ỨNG (SFX): {sfx_status}", True, COLOR_WHITE)
        surface.blit(sfx_txt, (sfx_btn_rect.centerx - sfx_txt.get_width() // 2, sfx_btn_rect.centery - sfx_txt.get_height() // 2))

        # Master Volume Bar
        vol_down_rect = pygame.Rect(cx - 150, 395, 36, 32)
        vol_up_rect = pygame.Rect(cx + 114, 395, 36, 32)
        
        pygame.draw.rect(surface, (60, 60, 70), vol_down_rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, vol_down_rect, width=1, border_radius=4)
        minus_txt = get_font(18, bold=True).render("-", True, COLOR_WHITE)
        surface.blit(minus_txt, (vol_down_rect.centerx - minus_txt.get_width() // 2, vol_down_rect.centery - minus_txt.get_height() // 2))

        pygame.draw.rect(surface, (60, 60, 70), vol_up_rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, vol_up_rect, width=1, border_radius=4)
        plus_txt = get_font(18, bold=True).render("+", True, COLOR_WHITE)
        surface.blit(plus_txt, (vol_up_rect.centerx - plus_txt.get_width() // 2, vol_up_rect.centery - plus_txt.get_height() // 2))

        vol_bar_bg = pygame.Rect(cx - 100, 403, 200, 16)
        pygame.draw.rect(surface, (30, 30, 35), vol_bar_bg, border_radius=4)
        vol_width = int(200 * self.sound_manager.volume_level)
        if vol_width > 0:
            vol_bar_fill = pygame.Rect(cx - 100, 403, vol_width, 16)
            pygame.draw.rect(surface, COLOR_GOLD_TEXT, vol_bar_fill, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, vol_bar_bg, width=1, border_radius=4)

        vol_pct_txt = get_font(13, bold=True).render(f"ÂM LƯỢNG: {int(self.sound_manager.volume_level * 100)}%", True, COLOR_WHITE)
        surface.blit(vol_pct_txt, (cx - vol_pct_txt.get_width() // 2, 424))

        # 4. BUTTON: "THOÁT GAME (Q)"
        exit_btn_rect = pygame.Rect(cx - 150, 452, 300, 44)
        is_hover_exit = exit_btn_rect.collidepoint((mx, my))
        exit_col = COLOR_RED_BTN_HOVER if is_hover_exit else COLOR_RED_BTN
        pygame.draw.rect(surface, exit_col, exit_btn_rect, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, exit_btn_rect, width=2, border_radius=8)
        exit_text = btn_font.render("THOÁT GAME (Q)", True, COLOR_WHITE)
        surface.blit(exit_text, (cx - exit_text.get_width() // 2, exit_btn_rect.centery - exit_text.get_height() // 2))

        # 5. CONTROLS GUIDE (Exact Text Parity)
        guide_box = pygame.Rect(cx - 270, 510, 540, 155)
        pygame.draw.rect(surface, (15, 12, 10, 200), guide_box, border_radius=8)
        pygame.draw.rect(surface, (150, 110, 60), guide_box, width=1, border_radius=8)

        guide_font = get_font(15, bold=False)
        guide_header = get_font(16, bold=True).render("HƯỚNG DẪN ĐIỀU KHIỂN CHUẨN XÁC:", True, COLOR_GOLD_TEXT)
        surface.blit(guide_header, (cx - guide_header.get_width() // 2, 520))

        line1 = guide_font.render("Phím [ Chuột trái ] hoặc [ SPACE ] : Thả móc ngoắm / Bắn móc", True, COLOR_WHITE)
        line2 = guide_font.render("Phím [ Chuột phải ] : Ném Bom phá hủy vật phẩm khi đang kéo", True, COLOR_WHITE)
        line3 = guide_font.render("Phím [ ESC ] : Tạm dừng trận đấu", True, COLOR_WHITE)
        line4 = guide_font.render("Phím [ Q ] : Thoát game nhanh", True, (200, 200, 200))

        surface.blit(line1, (cx - line1.get_width() // 2, 550))
        surface.blit(line2, (cx - line2.get_width() // 2, 576))
        surface.blit(line3, (cx - line3.get_width() // 2, 602))
        surface.blit(line4, (cx - line4.get_width() // 2, 628))
