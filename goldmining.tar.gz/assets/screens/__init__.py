"""
Screens package for Gold Miner UI and states.
"""
