"""
Menu Screen Controller: Main menu UI with New Game, Resume Session, Audio Controls,
and strictly verified keyboard/mouse controls guidance.
Unified Rect architecture ensuring 100% precision between event hitboxes and visuals.
"""
import sys
import pygame
from constants import (
    GameStates, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER,
    COLOR_RED_BTN, COLOR_RED_BTN_HOVER,
    COLOR_BLUE_BTN, COLOR_BLUE_BTN_HOVER,
    COLOR_PANEL_BG, COLOR_PANEL_BORDER,
    COLOR_SKY_TOP, COLOR_SKY_BOTTOM,
    COLOR_GROUND_DIRT_TOP, COLOR_GROUND_DIRT_MID,
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, get_font
)
from sound_manager import SoundManager

class MenuScreen:
    """Manages Main Menu layout, Resume Game button, and Audio settings."""
    def __init__(self):
        self.sound_manager = SoundManager.get_instance()
        self.anim_time = 0.0

        cx = VIRTUAL_WIDTH // 2
        # Unified Rect definitions shared by BOTH handle_event() and draw()
        self.panel_rect = pygame.Rect(cx - 300, 160, 600, 520)
        self.play_btn_rect = pygame.Rect(cx - 150, 185, 300, 50)
        self.resume_btn_rect = pygame.Rect(cx - 150, 245, 300, 50)
        
        self.bgm_btn_rect = pygame.Rect(cx - 240, 340, 230, 42)
        self.sfx_btn_rect = pygame.Rect(cx + 10, 340, 230, 42)
        
        self.vol_down_rect = pygame.Rect(cx - 150, 395, 36, 32)
        self.vol_up_rect = pygame.Rect(cx + 114, 395, 36, 32)
        self.vol_bar_bg = pygame.Rect(cx - 100, 403, 200, 16)
        
        self.exit_btn_rect = pygame.Rect(cx - 150, 452, 300, 44)
        self.guide_box = pygame.Rect(cx - 270, 510, 540, 155)

        # Fonts
        self.title_font = get_font(54, bold=True)
        self.sub_font = get_font(20, bold=False)
        self.btn_font = get_font(22, bold=True)
        self.audio_title_font = get_font(18, bold=True)
        self.audio_btn_font = get_font(16, bold=True)
        self.vol_btn_font = get_font(18, bold=True)
        self.vol_pct_font = get_font(13, bold=True)
        self.guide_hdr_font = get_font(16, bold=True)
        self.guide_font = get_font(15, bold=False)

    def update(self, dt: float):
        self.anim_time += dt

    def handle_event(self, event, game_state, screen_manager, play_screen=None) -> str:
        # Exit on Q key
        if event.type == pygame.KEYDOWN and event.key == pygame.K_q:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos

            # 1. PLAY BUTTON ("CHƠI MỚI")
            if self.play_btn_rect.collidepoint((mx, my)):
                self.sound_manager.play('click')
                game_state.start_game()
                return GameStates.PLAYING

            # 2. RESUME BUTTON ("TIẾP TỤC TRÒ CHƠI")
            if game_state.has_saved_session and self.resume_btn_rect.collidepoint((mx, my)):
                self.sound_manager.play('click')
                return GameStates.PLAYING

            # 3. AUDIO CONTROLS
            # BGM Toggle Button
            if self.bgm_btn_rect.collidepoint((mx, my)):
                self.sound_manager.toggle_bgm()
                self.sound_manager.play('click')
                return GameStates.MENU

            # SFX Toggle Button
            if self.sfx_btn_rect.collidepoint((mx, my)):
                self.sound_manager.toggle_sfx()
                self.sound_manager.play('click')
                return GameStates.MENU

            # Volume Down (-) Button
            if self.vol_down_rect.collidepoint((mx, my)):
                self.sound_manager.decrease_volume(0.1)
                self.sound_manager.play('click')
                return GameStates.MENU

            # Volume Up (+) Button
            if self.vol_up_rect.collidepoint((mx, my)):
                self.sound_manager.increase_volume(0.1)
                self.sound_manager.play('click')
                return GameStates.MENU

            # 4. EXIT BUTTON ("THOÁT GAME")
            if self.exit_btn_rect.collidepoint((mx, my)):
                self.sound_manager.play('click')
                pygame.quit()
                sys.exit()

        return GameStates.MENU

    def draw(self, surface: pygame.Surface, game_state, screen_manager, mouse_pos: tuple = (0, 0)):
        cx = VIRTUAL_WIDTH // 2
        mx, my = mouse_pos

        # Draw Scenery Background
        for y in range(0, 140):
            ratio = y / 140.0
            r = int(COLOR_SKY_TOP[0] * (1 - ratio) + COLOR_SKY_BOTTOM[0] * ratio)
            g = int(COLOR_SKY_TOP[1] * (1 - ratio) + COLOR_SKY_BOTTOM[1] * ratio)
            b = int(COLOR_SKY_TOP[2] * (1 - ratio) + COLOR_SKY_BOTTOM[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        for y in range(140, VIRTUAL_HEIGHT):
            ratio = (y - 140) / (VIRTUAL_HEIGHT - 140)
            r = int(COLOR_GROUND_DIRT_TOP[0] * (1 - ratio) + COLOR_GROUND_DIRT_MID[0] * ratio)
            g = int(COLOR_GROUND_DIRT_TOP[1] * (1 - ratio) + COLOR_GROUND_DIRT_MID[1] * ratio)
            b = int(COLOR_GROUND_DIRT_TOP[2] * (1 - ratio) + COLOR_GROUND_DIRT_MID[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        # Main Title Banner
        title_surf = self.title_font.render("ĐÀO VÀNG SIÊU CẤP", True, COLOR_GOLD_TEXT)
        title_shadow = self.title_font.render("ĐÀO VÀNG SIÊU CẤP", True, (40, 25, 10))
        surface.blit(title_shadow, (cx - title_surf.get_width() // 2 + 3, 48 + 3))
        surface.blit(title_surf, (cx - title_surf.get_width() // 2, 48))

        sub_surf = self.sub_font.render("Phiên bản WebAssembly HTML5 & Desktop", True, COLOR_WHITE)
        surface.blit(sub_surf, (cx - sub_surf.get_width() // 2, 112))

        # Main Menu Central Panel
        panel_bg = pygame.Surface((self.panel_rect.width, self.panel_rect.height), pygame.SRCALPHA)
        panel_bg.fill(COLOR_PANEL_BG)
        surface.blit(panel_bg, self.panel_rect.topleft)
        pygame.draw.rect(surface, COLOR_PANEL_BORDER, self.panel_rect, width=2, border_radius=12)

        # 1. BUTTON: "CHƠI MỚI"
        is_hover_play = self.play_btn_rect.collidepoint((mx, my))
        play_col = COLOR_GREEN_BTN_HOVER if is_hover_play else COLOR_GREEN_BTN
        pygame.draw.rect(surface, play_col, self.play_btn_rect, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.play_btn_rect, width=2, border_radius=8)

        play_text = self.btn_font.render("CHƠI MỚI", True, COLOR_WHITE)
        surface.blit(play_text, (self.play_btn_rect.centerx - play_text.get_width() // 2, self.play_btn_rect.centery - play_text.get_height() // 2))

        # 2. BUTTON: "TIẾP TỤC TRÒ CHƠI" (Only active when a session is active)
        has_session = game_state.has_saved_session
        if has_session:
            is_hover_res = self.resume_btn_rect.collidepoint((mx, my))
            res_col = COLOR_BLUE_BTN_HOVER if is_hover_res else COLOR_BLUE_BTN
            pygame.draw.rect(surface, res_col, self.resume_btn_rect, border_radius=8)
            pygame.draw.rect(surface, COLOR_WHITE, self.resume_btn_rect, width=2, border_radius=8)
            res_text = self.btn_font.render("TIẾP TỤC TRÒ CHƠI", True, COLOR_WHITE)
        else:
            pygame.draw.rect(surface, (70, 70, 75), self.resume_btn_rect, border_radius=8)
            pygame.draw.rect(surface, (100, 100, 105), self.resume_btn_rect, width=1, border_radius=8)
            res_text = self.btn_font.render("TIẾP TỤC TRÒ CHƠI", True, (140, 140, 145))
        surface.blit(res_text, (self.resume_btn_rect.centerx - res_text.get_width() // 2, self.resume_btn_rect.centery - res_text.get_height() // 2))

        # 3. AUDIO CONTROLS
        audio_title = self.audio_title_font.render("CÀI ĐẶT ÂM THANH:", True, COLOR_GOLD_TEXT)
        surface.blit(audio_title, (cx - audio_title.get_width() // 2, 310))

        # BGM Toggle
        is_hover_bgm = self.bgm_btn_rect.collidepoint((mx, my))
        bgm_col = (50, 120, 80) if not self.sound_manager.is_bgm_muted else (110, 50, 50)
        if is_hover_bgm:
            bgm_col = (65, 150, 100) if not self.sound_manager.is_bgm_muted else (140, 65, 65)
        pygame.draw.rect(surface, bgm_col, self.bgm_btn_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, self.bgm_btn_rect, width=1, border_radius=6)
        bgm_status = "BẬT" if not self.sound_manager.is_bgm_muted else "TẮT"
        bgm_txt = self.audio_btn_font.render(f"NHẠC NỀN (BGM): {bgm_status}", True, COLOR_WHITE)
        surface.blit(bgm_txt, (self.bgm_btn_rect.centerx - bgm_txt.get_width() // 2, self.bgm_btn_rect.centery - bgm_txt.get_height() // 2))

        # SFX Toggle
        is_hover_sfx = self.sfx_btn_rect.collidepoint((mx, my))
        sfx_col = (50, 120, 80) if not self.sound_manager.is_sfx_muted else (110, 50, 50)
        if is_hover_sfx:
            sfx_col = (65, 150, 100) if not self.sound_manager.is_sfx_muted else (140, 65, 65)
        pygame.draw.rect(surface, sfx_col, self.sfx_btn_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, self.sfx_btn_rect, width=1, border_radius=6)
        sfx_status = "BẬT" if not self.sound_manager.is_sfx_muted else "TẮT"
        sfx_txt = self.audio_btn_font.render(f"HIỆU ỨNG (SFX): {sfx_status}", True, COLOR_WHITE)
        surface.blit(sfx_txt, (self.sfx_btn_rect.centerx - sfx_txt.get_width() // 2, self.sfx_btn_rect.centery - sfx_txt.get_height() // 2))

        # Master Volume Bar
        pygame.draw.rect(surface, (60, 60, 70), self.vol_down_rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, self.vol_down_rect, width=1, border_radius=4)
        minus_txt = self.vol_btn_font.render("-", True, COLOR_WHITE)
        surface.blit(minus_txt, (self.vol_down_rect.centerx - minus_txt.get_width() // 2, self.vol_down_rect.centery - minus_txt.get_height() // 2))

        pygame.draw.rect(surface, (60, 60, 70), self.vol_up_rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, self.vol_up_rect, width=1, border_radius=4)
        plus_txt = self.vol_btn_font.render("+", True, COLOR_WHITE)
        surface.blit(plus_txt, (self.vol_up_rect.centerx - plus_txt.get_width() // 2, self.vol_up_rect.centery - plus_txt.get_height() // 2))

        pygame.draw.rect(surface, (30, 30, 35), self.vol_bar_bg, border_radius=4)
        vol_width = int(200 * self.sound_manager.volume_level)
        if vol_width > 0:
            vol_bar_fill = pygame.Rect(self.vol_bar_bg.x, self.vol_bar_bg.y, vol_width, self.vol_bar_bg.height)
            pygame.draw.rect(surface, COLOR_GOLD_TEXT, vol_bar_fill, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, self.vol_bar_bg, width=1, border_radius=4)

        vol_pct_txt = self.vol_pct_font.render(f"ÂM LƯỢNG: {int(self.sound_manager.volume_level * 100)}%", True, COLOR_WHITE)
        surface.blit(vol_pct_txt, (cx - vol_pct_txt.get_width() // 2, 424))

        # 4. BUTTON: "THOÁT GAME (Q)"
        is_hover_exit = self.exit_btn_rect.collidepoint((mx, my))
        exit_col = COLOR_RED_BTN_HOVER if is_hover_exit else COLOR_RED_BTN
        pygame.draw.rect(surface, exit_col, self.exit_btn_rect, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.exit_btn_rect, width=2, border_radius=8)
        exit_text = self.btn_font.render("THOÁT GAME (Q)", True, COLOR_WHITE)
        surface.blit(exit_text, (self.exit_btn_rect.centerx - exit_text.get_width() // 2, self.exit_btn_rect.centery - exit_text.get_height() // 2))

        # 5. CONTROLS GUIDE (Exact Text Parity)
        pygame.draw.rect(surface, (15, 12, 10, 200), self.guide_box, border_radius=8)
        pygame.draw.rect(surface, (150, 110, 60), self.guide_box, width=1, border_radius=8)

        guide_header = self.guide_hdr_font.render("HƯỚNG DẪN ĐIỀU KHIỂN CHUẨN XÁC:", True, COLOR_GOLD_TEXT)
        surface.blit(guide_header, (cx - guide_header.get_width() // 2, 520))

        line1 = self.guide_font.render("Phím [ Chuột trái ] hoặc [ SPACE ] : Thả móc ngoắm / Bắn móc", True, COLOR_WHITE)
        line2 = self.guide_font.render("Phím [ Chuột phải ] : Ném Bom phá hủy vật phẩm khi đang kéo", True, COLOR_WHITE)
        line3 = self.guide_font.render("Phím [ ESC ] : Tạm dừng trận đấu", True, COLOR_WHITE)
        line4 = self.guide_font.render("Phím [ Q ] : Thoát game nhanh", True, (200, 200, 200))

        surface.blit(line1, (cx - line1.get_width() // 2, 550))
        surface.blit(line2, (cx - line2.get_width() // 2, 576))
        surface.blit(line3, (cx - line3.get_width() // 2, 602))
        surface.blit(line4, (cx - line4.get_width() // 2, 628))
