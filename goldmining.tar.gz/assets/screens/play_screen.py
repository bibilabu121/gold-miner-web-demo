"""
Play Screen Controller: In-game level execution, HUD rendering, hook interaction,
Strict Time-Up Rule, physics loop, floating particle effects, and accurate level statistics.
Rendered on 1280x720 Virtual Canvas with high resolution and crisp Unicode typography.
"""
import pygame
from constants import (
    GameStates, VIRTUAL_WIDTH, VIRTUAL_HEIGHT, GROUND_Y,
    COLOR_WHITE, COLOR_GOLD_TEXT, COLOR_HUD_BG, COLOR_HUD_BORDER,
    COLOR_SKY_TOP, COLOR_SKY_BOTTOM, COLOR_GROUND_DIRT_TOP, COLOR_GROUND_DIRT_MID,
    get_font
)
from entities.hook import Hook
from entities.miner import Miner
from entities.effects import EffectManager
from level_generator import generate_level
from sound_manager import SoundManager

class PlayScreen:
    """Manages active mining gameplay, entity updates, and HUD drawing."""
    def __init__(self):
        self.hook = Hook()
        self.miner = Miner()
        self.items = []
        self.effect_manager = EffectManager()
        self.sound = SoundManager.get_instance()

        # Pre-calculated HUD Button Rectangles
        self.pause_btn_rect = pygame.Rect(VIRTUAL_WIDTH - 150, 10, 135, 42)

        # Fonts
        self.hud_font = get_font(18, bold=True)
        self.hud_bold = get_font(22, bold=True)
        self.timer_font = get_font(24, bold=True)

    def start_level(self, game_state):
        """Generates level items and initializes miner/hook states for current level."""
        self.items = generate_level(game_state.current_level)
        self.hook.reset()
        self.miner.reset()
        self.effect_manager.clear()
        self.sound.start_bgm()

    def handle_event(self, event, game_state, screen_manager=None) -> str:
        """Processes player inputs strictly according to input parity specifications."""
        # 1. Keyboard Inputs
        if event.type == pygame.KEYDOWN:
            # ESC: Pause Modal ONLY
            if event.key == pygame.K_ESCAPE:
                self.sound.play('click')
                return GameStates.PAUSE

            # SPACE: Shoot Hook
            elif event.key == pygame.K_SPACE:
                self.hook.shoot()

        # 2. Mouse Click Inputs
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # Left Mouse Click
            if event.button == 1:
                mx, my = event.pos

                # Check HUD "TẠM DỪNG" button
                if self.pause_btn_rect.collidepoint((mx, my)):
                    self.sound.play('click')
                    return GameStates.PAUSE
                else:
                    # Shoot hook via Left Click
                    self.hook.shoot()

            # Right Mouse Click (Bomb ONLY)
            elif event.button == 3:
                self.hook.throw_bomb(game_state, self.effect_manager)

        return GameStates.PLAYING

    def update(self, dt: float, game_state) -> str:
        """Runs 60 FPS physics updates, collision checks, entity movements, and strict time limit."""
        # 1. Strict Time Up Rule: Level ends immediately when timer <= 0
        game_state.level_timer -= dt
        if game_state.is_time_up():
            game_state.level_timer = 0.0
            self.sound.stop_bgm()
            
            # Cancel pulling and destroy caught item immediately
            if self.hook.caught_item:
                self.hook.caught_item = None
            self.hook.reset()

            # Determine Win or Game Over (Do NOT call next_level here - preserves level summary stats!)
            if game_state.is_level_won():
                self.sound.play('level_win')
                return GameStates.LEVEL_WIN
            else:
                self.sound.play('game_over')
                return GameStates.GAME_OVER

        # 2. Update Moving Entities (Boars)
        for item in self.items:
            if hasattr(item, 'update'):
                item.update(dt)

        # 3. Update Hook Physics & Collision Detection
        self.hook.update(dt, self.items, game_state, self.effect_manager)

        # 4. Update Miner Animations
        self.miner.update(dt, self.hook.state)

        # 5. Update Particle & Floating Text Effects
        self.effect_manager.update(dt)

        # 6. Clean up destroyed/collected items
        self.items = [item for item in self.items if getattr(item, 'is_alive', True)]

        return GameStates.PLAYING

    def draw(self, surface: pygame.Surface, game_state, virtual_mouse_pos: tuple = (0, 0)):
        """Renders underground scenery, items, miner, hook, effects, and HUD bar."""
        # 1. Draw Scenery Background (Sky above GROUND_Y, Dirt below GROUND_Y)
        for y in range(0, GROUND_Y):
            ratio = y / float(GROUND_Y)
            r = int(COLOR_SKY_TOP[0] * (1 - ratio) + COLOR_SKY_BOTTOM[0] * ratio)
            g = int(COLOR_SKY_TOP[1] * (1 - ratio) + COLOR_SKY_BOTTOM[1] * ratio)
            b = int(COLOR_SKY_TOP[2] * (1 - ratio) + COLOR_SKY_BOTTOM[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        for y in range(GROUND_Y, VIRTUAL_HEIGHT):
            ratio = (y - GROUND_Y) / float(VIRTUAL_HEIGHT - GROUND_Y)
            r = int(COLOR_GROUND_DIRT_TOP[0] * (1 - ratio) + COLOR_GROUND_DIRT_MID[0] * ratio)
            g = int(COLOR_GROUND_DIRT_TOP[1] * (1 - ratio) + COLOR_GROUND_DIRT_MID[1] * ratio)
            b = int(COLOR_GROUND_DIRT_TOP[2] * (1 - ratio) + COLOR_GROUND_DIRT_MID[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        # Ground border line directly at GROUND_Y
        pygame.draw.line(surface, (60, 40, 18), (0, GROUND_Y), (VIRTUAL_WIDTH, GROUND_Y), 3)

        # 2. Draw Items
        for item in self.items:
            item.draw(surface)

        # 3. Draw Hook Cable & Claw
        self.hook.draw(surface)

        # 4. Draw Miner Character & Winch (sitting flush on the ground)
        is_pulling = (self.hook.state == "RETRACTING" and self.hook.caught_item is not None)
        self.miner.draw(surface, is_pulling=is_pulling, hook_state=self.hook.state, has_strength=game_state.has_strength_drink)

        # 5. Draw Particle & Floating Text Effects
        self.effect_manager.draw(surface)

        # 6. Draw HUD (Heads-Up Display)
        self._draw_hud(surface, game_state, virtual_mouse_pos)

    def _draw_hud(self, surface: pygame.Surface, game_state, virtual_mouse_pos: tuple):
        """Draws money, goal, timer, bombs, level number, and pause button."""
        # Top HUD Bar Container
        hud_bar = pygame.Rect(0, 0, VIRTUAL_WIDTH, 60)
        hud_bg = pygame.Surface((hud_bar.width, hud_bar.height), pygame.SRCALPHA)
        hud_bg.fill(COLOR_HUD_BG)
        surface.blit(hud_bg, (0, 0))
        pygame.draw.line(surface, COLOR_HUD_BORDER, (0, 60), (VIRTUAL_WIDTH, 60), 2)

        # Money / Target Box
        m_txt = self.hud_bold.render(f"${game_state.total_money:,}", True, COLOR_GOLD_TEXT)
        m_lbl = self.hud_font.render(f"/ ${game_state.target_money:,}", True, (200, 200, 210))
        surface.blit(m_txt, (18, 16))
        surface.blit(m_lbl, (18 + m_txt.get_width() + 8, 19))

        # Level Indicator
        lvl_txt = self.hud_bold.render(f"LEVEL {game_state.current_level}", True, COLOR_WHITE)
        surface.blit(lvl_txt, (VIRTUAL_WIDTH // 2 - lvl_txt.get_width() // 2 - 140, 16))

        # 60s Countdown Timer
        t_sec = max(0, int(game_state.level_timer))
        t_col = (255, 70, 70) if t_sec <= 10 else COLOR_WHITE
        time_txt = self.timer_font.render(f"{t_sec:02d}s", True, t_col)
        time_lbl = self.hud_font.render("THỜI GIAN:", True, (200, 200, 200))
        cx = VIRTUAL_WIDTH // 2 + 70
        surface.blit(time_lbl, (cx - time_lbl.get_width() - 8, 19))
        surface.blit(time_txt, (cx, 16))

        # Bombs Inventory Icon & Count
        bx = VIRTUAL_WIDTH - 290
        pygame.draw.circle(surface, (230, 60, 40), (bx, 30), 11)
        pygame.draw.circle(surface, (255, 180, 50), (bx, 30), 5)
        b_txt = self.hud_bold.render(f"x{game_state.bombs_count}", True, COLOR_WHITE)
        surface.blit(b_txt, (bx + 16, 16))

        # Pause Button ("TẠM DỪNG")
        mx, my = virtual_mouse_pos
        is_hover_pause = self.pause_btn_rect.collidepoint((mx, my))
        pause_col = (70, 70, 85) if not is_hover_pause else (100, 100, 120)
        pygame.draw.rect(surface, pause_col, self.pause_btn_rect, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, self.pause_btn_rect, width=1, border_radius=6)

        pause_text = self.hud_font.render("TẠM DỪNG", True, COLOR_WHITE)
        surface.blit(pause_text, (self.pause_btn_rect.centerx - pause_text.get_width() // 2, self.pause_btn_rect.centery - pause_text.get_height() // 2))
