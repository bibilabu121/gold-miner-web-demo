"""
Result screens: LevelWinScreen and GameOverScreen with visual statistics,
clean uppercase button formatting, and clean quit options.
Rendered on 1280x720 Virtual Canvas with Unicode font support.
"""
import sys
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER, COLOR_RED_BTN,
    COLOR_RED_BTN_HOVER, COLOR_PANEL_BG, COLOR_PANEL_BORDER,
    GameStates, get_font
)
from sound_manager import SoundManager

class LevelWinScreen:
    """Displays victory summary and directs player to the Shop."""
    def __init__(self):
        self.font_title = get_font(48, bold=True)
        self.font_stat = get_font(22)
        self.font_btn = get_font(24, bold=True)
        self.shop_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 160, 500, 320, 58)
        self.sound = SoundManager.get_instance()

    def handle_event(self, event, game_state) -> str:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                self.sound.play('click')
                return GameStates.SHOP
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.shop_btn.collidepoint(event.pos):
                self.sound.play('click')
                return GameStates.SHOP
        return GameStates.LEVEL_WIN

    def draw(self, surface: pygame.Surface, game_state, virtual_mouse_pos=(0, 0)):
        # Dim overlay
        overlay = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.SRCALPHA)
        overlay.fill((15, 20, 30, 235))
        surface.blit(overlay, (0, 0))

        # Main Panel
        panel = pygame.Rect(VIRTUAL_WIDTH // 2 - 280, 95, 560, 490)
        pygame.draw.rect(surface, COLOR_PANEL_BG, panel, border_radius=10)
        pygame.draw.rect(surface, (100, 220, 120), panel, 3, border_radius=10)

        # Title
        title_surf = self.font_title.render("HOÀN THÀNH LEVEL!", True, (100, 255, 120))
        surface.blit(title_surf, (VIRTUAL_WIDTH // 2 - title_surf.get_width() // 2, 135))

        sub_title = self.font_stat.render(f"Chúc mừng bạn đã vượt qua Level {game_state.current_level}!", True, (220, 230, 240))
        surface.blit(sub_title, (VIRTUAL_WIDTH // 2 - sub_title.get_width() // 2, 205))

        # Stats Breakdown
        stats = [
            ("Mục tiêu màn (Goal):", f"${game_state.target_money:,}"),
            ("Tiền kiếm được màn này:", f"+${game_state.money_earned_this_level:,}"),
            ("Số vật phẩm đã đào:", f"{game_state.items_collected_this_level} món"),
            ("TỔNG TIỀN HIỆN CÓ:", f"${game_state.total_money:,}")
        ]

        sy = 265
        for label, val in stats:
            l_surf = self.font_stat.render(label, True, (200, 200, 210))
            v_col = COLOR_GOLD_TEXT if "TỔNG" in label else COLOR_WHITE
            v_surf = self.font_stat.render(val, True, v_col)
            
            surface.blit(l_surf, (panel.x + 45, sy))
            surface.blit(v_surf, (panel.right - 45 - v_surf.get_width(), sy))
            sy += 44

        # Shop Button
        is_hover = self.shop_btn.collidepoint(virtual_mouse_pos)
        btn_col = COLOR_GREEN_BTN_HOVER if is_hover else COLOR_GREEN_BTN

        pygame.draw.rect(surface, btn_col, self.shop_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.shop_btn, 2, border_radius=8)

        btn_txt = self.font_btn.render("VÀO CỬA HÀNG", True, COLOR_WHITE)
        surface.blit(btn_txt, (self.shop_btn.centerx - btn_txt.get_width() // 2, self.shop_btn.centery - btn_txt.get_height() // 2))

class GameOverScreen:
    """Displays Game Over when player fails to meet target money with retry and quit options."""
    def __init__(self):
        self.font_title = get_font(50, bold=True)
        self.font_stat = get_font(22)
        self.font_btn = get_font(22, bold=True)
        
        self.retry_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 250, 490, 240, 56)
        self.quit_btn  = pygame.Rect(VIRTUAL_WIDTH // 2 + 10, 490, 240, 56)
        self.sound = SoundManager.get_instance()

    def handle_event(self, event, game_state) -> str:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_r):
                self.sound.play('click')
                game_state.start_game()
                return GameStates.PLAYING
            elif event.key == pygame.K_q:
                pygame.quit()
                sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.retry_btn.collidepoint(event.pos):
                self.sound.play('click')
                game_state.start_game()
                return GameStates.PLAYING
            elif self.quit_btn.collidepoint(event.pos):
                pygame.quit()
                sys.exit()
        return GameStates.GAME_OVER

    def draw(self, surface: pygame.Surface, game_state, virtual_mouse_pos=(0, 0)):
        # Dark red overlay
        overlay = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.SRCALPHA)
        overlay.fill((30, 10, 10, 240))
        surface.blit(overlay, (0, 0))

        # Panel
        panel = pygame.Rect(VIRTUAL_WIDTH // 2 - 280, 95, 560, 480)
        pygame.draw.rect(surface, (25, 12, 12), panel, border_radius=10)
        pygame.draw.rect(surface, (230, 70, 60), panel, 3, border_radius=10)

        # Title
        title_surf = self.font_title.render("GAME OVER", True, (240, 70, 60))
        surface.blit(title_surf, (VIRTUAL_WIDTH // 2 - title_surf.get_width() // 2, 135))

        reason = self.font_stat.render("Hết 60 giây! Bạn không đạt đủ mục tiêu tiền.", True, (230, 190, 190))
        surface.blit(reason, (VIRTUAL_WIDTH // 2 - reason.get_width() // 2, 205))

        # Stats
        stats = [
            ("Dừng lại ở:", f"Level {game_state.current_level}"),
            ("Mục tiêu yêu cầu:", f"${game_state.target_money:,}"),
            ("Tổng tiền đạt được:", f"${game_state.total_money:,}"),
            ("KỶ LỤC ĐIỂM CAO:", f"${game_state.high_score:,}")
        ]

        sy = 265
        for label, val in stats:
            l_surf = self.font_stat.render(label, True, (200, 190, 190))
            v_col = COLOR_GOLD_TEXT if "KỶ LỤC" in label else COLOR_WHITE
            v_surf = self.font_stat.render(val, True, v_col)
            surface.blit(l_surf, (panel.x + 45, sy))
            surface.blit(v_surf, (panel.right - 45 - v_surf.get_width(), sy))
            sy += 42

        # Action Buttons (CHƠI LẠI & THOÁT GAME)
        is_hover_retry = self.retry_btn.collidepoint(virtual_mouse_pos)
        retry_col = COLOR_GREEN_BTN_HOVER if is_hover_retry else COLOR_GREEN_BTN
        pygame.draw.rect(surface, retry_col, self.retry_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.retry_btn, 2, border_radius=8)
        retry_txt = self.font_btn.render("CHƠI LẠI", True, COLOR_WHITE)
        surface.blit(retry_txt, (self.retry_btn.centerx - retry_txt.get_width() // 2, self.retry_btn.centery - retry_txt.get_height() // 2))

        is_hover_quit = self.quit_btn.collidepoint(virtual_mouse_pos)
        quit_col = COLOR_RED_BTN_HOVER if is_hover_quit else COLOR_RED_BTN
        pygame.draw.rect(surface, quit_col, self.quit_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.quit_btn, 2, border_radius=8)
        quit_txt = self.font_btn.render("THOÁT GAME (Q)", True, COLOR_WHITE)
        surface.blit(quit_txt, (self.quit_btn.centerx - quit_txt.get_width() // 2, self.quit_btn.centery - quit_txt.get_height() // 2))
