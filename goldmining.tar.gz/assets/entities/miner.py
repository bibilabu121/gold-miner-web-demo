"""
Miner character and mining cart entity.
Includes animated reeling crank, headlamp beam, and visual character expressions.
"""
import math
import pygame
from constants import (
    HOOK_ORIGIN_X, HOOK_ORIGIN_Y, HookStates,
    COLOR_WHITE
)

class Miner:
    """Old Gold Miner character operating the reel mechanism on top of the ground."""
    def __init__(self, x: float = HOOK_ORIGIN_X, y: float = HOOK_ORIGIN_Y):
        self.x = x
        self.y = y
        self.reel_angle = 0.0

    def update(self, dt: float, hook_state: str):
        """Updates animation according to hook state."""
        if hook_state == HookStates.RETRACTING:
            self.reel_angle += dt * 14.0
        elif hook_state == HookStates.SHOOTING:
            self.reel_angle -= dt * 10.0
        else:
            self.reel_angle += dt * 1.5

    def draw(self, surface: pygame.Surface, hook_state: str, has_strength: bool = False):
        cx = int(self.x)
        cy = int(self.y)

        # 1. Wooden platform & track rails
        pygame.draw.rect(surface, (50, 45, 40), (cx - 75, cy - 2, 150, 10))
        pygame.draw.rect(surface, (140, 110, 70), (cx - 70, cy + 2, 140, 5))

        # 2. Mining Cart Body
        cart_w, cart_h = 70, 40
        cart_rect = pygame.Rect(cx - cart_w // 2, cy - cart_h - 4, cart_w, cart_h)
        # Cart shadow
        pygame.draw.rect(surface, (30, 20, 15), (cart_rect.x + 2, cart_rect.y + 2, cart_w, cart_h), border_radius=4)
        # Cart wood
        pygame.draw.rect(surface, (135, 75, 35), cart_rect, border_radius=4)
        # Iron bands
        pygame.draw.rect(surface, (60, 60, 65), cart_rect, 3, border_radius=4)
        pygame.draw.line(surface, (70, 70, 75), (cart_rect.left, cart_rect.centery), (cart_rect.right, cart_rect.centery), 3)

        # Cart Wheels
        for wx in [cx - 24, cx + 24]:
            pygame.draw.circle(surface, (40, 40, 45), (wx, cy - 2), 10)
            pygame.draw.circle(surface, (160, 160, 170), (wx, cy - 2), 7)
            pygame.draw.circle(surface, (70, 70, 75), (wx, cy - 2), 3)

        # 3. Miner Body (Inside Cart)
        # Shirt (Red / Plaid or Purple if buffed)
        shirt_col = (210, 45, 40) if not has_strength else (180, 50, 210)
        miner_body = pygame.Rect(cx - 18, cy - cart_h - 26, 36, 30)
        pygame.draw.ellipse(surface, shirt_col, miner_body)

        # Suspenders
        pygame.draw.line(surface, (40, 60, 130), (cx - 9, miner_body.top + 6), (cx - 7, miner_body.bottom), 3)
        pygame.draw.line(surface, (40, 60, 130), (cx + 9, miner_body.top + 6), (cx + 7, miner_body.bottom), 3)

        # Miner Head
        head_cy = cy - cart_h - 34
        pygame.draw.circle(surface, (245, 195, 155), (cx, head_cy), 13)

        # Bushy White Beard & Mustache
        pygame.draw.ellipse(surface, (240, 240, 245), (cx - 12, head_cy + 2, 24, 15))
        pygame.draw.circle(surface, (230, 150, 130), (cx, head_cy + 1), 4)  # Big round nose

        # Eyes
        if hook_state == HookStates.RETRACTING and not has_strength:
            # Straining expression (squint)
            pygame.draw.line(surface, (20, 20, 20), (cx - 7, head_cy - 4), (cx - 3, head_cy - 2), 2)
            pygame.draw.line(surface, (20, 20, 20), (cx + 3, head_cy - 2), (cx + 7, head_cy - 4), 2)
            # Sweat drop
            pygame.draw.circle(surface, (100, 200, 255), (cx + 14, head_cy - 6), 3)
        else:
            # Cheerful open eyes
            pygame.draw.circle(surface, (20, 20, 20), (cx - 5, head_cy - 3), 2)
            pygame.draw.circle(surface, (20, 20, 20), (cx + 5, head_cy - 3), 2)

        # Mining Hardhat (Yellow)
        helmet_rect = pygame.Rect(cx - 15, head_cy - 16, 30, 14)
        pygame.draw.ellipse(surface, (245, 200, 30), helmet_rect)
        pygame.draw.rect(surface, (215, 170, 20), (cx - 16, head_cy - 6, 32, 4), border_radius=2)

        # Headlamp
        lamp_x = cx
        lamp_y = head_cy - 11
        pygame.draw.circle(surface, (80, 80, 85), (lamp_x, lamp_y), 5)
        pygame.draw.circle(surface, (255, 255, 200), (lamp_x, lamp_y), 3)

        # Headlamp light cone
        light_surf = pygame.Surface((120, 90), pygame.SRCALPHA)
        pygame.draw.polygon(light_surf, (255, 255, 180, 22), [(60, 0), (0, 90), (120, 90)])
        surface.blit(light_surf, (lamp_x - 60, lamp_y + 4))

        # 4. Spool / Winch Mechanism & Cranking Arm
        winch_x = cx + 22
        winch_y = cy - cart_h + 8
        pygame.draw.circle(surface, (50, 50, 55), (winch_x, winch_y), 9)
        pygame.draw.circle(surface, (150, 150, 160), (winch_x, winch_y), 6)

        # Crank handle
        handle_len = 12
        hx = winch_x + math.cos(self.reel_angle) * handle_len
        hy = winch_y + math.sin(self.reel_angle) * handle_len
        pygame.draw.line(surface, (80, 80, 85), (winch_x, winch_y), (hx, hy), 4)
        pygame.draw.circle(surface, (220, 180, 70), (int(hx), int(hy)), 4)

        # Miner Arm holding the crank
        shoulder_x = cx + 12
        shoulder_y = cy - cart_h - 14
        pygame.draw.line(surface, shirt_col, (shoulder_x, shoulder_y), (int(hx), int(hy)), 6)
        pygame.draw.circle(surface, (245, 195, 155), (int(hx), int(hy)), 4)  # Hand
