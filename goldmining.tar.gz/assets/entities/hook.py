"""
Hook entity and Finite State Machine (FSM):
Manages SWINGING, SHOOTING, RETRACTING, and IDLE states with exact physics,
collision mechanics, and throw_bomb dynamite explosion.
"""
import math
import random
import pygame
from constants import (
    HookStates, HOOK_ORIGIN_X, HOOK_ORIGIN_Y, HOOK_LENGTH_MIN,
    HOOK_MAX_ANGLE_RAD, HOOK_SWING_SPEED, HOOK_SHOOT_SPEED,
    HOOK_MIN_PULL_SPEED, HOOK_HEAD_RADIUS, DEFAULT_STRENGTH_FACTOR,
    BUFFED_STRENGTH_FACTOR, TNT_EXPLOSION_RADIUS,
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_GOLD_TEXT, COLOR_WHITE
)
from sound_manager import SoundManager

class Hook:
    """Rigid Finite State Machine implementation for the mining claw/hook."""
    def __init__(self, x0: float = HOOK_ORIGIN_X, y0: float = HOOK_ORIGIN_Y):
        self.x0 = x0
        self.y0 = y0
        
        self.state = HookStates.SWINGING
        self.angle = math.pi / 2  # Current angle in radians (pi/2 is straight down)
        self.swing_time = 0.0
        self.length = HOOK_LENGTH_MIN
        
        self.x = self.x0 + self.length * math.cos(self.angle)
        self.y = self.y0 + self.length * math.sin(self.angle)
        self.radius = HOOK_HEAD_RADIUS
        
        self.caught_item = None
        self.sound = SoundManager.get_instance()

    def reset(self):
        """Resets the hook to initial swinging state."""
        self.state = HookStates.SWINGING
        self.length = HOOK_LENGTH_MIN
        self.caught_item = None
        self.angle = math.pi / 2
        self.x = self.x0 + self.length * math.cos(self.angle)
        self.y = self.y0 + self.length * math.sin(self.angle)

    def shoot(self) -> bool:
        """Transitions from SWINGING to SHOOTING state if valid."""
        if self.state == HookStates.SWINGING:
            self.state = HookStates.SHOOTING
            self.sound.play('shoot')
            return True
        return False

    def throw_bomb(self, game_state, effect_manager) -> bool:
        """
        Throws a dynamite stick to destroy the currently caught item while retracting.
        Strict constraints:
        - Only active when state == RETRACTING and caught_item is not None.
        - Deducts 1 bomb from game_state inventory.
        - Destroys item, triggers sound and visual explosion, and hook retracts at full speed.
        """
        if self.state == HookStates.RETRACTING and self.caught_item is not None:
            if game_state.use_bomb():
                self.sound.play('bomb_throw')
                self.sound.play('explosion')
                effect_manager.add_explosion(self.x, self.y, radius=50)
                effect_manager.add_floating_text("BOMB!", self.x, self.y - 20, color=(255, 100, 50), font_size=24)
                self.caught_item.is_alive = False
                self.caught_item = None
                return True
        return False

    def update(self, dt: float, items: list, game_state, effect_manager):
        """Updates FSM states, physics calculations, and item interactions."""
        # 1. SWINGING STATE
        if self.state == HookStates.SWINGING:
            self.swing_time += dt * HOOK_SWING_SPEED
            # Angular oscillation: theta(t) = pi/2 + max_angle * sin(omega * t)
            self.angle = (math.pi / 2) + HOOK_MAX_ANGLE_RAD * math.sin(self.swing_time)
            self.length = HOOK_LENGTH_MIN
            self.x = self.x0 + self.length * math.cos(self.angle)
            self.y = self.y0 + self.length * math.sin(self.angle)

        # 2. SHOOTING STATE
        elif self.state == HookStates.SHOOTING:
            self.length += HOOK_SHOOT_SPEED * dt
            self.x = self.x0 + self.length * math.cos(self.angle)
            self.y = self.y0 + self.length * math.sin(self.angle)

            # Check screen boundaries
            if (self.x <= 15 or self.x >= VIRTUAL_WIDTH - 15 or 
                self.y >= VIRTUAL_HEIGHT - 15):
                self.state = HookStates.RETRACTING

            # Circle-based collision detection
            collided_items = []
            for item in items:
                if not item.is_alive or item.is_caught:
                    continue
                ix, iy, ir = item.get_collision_circle()
                dist = math.hypot(self.x - ix, self.y - iy)
                if dist <= (self.radius + ir):
                    collided_items.append((dist, item))

            if collided_items:
                # Prioritize item with smallest distance
                collided_items.sort(key=lambda x: x[0])
                closest_item = collided_items[0][1]

                # Check if item is TNT
                if closest_item.item_type == "tnt":
                    self._handle_tnt_explosion(closest_item, items, effect_manager)
                    self.state = HookStates.RETRACTING
                else:
                    # Lock item to hook
                    closest_item.is_caught = True
                    self.caught_item = closest_item
                    self.sound.play('grab')
                    self.state = HookStates.RETRACTING

        # 3. RETRACTING STATE
        elif self.state == HookStates.RETRACTING:
            # Determine pulling velocity
            if self.caught_item is None:
                pull_speed = HOOK_SHOOT_SPEED
            else:
                strength_factor = BUFFED_STRENGTH_FACTOR if game_state.has_strength_drink else DEFAULT_STRENGTH_FACTOR
                weight = self.caught_item.mass
                pull_speed = max(HOOK_MIN_PULL_SPEED, HOOK_SHOOT_SPEED / (1.0 + weight / strength_factor))
                
                # Keep item attached to hook head
                self.caught_item.x = self.x
                self.caught_item.y = self.y + self.caught_item.radius * 0.4

            self.length -= pull_speed * dt
            self.x = self.x0 + self.length * math.cos(self.angle)
            self.y = self.y0 + self.length * math.sin(self.angle)

            if self.length <= HOOK_LENGTH_MIN:
                self.length = HOOK_LENGTH_MIN
                self.state = HookStates.IDLE

        # 4. IDLE STATE
        elif self.state == HookStates.IDLE:
            if self.caught_item is not None:
                self._handle_item_collected(self.caught_item, game_state, effect_manager)
                self.caught_item.is_alive = False
                self.caught_item = None
            
            # Switch back to swinging
            self.state = HookStates.SWINGING

    def _handle_tnt_explosion(self, tnt_item, items: list, effect_manager):
        """Executes a massive TNT explosion and deletes surrounding items."""
        tx, ty = tnt_item.x, tnt_item.y
        tnt_item.is_alive = False
        
        effect_manager.add_explosion(tx, ty, radius=TNT_EXPLOSION_RADIUS)
        effect_manager.add_floating_text("BOOOM!", tx, ty - 30, color=(255, 60, 60), font_size=28)
        self.sound.play('explosion')

        # Destroy all active items within explosion radius
        for item in items:
            if not item.is_alive or item == tnt_item:
                continue
            ix, iy, ir = item.get_collision_circle()
            dist = math.hypot(tx - ix, ty - iy)
            if dist <= TNT_EXPLOSION_RADIUS + ir:
                item.is_alive = False
                # If chained TNT, spawn nested explosion
                if item.item_type == "tnt":
                    effect_manager.add_explosion(ix, iy, radius=TNT_EXPLOSION_RADIUS)
                else:
                    effect_manager.add_sparkle(ix, iy)

    def _handle_item_collected(self, item, game_state, effect_manager):
        """Processes rewards for collected items."""
        val = item.value

        if item.item_type == "gold":
            game_state.add_money(val)
            self.sound.play('money')
            effect_manager.add_floating_text(f"+${val}", self.x0, self.y0 - 20, color=COLOR_GOLD_TEXT, font_size=26)
            effect_manager.add_sparkle(self.x0, self.y0, color=(255, 230, 80))

        elif item.item_type == "diamond":
            if game_state.has_diamond_polish:
                val += 150
            game_state.add_money(val)
            self.sound.play('diamond')
            effect_manager.add_floating_text(f"+${val} (DIAMOND!)", self.x0, self.y0 - 20, color=(100, 240, 255), font_size=26)
            effect_manager.add_sparkle(self.x0, self.y0, color=(140, 240, 255))

        elif item.item_type == "rock":
            if game_state.has_rock_book:
                val = val * 3 if val <= 25 else 100
            game_state.add_money(val)
            self.sound.play('money')
            effect_manager.add_floating_text(f"+${val}", self.x0, self.y0 - 20, color=(180, 180, 180), font_size=22)

        elif item.item_type == "boar":
            game_state.add_money(val)
            self.sound.play('money')
            effect_manager.add_floating_text(f"+${val}", self.x0, self.y0 - 20, color=(255, 180, 120), font_size=24)

        elif item.item_type == "bag":
            # Mystery Bag Surprise
            clover = game_state.has_clover
            roll = random.random()
            
            if roll < (0.25 if not clover else 0.40):
                # Strength drink boost
                game_state.has_strength_drink = True
                self.sound.play('money')
                effect_manager.add_floating_text("STRENGTH DRINK!", self.x0, self.y0 - 20, color=(255, 100, 255), font_size=24)
            elif roll < (0.50 if not clover else 0.70):
                # Extra Bomb
                game_state.add_bomb(1)
                self.sound.play('money')
                effect_manager.add_floating_text("+1 DYNAMITE!", self.x0, self.y0 - 20, color=(255, 120, 50), font_size=24)
            else:
                # Random cash reward
                if clover:
                    cash = random.choice([350, 500, 650, 800])
                else:
                    cash = random.choice([50, 150, 250, 400, 600])
                game_state.add_money(cash)
                self.sound.play('money')
                effect_manager.add_floating_text(f"+${cash} (SURPRISE!)", self.x0, self.y0 - 20, color=COLOR_GOLD_TEXT, font_size=26)

    def draw(self, surface: pygame.Surface):
        """Renders the steel cable and articulated claw."""
        # 1. Cable / Chain
        pygame.draw.line(surface, (50, 50, 50), (self.x0, self.y0), (self.x, self.y), 4)
        pygame.draw.line(surface, (180, 180, 185), (self.x0 - 1, self.y0 - 1), (self.x - 1, self.y - 1), 2)

        # 2. Hook Head / Claw Mechanism
        cx, cy = self.x, self.y
        ang = self.angle
        
        # Base ring / joint
        pygame.draw.circle(surface, (70, 70, 75), (int(cx), int(cy)), 7)
        pygame.draw.circle(surface, (200, 200, 210), (int(cx), int(cy)), 4)

        # Claw jaws (open when swinging/shooting, clamped shut when holding item)
        jaw_spread = 0.55 if self.caught_item is None else 0.22
        jaw_len = 16
        
        # Left claw
        left_ang = ang + jaw_spread
        lx1 = cx + math.cos(left_ang) * jaw_len
        ly1 = cy + math.sin(left_ang) * jaw_len
        lx2 = lx1 + math.cos(ang - 0.5) * 8
        ly2 = ly1 + math.sin(ang - 0.5) * 8
        
        # Right claw
        right_ang = ang - jaw_spread
        rx1 = cx + math.cos(right_ang) * jaw_len
        ry1 = cy + math.sin(right_ang) * jaw_len
        rx2 = rx1 + math.cos(ang + 0.5) * 8
        ry2 = ry1 + math.sin(ang + 0.5) * 8

        # Draw metallic claws
        pygame.draw.lines(surface, (60, 60, 65), False, [(cx, cy), (lx1, ly1), (lx2, ly2)], 5)
        pygame.draw.lines(surface, (190, 195, 205), False, [(cx, cy), (lx1, ly1), (lx2, ly2)], 3)
        
        pygame.draw.lines(surface, (60, 60, 65), False, [(cx, cy), (rx1, ry1), (rx2, ry2)], 5)
        pygame.draw.lines(surface, (190, 195, 205), False, [(cx, cy), (rx1, ry1), (rx2, ry2)], 3)
