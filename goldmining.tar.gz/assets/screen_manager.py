"""
ScreenManager: Handles Virtual Canvas (1280x720), True Native Fullscreen, Letterboxing,
Aspect Ratios (16:9, 9:16, 3:4), and input coordinate translation.
"""
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, ASPECT_RATIO_PRESETS
)

class ScreenManager:
    """Manages true fullscreen, aspect ratios, and letterboxed virtual canvas projection."""
    def __init__(self):
        self.virtual_width = VIRTUAL_WIDTH
        self.virtual_height = VIRTUAL_HEIGHT
        
        # Fixed Virtual Canvas where all game logic and graphics are drawn
        self.virtual_surface = pygame.Surface((self.virtual_width, self.virtual_height))
        
        self.current_preset_index = 0
        self.is_fullscreen = False
        
        self.display_width = ASPECT_RATIO_PRESETS[0][1]
        self.display_height = ASPECT_RATIO_PRESETS[0][2]
        
        self.display_surface = None
        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.scaled_width = self.virtual_width
        self.scaled_height = self.virtual_height

        self._init_display()

    def _init_display(self):
        """Initializes or re-initializes the Pygame display surface."""
        if self.is_fullscreen:
            # Query actual monitor display dimensions for True Native Fullscreen
            info = pygame.display.Info()
            self.display_width = info.current_w if info.current_w > 0 else 1920
            self.display_height = info.current_h if info.current_h > 0 else 1080
            flags = pygame.FULLSCREEN | pygame.DOUBLEBUF
            self.display_surface = pygame.display.set_mode((self.display_width, self.display_height), flags)
        else:
            preset = ASPECT_RATIO_PRESETS[self.current_preset_index]
            self.display_width = preset[1]
            self.display_height = preset[2]
            flags = pygame.DOUBLEBUF
            self.display_surface = pygame.display.set_mode((self.display_width, self.display_height), flags)

        self._calculate_letterbox_viewport()

    def _calculate_letterbox_viewport(self):
        """Calculates scale factor and letterbox offsets to preserve aspect ratio without distortion."""
        scale_x = self.display_width / self.virtual_width
        scale_y = self.display_height / self.virtual_height
        self.scale = min(scale_x, scale_y)

        self.scaled_width = int(self.virtual_width * self.scale)
        self.scaled_height = int(self.virtual_height * self.scale)
        self.offset_x = (self.display_width - self.scaled_width) // 2
        self.offset_y = (self.display_height - self.scaled_height) // 2

    def toggle_fullscreen(self):
        """Toggles between windowed and true native fullscreen mode."""
        self.is_fullscreen = not self.is_fullscreen
        self._init_display()

    def set_aspect_ratio_preset(self, index: int):
        """Sets windowed aspect ratio preset by index."""
        if 0 <= index < len(ASPECT_RATIO_PRESETS):
            self.current_preset_index = index
            self.is_fullscreen = False
            self._init_display()

    def display_to_virtual(self, pos: tuple) -> tuple:
        """Transforms a mouse coordinate on the physical window into Virtual Canvas coordinates."""
        dx, dy = pos
        if self.scale <= 0:
            return (0, 0)
        vx = (dx - self.offset_x) / self.scale
        vy = (dy - self.offset_y) / self.scale
        return (int(vx), int(vy))

    def render_to_display(self):
        """Scales the virtual canvas and draws it onto the physical display with letterboxing."""
        # 1. Fill screen with black letterbox borders
        self.display_surface.fill((0, 0, 0))

        # 2. Smoothly scale virtual surface to letterbox dimensions
        scaled_surf = pygame.transform.smoothscale(
            self.virtual_surface, (self.scaled_width, self.scaled_height)
        )

        # 3. Blit centered onto physical display
        self.display_surface.blit(scaled_surf, (self.offset_x, self.offset_y))

        # 4. Flip buffers
        pygame.display.flip()
