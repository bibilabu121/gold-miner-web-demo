"""
Play Screen Controller: Main game-loop screen managing HUD, Hook physics,
dynamic entities (Gold, Diamonds, Rocks, Mystery Bags, TNT, Boars), collision detection,
strict time-up rule, procedural particle effects, and strict input parity.
Optimized for fixed 16:9 display with Fullscreen button removed.
"""
import pygame
from constants import (
    GameStates, GROUND_Y, VIRTUAL_WIDTH, VIRTUAL_HEIGHT,
    COLOR_WHITE, COLOR_GOLD_TEXT, COLOR_TNT_MAIN,
    COLOR_SKY_TOP, COLOR_SKY_BOTTOM,
    COLOR_GROUND_GRASS, COLOR_GROUND_DIRT_TOP,
    COLOR_GROUND_DIRT_MID, COLOR_GROUND_DIRT_BOT,
    COLOR_GROUND_LAYER_LINE, get_font
)
from entities.hook import Hook
from entities.miner import Miner
from entities.effects import EffectManager
from level_generator import generate_level
from sound_manager import SoundManager

class PlayScreen:
    """Manages gameplay execution, HUD layout, and collision resolution."""
    def __init__(self):
        self.hook = Hook()
        self.miner = Miner()
        self.items = []
        self.effect_manager = EffectManager()
        self.sound = SoundManager.get_instance()

        # In-game HUD Buttons (Only TẠM DỪNG, Fullscreen button removed)
        self.pause_btn_rect = pygame.Rect(VIRTUAL_WIDTH - 145, 10, 135, 38)

        # Fonts (Bundled TTF support)
        self.font_hud = get_font(20, bold=True)
        self.font_hud_large = get_font(28, bold=True)
        self.font_hud_small = get_font(13, bold=True)
        self.font_btn = get_font(15, bold=True)

        # Static Background Surface Cache
        self.bg_surface = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT))
        self._render_static_background()

    def _render_static_background(self):
        """Pre-renders sky, grass, and rich layered underground earth strata."""
        # Sky gradient
        for y in range(0, GROUND_Y):
            ratio = y / GROUND_Y
            r = int(COLOR_SKY_TOP[0] * (1 - ratio) + COLOR_SKY_BOTTOM[0] * ratio)
            g = int(COLOR_SKY_TOP[1] * (1 - ratio) + COLOR_SKY_BOTTOM[1] * ratio)
            b = int(COLOR_SKY_TOP[2] * (1 - ratio) + COLOR_SKY_BOTTOM[2] * ratio)
            pygame.draw.line(self.bg_surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        # Grass surface band
        pygame.draw.rect(self.bg_surface, COLOR_GROUND_GRASS, (0, GROUND_Y, VIRTUAL_WIDTH, 4))

        # Deep Earth Strata Gradient
        for y in range(GROUND_Y + 4, VIRTUAL_HEIGHT):
            ratio = (y - GROUND_Y) / (VIRTUAL_HEIGHT - GROUND_Y)
            if ratio < 0.5:
                sub_r = ratio * 2
                r = int(COLOR_GROUND_DIRT_TOP[0] * (1 - sub_r) + COLOR_GROUND_DIRT_MID[0] * sub_r)
                g = int(COLOR_GROUND_DIRT_TOP[1] * (1 - sub_r) + COLOR_GROUND_DIRT_MID[0] * sub_r)
                b = int(COLOR_GROUND_DIRT_TOP[2] * (1 - sub_r) + COLOR_GROUND_DIRT_MID[2] * sub_r)
            else:
                sub_r = (ratio - 0.5) * 2
                r = int(COLOR_GROUND_DIRT_MID[0] * (1 - sub_r) + COLOR_GROUND_DIRT_BOT[0] * sub_r)
                g = int(COLOR_GROUND_DIRT_MID[1] * (1 - sub_r) + COLOR_GROUND_DIRT_BOT[1] * sub_r)
                b = int(COLOR_GROUND_DIRT_MID[2] * (1 - sub_r) + COLOR_GROUND_DIRT_BOT[2] * sub_r)
            pygame.draw.line(self.bg_surface, (r, g, b), (0, y), (VIRTUAL_WIDTH, y))

        # Add stone speckles
        import random
        random.seed(42)
        for _ in range(120):
            sx = random.randint(10, VIRTUAL_WIDTH - 10)
            sy = random.randint(GROUND_Y + 20, VIRTUAL_HEIGHT - 20)
            sr = random.randint(2, 7)
            col = random.choice([(50, 30, 15), (70, 45, 25), (40, 25, 15), (85, 55, 30)])
            pygame.draw.circle(self.bg_surface, col, (sx, sy), sr)
        random.seed()

    def start_level(self, game_state):
        """Loads and prepares a new level."""
        self.items.clear()
        self.items = generate_level(game_state.current_level)
        self.hook.reset()
        self.effect_manager.clear()
        self.sound.start_bgm()

    def handle_event(self, event, game_state, screen_manager=None) -> str:
        """Processes player inputs during gameplay with STRICT INPUT PARITY."""
        if event.type == pygame.KEYDOWN:
            # ONLY ESC to pause
            if event.key == pygame.K_ESCAPE:
                self.sound.play('click')
                return GameStates.PAUSE

            # ONLY SPACE to shoot hook
            elif event.key == pygame.K_SPACE:
                self.hook.shoot()

        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            
            # Left Mouse Click
            if event.button == 1:
                # Pause button clicked
                if self.pause_btn_rect.collidepoint(mouse_pos):
                    self.sound.play('click')
                    return GameStates.PAUSE
                else:
                    # Shoot hook via Left Click
                    self.hook.shoot()

            # Right Mouse Click (Bomb ONLY)
            elif event.button == 3:
                self.hook.throw_bomb(game_state, self.effect_manager)

        return GameStates.PLAYING

    def update(self, dt: float, game_state) -> str:
        """Runs 60 FPS physics updates, collision checks, entity movements, and strict time limit."""
        # 1. Strict Time Up Rule: Level ends immediately when timer <= 0
        game_state.level_timer -= dt
        if game_state.is_time_up():
            game_state.level_timer = 0.0
            self.sound.stop_bgm()
            
            # Cancel pulling and destroy caught item immediately
            if self.hook.caught_item:
                self.hook.caught_item = None
            self.hook.reset()

            # Determine Win or Game Over
            if game_state.is_level_won():
                self.sound.play('level_win')
                game_state.next_level()
                return GameStates.LEVEL_WIN
            else:
                self.sound.play('game_over')
                return GameStates.GAME_OVER

        # 2. Update Moving Entities (Boars)
        for item in self.items:
            if hasattr(item, 'update'):
                item.update(dt)

        # 3. Update Hook Physics & Collision Detection
        self.hook.update(dt, self.items, game_state, self.effect_manager)

        # 4. Update Particle & Floating Text Effects
        self.effect_manager.update(dt)

        # 5. Clean up destroyed/collected items
        self.items = [item for item in self.items if getattr(item, 'is_alive', True)]

        return GameStates.PLAYING

    def draw(self, surface: pygame.Surface, game_state, virtual_mouse_pos: tuple = (0, 0)):
        """Renders gameplay frame onto the Virtual Canvas."""
        # 1. Background
        surface.blit(self.bg_surface, (0, 0))

        # 2. Strata lines for underground depth aesthetic
        pygame.draw.line(surface, COLOR_GROUND_LAYER_LINE, (0, GROUND_Y + 180), (VIRTUAL_WIDTH, GROUND_Y + 180), 2)
        pygame.draw.line(surface, COLOR_GROUND_LAYER_LINE, (0, GROUND_Y + 360), (VIRTUAL_WIDTH, GROUND_Y + 360), 2)

        # 3. Items / Gold / Diamonds / Rocks / TNT / Boars
        for item in self.items:
            item.draw(surface)

        # 4. Hook & Winch Rope
        self.hook.draw(surface)

        # 5. Miner Character & Winch Machine
        self.miner.draw(surface, self.hook.state, getattr(game_state, 'has_strength_drink', False))

        # 6. Particle & Floating Text Effects
        self.effect_manager.draw(surface)

        # 7. In-Game HUD Bar
        self._draw_hud(surface, game_state, virtual_mouse_pos)

    def _draw_hud(self, surface: pygame.Surface, game_state, virtual_mouse_pos: tuple):
        """Draws top HUD status panel, money, target, level, bombs, timer, and pause button."""
        # HUD Panel Background
        hud_rect = pygame.Rect(0, 0, VIRTUAL_WIDTH, 56)
        pygame.draw.rect(surface, (20, 15, 12, 225), hud_rect)
        pygame.draw.line(surface, (180, 130, 50), (0, 56), (VIRTUAL_WIDTH, 56), 2)

        # Current Money
        money_lbl = self.font_hud_small.render("TIỀN HIỆN CÓ:", True, (200, 200, 200))
        money_val = self.font_hud_large.render(f"${game_state.total_money:,}", True, COLOR_GOLD_TEXT)
        surface.blit(money_lbl, (25, 4))
        surface.blit(money_val, (25, 20))

        # Target Goal
        target_lbl = self.font_hud_small.render("MỤC TIÊU:", True, (200, 200, 200))
        target_col = (100, 255, 120) if game_state.is_level_won() else (255, 215, 100)
        target_val = self.font_hud_large.render(f"${game_state.target_money:,}", True, target_col)
        surface.blit(target_lbl, (210, 4))
        surface.blit(target_val, (210, 20))

        # Level
        level_surf = self.font_hud_large.render(f"LEVEL {game_state.current_level}", True, COLOR_WHITE)
        surface.blit(level_surf, (VIRTUAL_WIDTH // 2 - 140, 12))

        # Bombs Counter
        bx = VIRTUAL_WIDTH // 2 + 20
        pygame.draw.circle(surface, COLOR_TNT_MAIN, (bx + 14, 26), 11)
        pygame.draw.line(surface, (240, 200, 50), (bx + 14, 15), (bx + 19, 10), 2)
        bomb_text = self.font_hud.render(f"x {game_state.bombs_count}", True, COLOR_WHITE)
        surface.blit(bomb_text, (bx + 32, 14))

        # Active Power-up Badges
        badge_x = bx + 95
        if game_state.has_strength_drink:
            pygame.draw.rect(surface, (160, 40, 200), (badge_x, 12, 28, 28), border_radius=4)
            badge_txt = self.font_hud_small.render("S", True, COLOR_WHITE)
            surface.blit(badge_txt, (badge_x + 8, 16))
            badge_x += 34
        if game_state.has_clover:
            pygame.draw.rect(surface, (40, 180, 50), (badge_x, 12, 28, 28), border_radius=4)
            badge_txt = self.font_hud_small.render("C", True, COLOR_WHITE)
            surface.blit(badge_txt, (badge_x + 8, 16))
            badge_x += 34
        if game_state.has_diamond_polish:
            pygame.draw.rect(surface, (40, 180, 230), (badge_x, 12, 28, 28), border_radius=4)
            badge_txt = self.font_hud_small.render("D", True, COLOR_WHITE)
            surface.blit(badge_txt, (badge_x + 8, 16))
            badge_x += 34
        if game_state.has_rock_book:
            pygame.draw.rect(surface, (150, 120, 60), (badge_x, 12, 28, 28), border_radius=4)
            badge_txt = self.font_hud_small.render("R", True, COLOR_WHITE)
            surface.blit(badge_txt, (badge_x + 8, 16))
            badge_x += 34

        # Timer (seconds)
        time_left = max(0.0, game_state.level_timer)
        timer_col = (255, 60, 60) if time_left < 10.0 else COLOR_WHITE
        time_lbl = self.font_hud_small.render("THỜI GIAN:", True, (200, 200, 200))
        time_val = self.font_hud_large.render(f"{int(time_left):02d}s", True, timer_col)
        surface.blit(time_lbl, (VIRTUAL_WIDTH - 300, 4))
        surface.blit(time_val, (VIRTUAL_WIDTH - 300, 20))

        # Pause Button (Clean Text, No Emoji)
        is_p_hover = self.pause_btn_rect.collidepoint(virtual_mouse_pos)
        p_col = (200, 140, 40) if is_p_hover else (160, 105, 30)
        pygame.draw.rect(surface, p_col, self.pause_btn_rect, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.pause_btn_rect, 1, border_radius=8)
        p_txt = self.font_btn.render("TẠM DỪNG", True, COLOR_WHITE)
        surface.blit(p_txt, (self.pause_btn_rect.centerx - p_txt.get_width() // 2, self.pause_btn_rect.centery - p_txt.get_height() // 2))
