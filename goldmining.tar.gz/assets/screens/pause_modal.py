"""
PauseModal: In-game pause menu with clean uppercase text, consistent buttons,
audio controls, fullscreen toggle, restart level, and clean quit options.
"""
import sys
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER, COLOR_RED_BTN,
    COLOR_RED_BTN_HOVER, COLOR_BLUE_BTN, COLOR_BLUE_BTN_HOVER,
    COLOR_PANEL_BG, COLOR_PANEL_BORDER, GameStates, get_font
)
from sound_manager import SoundManager

class PauseModal:
    """Manages in-game pause dialog and settings adjustment."""
    def __init__(self):
        self.font_title = get_font(42, bold=True)
        self.font_btn = get_font(20, bold=True)
        self.font_label = get_font(17, bold=True)
        
        self.panel_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 270, 70, 540, 560)
        
        # Interactive buttons (consistent 8px rounded corners and heights)
        self.resume_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 140, 380, 48)
        self.restart_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 198, 380, 48)
        
        # Audio row
        self.bgm_toggle_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 258, 185, 44)
        self.sfx_toggle_btn = pygame.Rect(VIRTUAL_WIDTH // 2 + 5, 258, 185, 44)
        
        # Volume row
        self.vol_down_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 314, 55, 42)
        self.vol_up_btn = pygame.Rect(VIRTUAL_WIDTH // 2 + 135, 314, 55, 42)
        
        # Fullscreen row
        self.fullscreen_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 368, 380, 46)
        
        # Menu return
        self.menu_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 426, 380, 48)

        # Quit application
        self.quit_app_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 190, 484, 380, 48)

        self.sound = SoundManager.get_instance()

    def handle_event(self, event, game_state, screen_manager=None, play_screen=None) -> str:
        """Processes pause menu inputs and settings changes."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_SPACE):
                self.sound.play('click')
                return GameStates.PLAYING
            elif event.key == pygame.K_r and play_screen:
                self.sound.play('click')
                play_screen.start_level(game_state)
                game_state.level_timer = 60.0
                return GameStates.PLAYING
            elif event.key == pygame.K_q:
                # Clean exit application
                pygame.quit()
                sys.exit()
            elif event.key == pygame.K_F11 and screen_manager:
                self.sound.play('click')
                screen_manager.toggle_fullscreen()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos

            # Resume
            if self.resume_btn.collidepoint(pos):
                self.sound.play('click')
                return GameStates.PLAYING

            # Restart Level
            if self.restart_btn.collidepoint(pos) and play_screen:
                self.sound.play('click')
                play_screen.start_level(game_state)
                game_state.level_timer = 60.0
                return GameStates.PLAYING

            # BGM Toggle
            if self.bgm_toggle_btn.collidepoint(pos):
                self.sound.toggle_bgm()
                self.sound.play('click')
                return GameStates.PAUSE

            # SFX Toggle
            if self.sfx_toggle_btn.collidepoint(pos):
                self.sound.toggle_sfx()
                self.sound.play('click')
                return GameStates.PAUSE

            # Volume Down
            if self.vol_down_btn.collidepoint(pos):
                self.sound.decrease_volume(0.1)
                self.sound.play('click')
                return GameStates.PAUSE

            # Volume Up
            if self.vol_up_btn.collidepoint(pos):
                self.sound.increase_volume(0.1)
                self.sound.play('click')
                return GameStates.PAUSE

            # Fullscreen Toggle
            if self.fullscreen_btn.collidepoint(pos) and screen_manager:
                self.sound.play('click')
                screen_manager.toggle_fullscreen()
                return GameStates.PAUSE

            # Menu Exit
            if self.menu_btn.collidepoint(pos):
                self.sound.play('click')
                return GameStates.MENU

            # Quit App
            if self.quit_app_btn.collidepoint(pos):
                pygame.quit()
                sys.exit()

        return GameStates.PAUSE

    def draw(self, surface: pygame.Surface, game_state, screen_manager=None, virtual_mouse_pos=(0, 0)):
        """Renders the pause dialog modal overlay."""
        # Dark dimming layer
        dim = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.SRCALPHA)
        dim.fill((10, 12, 16, 215))
        surface.blit(dim, (0, 0))

        # Modal Panel
        pygame.draw.rect(surface, COLOR_PANEL_BG, self.panel_rect, border_radius=10)
        pygame.draw.rect(surface, COLOR_PANEL_BORDER, self.panel_rect, 3, border_radius=10)

        # Title
        title_surf = self.font_title.render("TẠM DỪNG", True, COLOR_GOLD_TEXT)
        surface.blit(title_surf, (VIRTUAL_WIDTH // 2 - title_surf.get_width() // 2, 85))

        # 1. Resume Button
        is_hover = self.resume_btn.collidepoint(virtual_mouse_pos)
        col = COLOR_GREEN_BTN_HOVER if is_hover else COLOR_GREEN_BTN
        pygame.draw.rect(surface, col, self.resume_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.resume_btn, 2, border_radius=8)
        res_txt = self.font_btn.render("TIẾP TỤC", True, COLOR_WHITE)
        surface.blit(res_txt, (self.resume_btn.centerx - res_txt.get_width() // 2, self.resume_btn.centery - res_txt.get_height() // 2))

        # 2. Restart Level Button
        is_hover = self.restart_btn.collidepoint(virtual_mouse_pos)
        col = (200, 140, 40) if is_hover else (170, 110, 30)
        pygame.draw.rect(surface, col, self.restart_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.restart_btn, 2, border_radius=8)
        rst_txt = self.font_btn.render("CHƠI LẠI MÀN NÀY", True, COLOR_WHITE)
        surface.blit(rst_txt, (self.restart_btn.centerx - rst_txt.get_width() // 2, self.restart_btn.centery - rst_txt.get_height() // 2))

        # 3. Audio Toggles
        bgm_txt = "NHẠC NỀN: BẬT" if not self.sound.is_bgm_muted else "NHẠC NỀN: TẮT"
        bgm_col = (46, 120, 70) if not self.sound.is_bgm_muted else (110, 50, 50)
        pygame.draw.rect(surface, bgm_col, self.bgm_toggle_btn, border_radius=8)
        pygame.draw.rect(surface, (200, 200, 200), self.bgm_toggle_btn, 1, border_radius=8)
        b_surf = self.font_label.render(bgm_txt, True, COLOR_WHITE)
        surface.blit(b_surf, (self.bgm_toggle_btn.centerx - b_surf.get_width() // 2, self.bgm_toggle_btn.centery - b_surf.get_height() // 2))

        sfx_txt = "HIỆU ỨNG: BẬT" if not self.sound.is_sfx_muted else "HIỆU ỨNG: TẮT"
        sfx_col = (46, 120, 70) if not self.sound.is_sfx_muted else (110, 50, 50)
        pygame.draw.rect(surface, sfx_col, self.sfx_toggle_btn, border_radius=8)
        pygame.draw.rect(surface, (200, 200, 200), self.sfx_toggle_btn, 1, border_radius=8)
        s_surf = self.font_label.render(sfx_txt, True, COLOR_WHITE)
        surface.blit(s_surf, (self.sfx_toggle_btn.centerx - s_surf.get_width() // 2, self.sfx_toggle_btn.centery - s_surf.get_height() // 2))

        # 4. Volume Row
        pygame.draw.rect(surface, (50, 60, 80), self.vol_down_btn, border_radius=8)
        vd_txt = self.font_btn.render("-", True, COLOR_WHITE)
        surface.blit(vd_txt, (self.vol_down_btn.centerx - vd_txt.get_width() // 2, self.vol_down_btn.centery - vd_txt.get_height() // 2))

        vol_pct = int(self.sound.volume_level * 100)
        vol_label = self.font_label.render(f"ÂM LƯỢNG: {vol_pct}%", True, (240, 240, 240))
        surface.blit(vol_label, (VIRTUAL_WIDTH // 2 - vol_label.get_width() // 2, 325))

        pygame.draw.rect(surface, (50, 60, 80), self.vol_up_btn, border_radius=8)
        vu_txt = self.font_btn.render("+", True, COLOR_WHITE)
        surface.blit(vu_txt, (self.vol_up_btn.centerx - vu_txt.get_width() // 2, self.vol_up_btn.centery - vu_txt.get_height() // 2))

        # 5. Fullscreen Toggle Button
        is_hover = self.fullscreen_btn.collidepoint(virtual_mouse_pos)
        fs_col = COLOR_BLUE_BTN_HOVER if is_hover else COLOR_BLUE_BTN
        pygame.draw.rect(surface, fs_col, self.fullscreen_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.fullscreen_btn, 1, border_radius=8)
        fs_state_txt = "CHẾ ĐỘ CỬA SỔ (F11)" if (screen_manager and screen_manager.is_fullscreen) else "TOÀN MÀN HÌNH (F11)"
        fs_surf = self.font_label.render(fs_state_txt, True, COLOR_WHITE)
        surface.blit(fs_surf, (self.fullscreen_btn.centerx - fs_surf.get_width() // 2, self.fullscreen_btn.centery - fs_surf.get_height() // 2))

        # 6. Return to Menu Button
        is_hover = self.menu_btn.collidepoint(virtual_mouse_pos)
        col = (180, 90, 40) if is_hover else (150, 70, 30)
        pygame.draw.rect(surface, col, self.menu_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.menu_btn, 2, border_radius=8)
        m_txt = self.font_btn.render("VỀ MENU CHÍNH", True, COLOR_WHITE)
        surface.blit(m_txt, (self.menu_btn.centerx - m_txt.get_width() // 2, self.menu_btn.centery - m_txt.get_height() // 2))

        # 7. Quit Application Button
        is_hover = self.quit_app_btn.collidepoint(virtual_mouse_pos)
        col = COLOR_RED_BTN_HOVER if is_hover else COLOR_RED_BTN
        pygame.draw.rect(surface, col, self.quit_app_btn, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.quit_app_btn, 2, border_radius=8)
        q_txt = self.font_btn.render("THOÁT GAME (Q)", True, COLOR_WHITE)
        surface.blit(q_txt, (self.quit_app_btn.centerx - q_txt.get_width() // 2, self.quit_app_btn.centery - q_txt.get_height() // 2))
