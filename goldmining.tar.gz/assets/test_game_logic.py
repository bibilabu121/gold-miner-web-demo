"""
Automated unit & logic test suite for Gold Miner Game.
Tests Hook FSM, physics calculations, circle collisions, TNT explosion logic,
Strict Time-Up Rule, ScreenManager letterboxing projection, Audio Controller, and Session Resume.
"""
import sys
import math
import unittest
import pygame

# Initialize pygame in dummy mode for testing
import os
os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
pygame.init()

from constants import (
    HookStates, GameStates, HOOK_SHOOT_SPEED, HOOK_MIN_PULL_SPEED,
    DEFAULT_STRENGTH_FACTOR, BUFFED_STRENGTH_FACTOR, TNT_EXPLOSION_RADIUS,
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT
)
from game_state import GameState
from entities.item import GoldItem, DiamondItem, RockItem, TNTItem, MysteryBagItem, BoarItem
from entities.hook import Hook
from entities.effects import EffectManager
from level_generator import generate_level
from screen_manager import ScreenManager
from sound_manager import SoundManager
from screens.play_screen import PlayScreen

class TestGoldMinerGame(unittest.TestCase):
    def setUp(self):
        self.game_state = GameState()
        self.effect_manager = EffectManager()
        self.hook = Hook()
        self.sound = SoundManager.get_instance()

    def test_game_state_initialization_and_progression(self):
        """Test initial state, next_level progression, and buff management."""
        self.assertEqual(self.game_state.current_level, 1)
        self.assertEqual(self.game_state.total_money, 0)
        self.assertEqual(self.game_state.bombs_count, 3)
        self.assertEqual(self.game_state.level_timer, 60.0)

        # Earn money and advance level
        self.game_state.add_money(800)
        self.assertTrue(self.game_state.is_level_won())
        self.assertEqual(self.game_state.high_score, 800)

        # Add strength drink and advance level
        self.game_state.has_strength_drink = True
        self.game_state.next_level()
        self.assertEqual(self.game_state.current_level, 2)
        self.assertEqual(self.game_state.level_timer, 60.0)
        # Single-level buff should be cleared
        self.assertFalse(self.game_state.has_strength_drink)

    def test_session_save_and_resume(self):
        """Test ongoing game session flag management."""
        self.assertFalse(self.game_state.has_saved_session)
        self.game_state.start_game()
        self.assertTrue(self.game_state.has_saved_session)

    def test_hook_fsm_transitions(self):
        """Test strict Hook FSM state changes."""
        self.assertEqual(self.hook.state, HookStates.SWINGING)

        # 1. Shoot
        shoot_success = self.hook.shoot()
        self.assertTrue(shoot_success)
        self.assertEqual(self.hook.state, HookStates.SHOOTING)

        # 2. Cannot shoot again while shooting
        self.assertFalse(self.hook.shoot())

        # 3. Simulate shooting downwards and colliding with boundary
        dt = 0.05
        items = []
        for _ in range(50):
            self.hook.update(dt, items, self.game_state, self.effect_manager)
            if self.hook.state == HookStates.RETRACTING:
                break
        self.assertEqual(self.hook.state, HookStates.RETRACTING)

        # 4. Retract back to origin
        for _ in range(60):
            self.hook.update(dt, items, self.game_state, self.effect_manager)
            if self.hook.state == HookStates.SWINGING:
                break
        self.assertEqual(self.hook.state, HookStates.SWINGING)

    def test_circle_distance_collision_and_pull_speed(self):
        """Test Distance-based Circle Collision and physics formula for V_pull with Mass = 9."""
        gold = GoldItem(self.hook.x0, 200, "large")
        self.assertEqual(gold.mass, 9.0)
        self.assertEqual(gold.value, 500)
        items = [gold]

        self.hook.shoot()
        self.hook.angle = math.pi / 2
        self.hook.x = self.hook.x0

        dt = 0.02
        for _ in range(30):
            self.hook.update(dt, items, self.game_state, self.effect_manager)
            if self.hook.state == HookStates.RETRACTING:
                break

        self.assertEqual(self.hook.state, HookStates.RETRACTING)
        self.assertEqual(self.hook.caught_item, gold)
        self.assertTrue(gold.is_caught)

        expected_pull_speed = max(HOOK_MIN_PULL_SPEED, HOOK_SHOOT_SPEED / (1.0 + gold.mass / DEFAULT_STRENGTH_FACTOR))
        self.assertAlmostEqual(expected_pull_speed, HOOK_SHOOT_SPEED / (1.0 + 9.0 / 2.0), delta=1.0)

    def test_strict_time_up_rule(self):
        """Test that when timer <= 0, play screen immediately terminates without overtime."""
        play_screen = PlayScreen()
        play_screen.start_level(self.game_state)
        
        rock = RockItem(play_screen.hook.x0, 300, "large")
        play_screen.hook.caught_item = rock
        play_screen.hook.state = HookStates.RETRACTING

        self.game_state.level_timer = 0.0
        self.game_state.total_money = 100
        self.game_state.target_money = 650

        next_state = play_screen.update(0.016, self.game_state)

        self.assertEqual(next_state, GameStates.GAME_OVER)
        self.assertIsNone(play_screen.hook.caught_item)
        self.assertEqual(play_screen.hook.state, HookStates.SWINGING)

    def test_sound_and_volume_controller(self):
        """Test BGM/SFX mute toggles and volume control."""
        self.sound.set_volume(0.5)
        self.assertAlmostEqual(self.sound.volume_level, 0.5)
        self.sound.increase_volume(0.2)
        self.assertAlmostEqual(self.sound.volume_level, 0.7)
        self.sound.decrease_volume(0.3)
        self.assertAlmostEqual(self.sound.volume_level, 0.4)

        self.assertFalse(self.sound.is_bgm_muted)
        self.sound.toggle_bgm()
        self.assertTrue(self.sound.is_bgm_muted)
        self.sound.toggle_bgm()
        self.assertFalse(self.sound.is_bgm_muted)

        self.assertFalse(self.sound.is_sfx_muted)
        self.sound.toggle_sfx()
        self.assertTrue(self.sound.is_sfx_muted)
        self.sound.toggle_sfx()
        self.assertFalse(self.sound.is_sfx_muted)

    def test_screen_manager_aspect_ratios_and_coordinates(self):
        """Test ScreenManager virtual canvas projection and coordinate mapping."""
        sm = ScreenManager()
        self.assertEqual(sm.virtual_width, VIRTUAL_WIDTH)
        self.assertEqual(sm.virtual_height, VIRTUAL_HEIGHT)

        sm.set_aspect_ratio_preset(0)
        vx, vy = sm.display_to_virtual((640, 360))
        self.assertEqual((vx, vy), (640, 360))

        sm.set_aspect_ratio_preset(1)
        self.assertEqual(sm.display_width, 540)
        self.assertEqual(sm.display_height, 960)
        self.assertGreater(sm.offset_y, 0)

    def test_bomb_destruction(self):
        """Test bomb usage destroying caught item and resetting hook pull speed."""
        rock = RockItem(self.hook.x0, 200, "large")
        self.hook.caught_item = rock
        self.hook.state = HookStates.RETRACTING
        self.assertEqual(self.game_state.bombs_count, 3)

        used = self.hook.trigger_bomb(self.game_state, self.effect_manager)
        self.assertTrue(used)
        self.assertEqual(self.game_state.bombs_count, 2)
        self.assertIsNone(self.hook.caught_item)
        self.assertFalse(rock.is_alive)

    def test_tnt_explosion_radius(self):
        """Test TNT contact exploding and removing items within 100px radius."""
        tnt = TNTItem(self.hook.x0, 300)
        near_gold = GoldItem(self.hook.x0 + 20, 320, "small")
        far_gold = GoldItem(self.hook.x0, 480, "large")
        items = [tnt, near_gold, far_gold]

        self.hook.angle = math.pi / 2
        self.hook.length = 300 - self.hook.y0 - 5
        self.hook.state = HookStates.SHOOTING

        self.hook.update(0.02, items, self.game_state, self.effect_manager)

        self.assertFalse(tnt.is_alive)
        self.assertFalse(near_gold.is_alive)
        self.assertTrue(far_gold.is_alive)
        self.assertEqual(self.hook.state, HookStates.RETRACTING)

    def test_level_generation(self):
        """Test level generator produces non-overlapping items."""
        for lvl in range(1, 5):
            items = generate_level(lvl)
            self.assertGreater(len(items), 5)
            for i in range(len(items)):
                for j in range(i + 1, len(items)):
                    ix, iy, ir = items[i].get_collision_circle()
                    jx, jy, jr = items[j].get_collision_circle()
                    dist = math.hypot(ix - jx, iy - jy)
                    self.assertGreaterEqual(dist, ir + jr, f"Items {i} and {j} overlap in level {lvl}")

if __name__ == "__main__":
    unittest.main()
