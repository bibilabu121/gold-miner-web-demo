"""
Entities package for Gold Miner game.
"""
