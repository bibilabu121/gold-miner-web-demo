"""
Miner character and mining cart entity.
Includes animated reeling crank, headlamp beam, and visual character expressions.
Rendered flush on top of the ground line.
"""
import math
import pygame
from constants import (
    HOOK_ORIGIN_X, HOOK_ORIGIN_Y, HookStates, GROUND_Y,
    COLOR_WHITE
)

class Miner:
    """Old Gold Miner character operating the reel mechanism directly on top of the ground."""
    def __init__(self, x: float = HOOK_ORIGIN_X, y: float = HOOK_ORIGIN_Y):
        self.x = x
        self.y = y
        self.reel_angle = 0.0

    def reset(self):
        """Resets the reel animation."""
        self.reel_angle = 0.0

    def update(self, dt: float, hook_state: str = HookStates.SWINGING):
        """Updates animation according to hook state."""
        if hook_state == HookStates.RETRACTING:
            self.reel_angle += dt * 14.0
        elif hook_state == HookStates.SHOOTING:
            self.reel_angle -= dt * 10.0
        else:
            self.reel_angle += dt * 1.5

    def draw(self, surface: pygame.Surface, is_pulling: bool = False, hook_state: str = HookStates.SWINGING, has_strength: bool = False):
        cx = int(self.x)
        cy = int(self.y)  # GROUND_Y = 100

        # 1. Wooden platform & track rails (resting flush at the ground boundary)
        pygame.draw.rect(surface, (50, 45, 40), (cx - 75, cy - 8, 150, 8))
        pygame.draw.rect(surface, (140, 110, 70), (cx - 70, cy - 6, 140, 4))
        pygame.draw.line(surface, (30, 25, 20), (cx - 75, cy), (cx + 75, cy), 2)

        # 2. Mining Cart Body
        cart_w, cart_h = 70, 38
        cart_rect = pygame.Rect(cx - cart_w // 2, cy - cart_h - 8, cart_w, cart_h)
        # Cart shadow
        pygame.draw.rect(surface, (30, 20, 15), (cart_rect.x + 2, cart_rect.y + 2, cart_w, cart_h), border_radius=4)
        # Cart wood
        pygame.draw.rect(surface, (135, 75, 35), cart_rect, border_radius=4)
        # Iron bands
        pygame.draw.rect(surface, (60, 60, 65), cart_rect, 3, border_radius=4)
        pygame.draw.line(surface, (70, 70, 75), (cart_rect.left, cart_rect.centery), (cart_rect.right, cart_rect.centery), 3)

        # Cart Wheels (touching the track)
        for wx in [cx - 24, cx + 24]:
            pygame.draw.circle(surface, (40, 40, 45), (wx, cy - 8), 9)
            pygame.draw.circle(surface, (160, 160, 170), (wx, cy - 8), 6)
            pygame.draw.circle(surface, (70, 70, 75), (wx, cy - 8), 3)

        # 3. Miner Body (Inside Cart)
        # Shirt (Red or Purple if buffed with strength drink)
        shirt_col = (210, 45, 40) if not has_strength else (180, 50, 210)
        miner_body = pygame.Rect(cx - 18, cart_rect.top - 22, 36, 28)
        pygame.draw.ellipse(surface, shirt_col, miner_body)

        # Suspenders
        pygame.draw.line(surface, (40, 60, 130), (cx - 9, miner_body.top + 6), (cx - 7, miner_body.bottom), 3)
        pygame.draw.line(surface, (40, 60, 130), (cx + 9, miner_body.top + 6), (cx + 7, miner_body.bottom), 3)

        # Head & Face
        head_y = miner_body.top - 8
        pygame.draw.circle(surface, (235, 175, 135), (cx, head_y), 13)

        # White Beard
        pygame.draw.arc(surface, (230, 230, 235), (cx - 11, head_y - 2, 22, 18), 3.14, 0.0, 5)
        pygame.draw.circle(surface, (240, 240, 245), (cx, head_y + 9), 6)

        # Eyes & Nose
        pygame.draw.circle(surface, (40, 30, 30), (cx - 4, head_y - 2), 2)
        pygame.draw.circle(surface, (40, 30, 30), (cx + 4, head_y - 2), 2)
        pygame.draw.circle(surface, (220, 140, 110), (cx, head_y + 2), 3)

        # Miner Helmet (Yellow Mining Hat)
        helmet_rect = pygame.Rect(cx - 15, head_y - 15, 30, 12)
        pygame.draw.ellipse(surface, (245, 195, 30), helmet_rect)
        pygame.draw.rect(surface, (220, 170, 20), (cx - 12, head_y - 17, 24, 8), border_radius=3)
        # Headlamp
        pygame.draw.circle(surface, (255, 255, 230), (cx, head_y - 12), 4)
        pygame.draw.circle(surface, (255, 235, 100), (cx, head_y - 12), 6, width=1)

        # 4. Reeling Mechanism / Winch
        winch_x = cx + 22
        winch_y = cart_rect.top + 14
        pygame.draw.circle(surface, (70, 70, 75), (winch_x, winch_y), 10)
        pygame.draw.circle(surface, (180, 180, 185), (winch_x, winch_y), 7)
        
        # Rotating Crank Handle
        crank_len = 12
        hx = winch_x + math.cos(self.reel_angle) * crank_len
        hy = winch_y + math.sin(self.reel_angle) * crank_len
        pygame.draw.line(surface, (50, 50, 55), (winch_x, winch_y), (hx, hy), 4)
        pygame.draw.circle(surface, (140, 80, 40), (int(hx), int(hy)), 5)
