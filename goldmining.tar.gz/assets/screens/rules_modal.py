"""
RulesModal: In-game rules & controls tutorial popup dialog.
Displays clean summary of game objectives, controls, power-ups, and tips.
"""
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER, COLOR_PANEL_BG,
    COLOR_PANEL_BORDER, get_font
)
from sound_manager import SoundManager

class RulesModal:
    """Manages rules & tutorial modal overlay during gameplay."""
    def __init__(self):
        self.font_title = get_font(34, bold=True)
        self.font_hdr = get_font(18, bold=True)
        self.font_body = get_font(16)
        self.font_btn = get_font(20, bold=True)
        
        cx = VIRTUAL_WIDTH // 2
        self.panel_rect = pygame.Rect(cx - 380, 75, 760, 560)
        self.close_btn = pygame.Rect(cx - 160, 565, 320, 50)
        self.sound = SoundManager.get_instance()

    def handle_event(self, event) -> bool:
        """Returns True if modal should close and resume game."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_SPACE, pygame.K_RETURN):
                self.sound.play('click')
                return True
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.close_btn.collidepoint(event.pos):
                self.sound.play('click')
                return True
        return False

    def draw(self, surface: pygame.Surface, virtual_mouse_pos: tuple = (0, 0)):
        """Renders rules modal popup dialog."""
        # 1. Dark dim backdrop
        overlay = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        surface.blit(overlay, (0, 0))

        # 2. Main Dialog Panel
        panel = pygame.Surface((self.panel_rect.width, self.panel_rect.height), pygame.SRCALPHA)
        panel.fill(COLOR_PANEL_BG)
        surface.blit(panel, self.panel_rect.topleft)
        pygame.draw.rect(surface, COLOR_PANEL_BORDER, self.panel_rect, width=3, border_radius=12)

        # 3. Header Title
        title_surf = self.font_title.render("LUẬT CHƠI & HƯỚNG DẪN ĐIỀU KHIỂN", True, COLOR_GOLD_TEXT)
        surface.blit(title_surf, (self.panel_rect.centerx - title_surf.get_width() // 2, self.panel_rect.top + 20))

        # 4. Rules Sections
        sections = [
            ("MỤC TIÊU:", "Kéo vàng, kim cương để đạt đủ mốc tiền mục tiêu trước khi hết 60 giây."),
            ("THẢ MÓC / BẮN MÓC:", "Nhấn [ Chuột trái ] hoặc phím [ SPACE ] khi móc xoay đến hướng mong muốn."),
            ("NÉM BOM (DYNAMITE):", "Nhấn [ Chuột phải ] khi đang kéo vật nặng để phá hủy và thu hồi móc siêu tốc."),
            ("NƯỚC TĂNG LỰC:", "Nhấn phím [ R ] hoặc click Icon trên HUD (khi mua từ Shop) để kích hoạt sức mạnh kéo nhanh."),
            ("TÚI MÙ BÍ ẨN:", "Khi kéo lên, tự động kích hoạt ngay lập tức 1 trong 3 phần thưởng: Nước tăng lực, +1 Quả bom hoặc Tiền thưởng ($100 - $800)."),
            ("SÁCH SƯU TẦM ĐÁ:", "Khi mua từ Shop, nhân 3 giá trị của toàn bộ tảng đá trong ván chơi tiếp theo.")
        ]

        sy = self.panel_rect.top + 75
        for header, content in sections:
            h_surf = self.font_hdr.render(header, True, (255, 215, 0))
            surface.blit(h_surf, (self.panel_rect.left + 35, sy))
            
            c_surf = self.font_body.render(content, True, COLOR_WHITE)
            surface.blit(c_surf, (self.panel_rect.left + 35, sy + 24))
            sy += 66

        # 5. Close Button ("ĐÃ HIỂU / TIẾP TỤC")
        is_hover = self.close_btn.collidepoint(virtual_mouse_pos)
        btn_col = COLOR_GREEN_BTN_HOVER if is_hover else COLOR_GREEN_BTN
        pygame.draw.rect(surface, btn_col, self.close_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.close_btn, width=2, border_radius=8)
        
        btn_txt = self.font_btn.render("ĐÃ HIỂU (ESC / SPACE)", True, COLOR_WHITE)
        surface.blit(btn_txt, (self.close_btn.centerx - btn_txt.get_width() // 2, self.close_btn.centery - btn_txt.get_height() // 2))
