"""
Constants and game configuration for Gold Miner.
Includes Virtual Canvas dimensions, aspect ratio presets, game states, and Bundled Unicode font helper.
"""
import os
import math
import pygame

# Virtual Canvas (Fixed logical resolution for physics, items, and rendering)
VIRTUAL_WIDTH = 1280
VIRTUAL_HEIGHT = 720
FPS = 60

# Aspect Ratio / Screen Resolution Presets (Name, Width, Height)
ASPECT_RATIO_PRESETS = [
    ("16:9 (Desktop 1280x720)", 1280, 720),
    ("9:16 (Mobile 540x960)", 540, 960),
    ("3:4 (Tablet 768x1024)", 768, 1024),
]

# Top Fixed HUD Bar height & World dimensions
HUD_HEIGHT = 56
GROUND_Y = 130  # Ground lowered by 30px to give ample headspace below HUD
MINE_DEPTH_MAX = VIRTUAL_HEIGHT - 30

# Hook parameters (Wider angle and longer reach to guarantee pulling all items)
HOOK_ORIGIN_X = VIRTUAL_WIDTH // 2
HOOK_ORIGIN_Y = GROUND_Y
HOOK_LENGTH_MIN = 36
HOOK_MAX_ANGLE_DEG = 78.0
HOOK_MAX_ANGLE_RAD = math.radians(HOOK_MAX_ANGLE_DEG)
HOOK_SWING_SPEED = 2.2  # rad/s
HOOK_SHOOT_SPEED = 640.0  # px/s
HOOK_MIN_PULL_SPEED = 70.0  # px/s
HOOK_HEAD_RADIUS = 15

# Physics Factors for Mass/Weight scaling
DEFAULT_STRENGTH_FACTOR = 2.0
BUFFED_STRENGTH_FACTOR = 35.0
TNT_EXPLOSION_RADIUS = 100.0

# Level settings
LEVEL_TIME_LIMIT = 60.0  # seconds per level

# Bundled TrueType Font for Universal Desktop & WebAssembly (Pygbag) Support
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_FILE_PATH = os.path.join(_BASE_DIR, "assets", "fonts", "Roboto-Regular.ttf")

def get_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Returns a pygame.font.Font instance using the bundled Unicode font."""
    try:
        if os.path.exists(FONT_FILE_PATH):
            font = pygame.font.Font(FONT_FILE_PATH, size)
            font.set_bold(bold)
            return font
        # Relative fallback in WASM sandbox
        if os.path.exists("assets/fonts/Roboto-Regular.ttf"):
            font = pygame.font.Font("assets/fonts/Roboto-Regular.ttf", size)
            font.set_bold(bold)
            return font
    except Exception:
        pass

    try:
        font = pygame.font.Font(None, size)
        font.set_bold(bold)
        return font
    except Exception:
        return pygame.font.SysFont("arial", size, bold=bold)

# Target Score by Level progression
def get_target_score(level: int) -> int:
    """Calculate target score curve based on level."""
    base_targets = [
        650,    # Level 1
        1400,   # Level 2
        2300,   # Level 3
        3350,   # Level 4
        4600,   # Level 5
        6000,   # Level 6
        7600,   # Level 7
        9400,   # Level 8
        11400,  # Level 9
        13600   # Level 10
    ]
    if level <= len(base_targets):
        return base_targets[level - 1]
    return base_targets[-1] + (level - len(base_targets)) * 2400

# Color Palette (Rich RGB Values)
COLOR_SKY_TOP = (45, 90, 155)
COLOR_SKY_BOTTOM = (120, 175, 220)
COLOR_GROUND_GRASS = (58, 125, 45)
COLOR_GROUND_DIRT_TOP = (110, 72, 38)
COLOR_GROUND_DIRT_MID = (78, 48, 26)
COLOR_GROUND_DIRT_BOT = (46, 28, 16)
COLOR_GROUND_LAYER_LINE = (35, 20, 10)

# Item Colors
COLOR_GOLD_LIGHT = (255, 230, 80)
COLOR_GOLD_MAIN = (245, 190, 25)
COLOR_GOLD_DARK = (180, 130, 10)
COLOR_GOLD_SHINE = (255, 255, 220)

COLOR_DIAMOND_MAIN = (90, 225, 255)
COLOR_DIAMOND_LIGHT = (220, 250, 255)
COLOR_DIAMOND_DARK = (30, 130, 190)

COLOR_ROCK_LIGHT = (165, 165, 165)
COLOR_ROCK_MAIN = (120, 120, 125)
COLOR_ROCK_DARK = (75, 75, 80)

COLOR_TNT_MAIN = (210, 45, 30)
COLOR_TNT_BAND = (240, 200, 50)
COLOR_TNT_DARK = (130, 25, 15)

COLOR_BAG_MAIN = (190, 140, 75)
COLOR_BAG_STRING = (240, 220, 170)
COLOR_BAG_QUESTION = (255, 240, 80)

COLOR_BOAR_BODY = (120, 75, 45)
COLOR_BOAR_SNOUT = (210, 135, 125)
COLOR_BOAR_TUSK = (245, 245, 235)

# UI Colors
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)
COLOR_GOLD_TEXT = (255, 215, 0)
COLOR_GREEN_BTN = (46, 204, 113)
COLOR_GREEN_BTN_HOVER = (39, 174, 96)
COLOR_RED_BTN = (231, 76, 60)
COLOR_RED_BTN_HOVER = (192, 57, 43)
COLOR_BLUE_BTN = (52, 152, 219)
COLOR_BLUE_BTN_HOVER = (41, 128, 185)
COLOR_PANEL_BG = (30, 22, 18, 230)
COLOR_PANEL_BORDER = (200, 150, 80)
COLOR_HUD_BG = (20, 15, 12, 240)
COLOR_HUD_BORDER = (180, 130, 60)

# Game States (6 States)
class GameStates:
    MENU = "MENU"
    PLAYING = "PLAYING"
    PAUSE = "PAUSE"
    SHOP = "SHOP"
    LEVEL_WIN = "LEVEL_WIN"
    GAME_OVER = "GAME_OVER"

# Hook States (Strict FSM)
class HookStates:
    SWINGING = "SWINGING"
    SHOOTING = "SHOOTING"
    RETRACTING = "RETRACTING"
    IDLE = "IDLE"
