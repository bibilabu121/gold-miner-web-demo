"""
Level generator creating procedural, balanced underground item layouts for each level.
Ensures zero overlapping items, reachable item bounds, and progressive difficulty.
"""
import math
import random
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, GROUND_Y, MINE_DEPTH_MAX, HOOK_ORIGIN_X
)
from entities.item import (
    GoldItem, DiamondItem, RockItem, MysteryBagItem, BoarItem, TNTItem
)

def _is_position_valid(x: float, y: float, radius: float, existing_items: list, min_margin: float = 20.0) -> bool:
    """Checks if the proposed (x, y, radius) overlaps with any existing item or hook origin."""
    # Avoid blocking straight down initial hook position
    if abs(x - HOOK_ORIGIN_X) < 30 and y < GROUND_Y + 75:
        return False

    for item in existing_items:
        ix, iy, ir = item.get_collision_circle()
        dist = math.hypot(x - ix, y - iy)
        if dist < (radius + ir + min_margin):
            return False
    return True

def generate_level(level: int) -> list:
    """Generates a complete list of Item objects for the specified level."""
    items = []
    
    # Boundary bounds for items (Guaranteed within hook's swinging reach)
    min_x = 90
    max_x = VIRTUAL_WIDTH - 90
    min_y = GROUND_Y + 70
    max_y = VIRTUAL_HEIGHT - 65

    def try_add(item_factory, max_attempts=100):
        for _ in range(max_attempts):
            x = random.uniform(min_x, max_x)
            y = random.uniform(min_y, max_y)
            temp = item_factory(x, y)
            if _is_position_valid(x, y, temp.radius, items):
                items.append(temp)
                return True
        return False

    # 1. Level Configurations
    if level == 1:
        # Level 1: Gentle introduction
        # 2 Large Gold, 3 Medium Gold, 2 Small Gold, 1 Diamond, 2 Small Rocks, 1 Mystery Bag
        for _ in range(2): try_add(lambda x, y: GoldItem(x, y, "large"))
        for _ in range(3): try_add(lambda x, y: GoldItem(x, y, "medium"))
        for _ in range(2): try_add(lambda x, y: GoldItem(x, y, "small"))
        try_add(lambda x, y: DiamondItem(x, y))
        for _ in range(2): try_add(lambda x, y: RockItem(x, y, "small"))
        try_add(lambda x, y: MysteryBagItem(x, y))

    elif level == 2:
        # Level 2: Introduce Boar & TNT
        for _ in range(2): try_add(lambda x, y: GoldItem(x, y, "large"))
        for _ in range(3): try_add(lambda x, y: GoldItem(x, y, "medium"))
        for _ in range(3): try_add(lambda x, y: GoldItem(x, y, "small"))
        for _ in range(2): try_add(lambda x, y: DiamondItem(x, y))
        for _ in range(2): try_add(lambda x, y: RockItem(x, y, "large"))
        for _ in range(2): try_add(lambda x, y: RockItem(x, y, "small"))
        try_add(lambda x, y: MysteryBagItem(x, y))
        try_add(lambda x, y: TNTItem(x, y))
        # 1 Boar with diamond
        try_add(lambda x, y: BoarItem(x, y, carries_diamond=True))

    elif level == 3:
        # Level 3: Strategic TNT clusters & multiple boars
        for _ in range(3): try_add(lambda x, y: GoldItem(x, y, "large"))
        for _ in range(4): try_add(lambda x, y: GoldItem(x, y, "medium"))
        for _ in range(2): try_add(lambda x, y: GoldItem(x, y, "small"))
        for _ in range(3): try_add(lambda x, y: DiamondItem(x, y))
        for _ in range(3): try_add(lambda x, y: RockItem(x, y, "large"))
        for _ in range(2): try_add(lambda x, y: MysteryBagItem(x, y))
        for _ in range(2): try_add(lambda x, y: TNTItem(x, y))
        try_add(lambda x, y: BoarItem(x, y, carries_diamond=True))
        try_add(lambda x, y: BoarItem(x, y, carries_diamond=False))

    else:
        # Level 4+: Procedural scale
        num_large_gold = random.randint(2, 4)
        num_med_gold = random.randint(3, 5)
        num_small_gold = random.randint(2, 4)
        num_diamonds = random.randint(2, 4 + min(4, level // 2))
        num_rocks_l = random.randint(2, 4)
        num_rocks_s = random.randint(2, 4)
        num_bags = random.randint(2, 3)
        num_tnt = random.randint(1, 3)
        num_boars = random.randint(1, 2)

        for _ in range(num_large_gold): try_add(lambda x, y: GoldItem(x, y, "large"))
        for _ in range(num_med_gold): try_add(lambda x, y: GoldItem(x, y, "medium"))
        for _ in range(num_small_gold): try_add(lambda x, y: GoldItem(x, y, "small"))
        for _ in range(num_diamonds): try_add(lambda x, y: DiamondItem(x, y))
        for _ in range(num_rocks_l): try_add(lambda x, y: RockItem(x, y, "large"))
        for _ in range(num_rocks_s): try_add(lambda x, y: RockItem(x, y, "small"))
        for _ in range(num_bags): try_add(lambda x, y: MysteryBagItem(x, y))
        for _ in range(num_tnt): try_add(lambda x, y: TNTItem(x, y))
        for _ in range(num_boars): try_add(lambda x, y: BoarItem(x, y, carries_diamond=random.random() > 0.5))

    return items
