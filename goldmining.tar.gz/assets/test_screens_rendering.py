"""
Automated rendering and game-loop integration test.
Simulates all 6 screen transitions (MENU, PLAYING, PAUSE, SHOP, LEVEL_WIN, GAME_OVER),
audio controls, and fullscreen projection.
"""
import os
os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

import pygame
import unittest
from main import GoldMinerGame
from constants import GameStates

class TestGameIntegration(unittest.TestCase):
    def test_full_game_loop_and_screens(self):
        game = GoldMinerGame()
        self.assertEqual(game.current_state, GameStates.MENU)

        # 1. Simulate Menu Screen
        game.update(0.016)
        game.draw()

        # 2. Transition to Playing Screen
        game.set_state(GameStates.PLAYING)
        self.assertEqual(game.current_state, GameStates.PLAYING)
        self.assertGreater(len(game.play_screen.items), 0)

        # 3. Simulate 60 gameplay frames (shooting hook, pulling items)
        game.play_screen.hook.shoot()
        for _ in range(60):
            game.update(0.016)
            game.draw()

        # 4. Transition to PAUSE state & verify modal
        game.set_state(GameStates.PAUSE)
        self.assertEqual(game.current_state, GameStates.PAUSE)
        game.update(0.016)
        game.draw()

        # Resume from PAUSE
        game.set_state(GameStates.PLAYING)
        self.assertEqual(game.current_state, GameStates.PLAYING)

        # 5. Transition to Shop Screen
        game.set_state(GameStates.SHOP)
        self.assertEqual(game.current_state, GameStates.SHOP)
        self.assertGreater(len(game.shop_screen.available_items), 0)
        game.update(0.016)
        game.draw()

        # 6. Transition to Level Win Screen
        game.set_state(GameStates.LEVEL_WIN)
        game.update(0.016)
        game.draw()

        # 7. Transition to Game Over Screen
        game.set_state(GameStates.GAME_OVER)
        game.update(0.016)
        game.draw()

        print("Full 6-state game rendering, Pause modal, and screen projection integration test PASSED!")

if __name__ == "__main__":
    unittest.main()
