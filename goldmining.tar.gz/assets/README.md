# ⛏️ Gold Miner (Đào Vàng Siêu Cấp) - Python Pygame

Game **Đào Vàng (Gold Miner)** chuẩn phong cách Arcade cổ điển, xây dựng hoàn chỉnh trên nền tảng **Pygame + OOP**, hỗ trợ **Đồng bộ tuyệt đối giữa UI và Bộ bắt sự kiện (Strict Input Parity)**, **Lưu và Tiếp tục bàn chơi dở (Resume Game Session)**, **Đồng bộ hóa giao diện nút bấm chuẩn Unicode**, **Trình điều khiển âm thanh BGM/SFX**, **Popup Tạm dừng (Pause Modal)**, và **Đa tỷ lệ màn hình (16:9, 9:16, 3:4, True Native Fullscreen)**.

---

## 🚀 Hướng Dẫn Chạy Game

1. Cài đặt các thư viện:
   ```bash
   pip install pygame numpy
   ```

2. Khởi chạy game:
   ```bash
   python main.py
   ```

3. Chạy toàn bộ bộ test tự động:
   ```bash
   python test_game_logic.py
   python test_screens_rendering.py
   ```

---

## 🎮 Ràng Buộc Đồng Bộ Điều Khiển Tuyệt Đối (Strict Input Parity)

| Thao Tác | Phím / Chuột | Quy Định Bắt Sự Kiện (Code Logic) |
| :--- | :--- | :--- |
| **Thả Móc / Bắn Móc** | **[ Chuột trái ]** hoặc **[ SPACE ]** | **CHỈ NHẬN** `event.button == 1` hoặc `event.key == pygame.K_SPACE`. Tuyệt đối không nhận phím khác. |
| **Ném Bom Hủy Vật Nặng** | **[ Chuột phải ]** | **CHỈ NHẬN** `event.button == 3` (Chuột phải) khi đang kéo vật phẩm. Tuyệt đối không nhận phím bàn phím. |
| **Tạm Dừng Trận Đấu** | **[ ESC ]** hoặc nút **TẠM DỪNG** | **CHỈ NHẬN** `event.key == pygame.K_ESCAPE` hoặc click nút TẠM DỪNG. |
| **Thoát Game Nhanh** | **[ Q ]** hoặc nút **THOÁT GAME** | Thoát hoàn toàn ứng dụng Python an toàn bằng `pygame.quit()` và `sys.exit()`. |
| **Toàn Màn Hình** | **[ F11 ]** hoặc nút **FULLSCREEN** | Chuyển đổi qua lại giữa Fullscreen và Cửa sổ. |
| **Đổi Tỷ Lệ Màn Hình** | Phím `1` (16:9), `2` (9:16), `3` (3:4) | Thay đổi tỷ lệ cửa sổ chuẩn letterbox. |
| **Bật/Tắt Nhạc BGM** | Phím `M` hoặc Nút BGM | Mute / Unmute nhạc nền lặp. |
| **Bật/Tắt Hiệu Ứng SFX**| Phím `S` hoặc Nút SFX | Mute / Unmute âm thanh hiệu ứng. |

---

## 💾 Tính Năng Tiếp Tục Bàn Chơi (Resume Game Session)

- Khi đang chơi (`PLAYING`) mà tạm dừng (`ESC`) rồi chọn **"VỀ MENU CHÍNH"**:
  - Hệ thống tự động ghi nhớ toàn bộ tiến trình màn chơi dở dang (vị trí móc, các vật phẩm còn lại trên sân, điểm số, thời gian còn lại, các vật phẩm hỗ trợ).
  - Tại Menu chính, nút **"TIẾP TỤC TRÒ CHƠI"** sẽ được kích hoạt để người chơi có thể vào lại và chơi tiếp tục ngay lập tức.
  - Nút **"CHƠI MỚI"** sẽ bắt đầu lại trận đấu mới hoàn toàn từ Level 1.

---

## 🎨 Đồng Bộ Giao Diện & Làm Sạch Unicode

- **100% Không có Emoji trong `font.render()`**: Loại bỏ hoàn toàn lỗi hiển thị ô vuông hoặc mất ký tự khi gọi font chữ.
- **Đồng bộ hóa Nút bấm**: Bo góc nhẹ (`border_radius=8`), viết hoa chuẩn xác:
  - `"CHƠI MỚI"`
  - `"TIẾP TỤC TRÒ CHƠI"`
  - `"TẠM DỪNG"`
  - `"TIẾP TỤC"`
  - `"CỬA HÀNG"`
  - `"THOÁT GAME (Q)"`
  - `"CHƠI LẠI"`
