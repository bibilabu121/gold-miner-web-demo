"""
Automated Web Packaging & Release Builder for Gold Miner (Pygbag / WASM).
Compiles Pygame source into WebAssembly, patches HTML/CSS for premium dark luxury theme (#0a0b10),
bundles TTF Unicode font, enables crisp pixel rendering, and creates a standalone release folder
ready to be pushed to GitHub Pages without exposing raw Python source code.
"""
import os
import sys
import shutil
import subprocess

if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def main():
    print("=" * 70)
    print(" [BUILDER] GOLD MINER - PYGBAG WEBASSEMBLY BUILDER")
    print("=" * 70)

    project_root = os.path.dirname(os.path.abspath(__file__))
    build_web_dir = os.path.join(project_root, "build", "web")
    workflows_source = os.path.join(project_root, ".github", "workflows", "deploy.yml")

    # 1. Ensure fonts directory is bundled
    fonts_dir = os.path.join(project_root, "assets", "fonts")
    os.makedirs(fonts_dir, exist_ok=True)
    font_target = os.path.join(fonts_dir, "Roboto-Regular.ttf")
    if not os.path.exists(font_target):
        for candidate in [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeui.ttf"]:
            if os.path.exists(candidate):
                shutil.copy2(candidate, font_target)
                print(f"      + Bundled Unicode font from: {candidate}")
                break

    # 2. Set UTF-8 environment variable for Pygbag on Windows
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"

    print("\n[1/3] Compiling Pygame project to WebAssembly (Pygbag)...")
    cmd = [sys.executable, "-m", "pygbag", "--build", "."]
    result = subprocess.run(cmd, cwd=project_root, env=env)
    
    if result.returncode != 0:
        print("\n[ERROR] Build failed! Please check error output above.")
        sys.exit(result.returncode)

    print(f"\n[2/3] Customizing WebAssembly theme & CSS in: {build_web_dir}")

    # 3. Patch index.html for Premium Dark Theme (#0a0b10), Centered Canvas, Crisp Font, and Auto-start
    index_html_path = os.path.join(build_web_dir, "index.html")
    if os.path.exists(index_html_path):
        with open(index_html_path, "r", encoding="utf-8") as f:
            html_content = f.read()

        # Fix path lookup in Python bootstrap
        old_loader = 'platform.run_main(PyConfig, loaderhome= appdir / "assets", loadermain=None)'
        new_loader = 'platform.run_main(PyConfig, loaderhome= (appdir / "assets") if (appdir / "assets").exists() else appdir, loadermain=None)'
        if old_loader in html_content:
            html_content = html_content.replace(old_loader, new_loader)

        old_main = 'main = appdir / "assets" / "main.py"'
        new_main = 'main = (appdir / "assets" / "main.py") if (appdir / "assets" / "main.py").is_file() else (appdir / "main.py")'
        if old_main in html_content:
            html_content = html_content.replace(old_main, new_main)

        # Replace gray background with luxury dark theme #0a0b10
        html_content = html_content.replace('platform.document.body.style.background = "#7f7f7f"', 'platform.document.body.style.background = "#0a0b10"')
        html_content = html_content.replace('background-color: #707070', 'background-color: #0a0b10')
        html_content = html_content.replace('background-color: #7f7f7f', 'background-color: #0a0b10')

        # Inject Custom CSS for Centered Canvas, Anti-blur, and Luxury Dark Theme
        custom_css = """
<style>
    body, html {
        margin: 0;
        padding: 0;
        width: 100vw;
        height: 100vh;
        background-color: #0a0b10 !important;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    #canvas {
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.95);
        border-radius: 8px;
        image-rendering: -webkit-optimize-contrast;
        image-rendering: crisp-edges;
        max-width: 100vw;
        max-height: 100vh;
    }
    #infobox {
        background: rgba(15, 20, 30, 0.9) !important;
        color: #ffd700 !important;
        border: 2px solid #c89650 !important;
        border-radius: 8px !important;
        font-weight: bold !important;
        padding: 12px 24px !important;
        font-size: 18px !important;
        box-shadow: 0 0 20px rgba(200, 150, 80, 0.4) !important;
        cursor: pointer !important;
    }
</style>
</head>
"""
        if "</head>" in html_content:
            html_content = html_content.replace("</head>", custom_css)

        # Update prompt message
        html_content = html_content.replace('Ready to start ! Please click/touch page', '⛏️ CLICK HOẶC CHẠM VÀO MÀN HÌNH ĐỂ BẮT ĐẦU CHƠI ⛏️')

        with open(index_html_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        print("      + Patched index.html with Dark Luxury Theme (#0a0b10) and Crisp Canvas.")

    # 4. Embed GitHub Actions workflow inside build/web/.github/workflows/deploy.yml
    target_workflows_dir = os.path.join(build_web_dir, ".github", "workflows")
    os.makedirs(target_workflows_dir, exist_ok=True)
    if os.path.exists(workflows_source):
        shutil.copy2(workflows_source, os.path.join(target_workflows_dir, "deploy.yml"))
        print(f"      + Added GitHub Pages workflow: {target_workflows_dir}")

    # 5. Create .nojekyll to prevent GitHub Pages from ignoring files starting with _
    nojekyll_path = os.path.join(build_web_dir, ".nojekyll")
    with open(nojekyll_path, "w", encoding="utf-8") as f:
        f.write("")
    print("      + Created .nojekyll for GitHub Pages asset compatibility.")

    # 6. Create README for the public web repository
    public_readme_path = os.path.join(build_web_dir, "README.md")
    with open(public_readme_path, "w", encoding="utf-8") as f:
        f.write("""# ⛏️ Gold Miner - WebAssembly (Pygbag HTML5 Demo)

Trò chơi **Đào Vàng (Gold Miner)** được biên dịch sang **HTML5 / WebAssembly (WASM)** bằng **Pygbag** để chơi trực tiếp trên trình duyệt Web qua GitHub Pages.

---

## 🎮 Cách Chơi Trực Tuyến

Truy cập đường dẫn GitHub Pages: **[https://bibilabu121.github.io/gold-miner-web-demo/](https://bibilabu121.github.io/gold-miner-web-demo/)**

### 🕹️ Phím Điều Khiển:
- **Thả Móc**: `[ Chuột trái ]` hoặc phím `[ SPACE ]`.
- **Ném Bom Hủy Vật Nặng**: `[ Chuột phải ]`.
- **Tạm Dừng Trận Đấu**: `[ ESC ]` hoặc nút **TẠM DỪNG** trên HUD.
- **Toàn Màn Hình**: `[ F11 ]` hoặc nút **FULLSCREEN**.
- **Chế Độ Màn Hình**: Phím `1` (16:9), `2` (9:16), `3` (3:4).
""")
    print("      + Generated README.md for Public Web Repository.")

    print("\n[3/3] Build completed successfully!")

if __name__ == "__main__":
    main()
