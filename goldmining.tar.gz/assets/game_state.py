"""
Global GameState class managing persistent progress, items, money, score,
level progression, power-up buffs, inventory slots, and ongoing session saving.
"""
from constants import get_target_score, LEVEL_TIME_LIMIT

class GameState:
    """Stores and manages the global state of the Gold Miner game."""
    def __init__(self):
        self.current_level = 1
        self.total_money = 0
        self.target_money = get_target_score(1)
        self.bombs_count = 3
        
        # Power-up Buffs & Inventory
        self.has_strength_drink = False          # Active super speed state
        self.purchased_strength_drink = False    # Stored in HUD inventory for manual R activation
        self.has_clover = False                  # Lucky clover active
        self.has_diamond_polish = False          # Diamond polish active
        self.has_rock_book = False               # Rock collector book active (x3 rock value)

        # Level runtime
        self.level_timer = LEVEL_TIME_LIMIT
        self.high_score = 0
        self.items_collected_this_level = 0
        self.money_earned_this_level = 0
        
        # Saved session flag
        self.has_saved_session = False

    def start_game(self):
        """Initializes a brand new game session from Level 1."""
        self.current_level = 1
        self.total_money = 0
        self.target_money = get_target_score(1)
        self.bombs_count = 3
        self.clear_buffs()
        self.level_timer = LEVEL_TIME_LIMIT
        self.items_collected_this_level = 0
        self.money_earned_this_level = 0
        self.has_saved_session = True

    def reset_to_start(self):
        """Alias for start_game."""
        self.start_game()

    def next_level(self):
        """Advances to the next level, resets level timer and single-level consumable buffs."""
        self.current_level += 1
        self.target_money = get_target_score(self.current_level)
        self.level_timer = LEVEL_TIME_LIMIT
        self.clear_buffs()
        self.items_collected_this_level = 0
        self.money_earned_this_level = 0
        self.has_saved_session = True

    def clear_buffs(self):
        """Resets single-level power-ups purchased in shop or collected."""
        self.has_strength_drink = False
        self.purchased_strength_drink = False
        self.has_clover = False
        self.has_diamond_polish = False
        self.has_rock_book = False

    def activate_strength_drink(self) -> bool:
        """Consumes purchased strength drink from HUD inventory and activates speed buff."""
        if self.purchased_strength_drink and not self.has_strength_drink:
            self.purchased_strength_drink = False
            self.has_strength_drink = True
            return True
        return False

    def add_money(self, amount: int):
        """Adds money to total and updates high score."""
        self.total_money += amount
        self.money_earned_this_level += amount
        self.items_collected_this_level += 1
        if self.total_money > self.high_score:
            self.high_score = self.total_money

    def record_item_collected(self, estimated_value: int = 0):
        """Records that an item (like power-up bag) was collected."""
        self.items_collected_this_level += 1

    def spend_money(self, amount: int) -> bool:
        """Attempts to spend money. Returns True if successful."""
        if self.total_money >= amount:
            self.total_money -= amount
            return True
        return False

    def use_bomb(self) -> bool:
        """Consumes a bomb from inventory. Returns True if bomb was available."""
        if self.bombs_count > 0:
            self.bombs_count -= 1
            return True
        return False

    def add_bomb(self, count: int = 1):
        """Adds bombs to inventory (capped at max 5)."""
        self.bombs_count = min(5, self.bombs_count + count)

    def is_level_won(self) -> bool:
        """Checks if current money meets or exceeds the target score."""
        return self.total_money >= self.target_money

    def is_time_up(self) -> bool:
        """Checks if the 60-second level timer has elapsed."""
        return self.level_timer <= 0.0
