"""
PauseModal: In-game pause menu with clean uppercase text, consistent buttons,
audio controls, restart level, resume, and clean quit options.
Optimized for fixed 16:9 display with Fullscreen button removed.
"""
import sys
import pygame
from constants import (
    VIRTUAL_WIDTH, VIRTUAL_HEIGHT, COLOR_WHITE, COLOR_GOLD_TEXT,
    COLOR_GREEN_BTN, COLOR_GREEN_BTN_HOVER, COLOR_RED_BTN,
    COLOR_RED_BTN_HOVER, COLOR_BLUE_BTN, COLOR_BLUE_BTN_HOVER,
    COLOR_PANEL_BG, COLOR_PANEL_BORDER, GameStates, get_font
)
from sound_manager import SoundManager

class PauseModal:
    """Manages in-game pause dialog and settings adjustment."""
    def __init__(self):
        self.font_title = get_font(38, bold=True)
        self.font_btn = get_font(19, bold=True)
        self.font_label = get_font(16, bold=True)
        
        self.panel_rect = pygame.Rect(VIRTUAL_WIDTH // 2 - 260, 80, 520, 530)
        
        # Interactive buttons
        self.resume_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 180, 150, 360, 48)
        self.restart_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 180, 208, 360, 48)
        
        # Audio row
        self.bgm_toggle_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 180, 268, 175, 44)
        self.sfx_toggle_btn = pygame.Rect(VIRTUAL_WIDTH // 2 + 5, 268, 175, 44)
        
        # Volume row
        self.vol_down_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 180, 324, 50, 40)
        self.vol_up_btn = pygame.Rect(VIRTUAL_WIDTH // 2 + 130, 324, 50, 40)
        
        # Menu return
        self.menu_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 180, 394, 360, 48)

        # Quit application
        self.quit_app_btn = pygame.Rect(VIRTUAL_WIDTH // 2 - 180, 452, 360, 48)

        self.sound = SoundManager.get_instance()

    def handle_event(self, event, game_state, screen_manager=None, play_screen=None) -> str:
        """Processes pause menu inputs and settings changes."""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_SPACE):
                self.sound.play('click')
                return GameStates.PLAYING
            elif event.key == pygame.K_r and play_screen:
                self.sound.play('click')
                play_screen.start_level(game_state)
                game_state.level_timer = 60.0
                return GameStates.PLAYING
            elif event.key == pygame.K_q:
                # Clean exit application
                pygame.quit()
                sys.exit()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos

            # Resume
            if self.resume_btn.collidepoint(pos):
                self.sound.play('click')
                return GameStates.PLAYING

            # Restart Level
            if self.restart_btn.collidepoint(pos) and play_screen:
                self.sound.play('click')
                play_screen.start_level(game_state)
                game_state.level_timer = 60.0
                return GameStates.PLAYING

            # BGM Toggle
            if self.bgm_toggle_btn.collidepoint(pos):
                self.sound.toggle_bgm()
                self.sound.play('click')
                return GameStates.PAUSE

            # SFX Toggle
            if self.sfx_toggle_btn.collidepoint(pos):
                self.sound.toggle_sfx()
                self.sound.play('click')
                return GameStates.PAUSE

            # Volume Down
            if self.vol_down_btn.collidepoint(pos):
                self.sound.decrease_volume(0.1)
                self.sound.play('click')
                return GameStates.PAUSE

            # Volume Up
            if self.vol_up_btn.collidepoint(pos):
                self.sound.increase_volume(0.1)
                self.sound.play('click')
                return GameStates.PAUSE

            # Return to Menu (Preserve active game session)
            if self.menu_btn.collidepoint(pos):
                self.sound.play('click')
                game_state.has_saved_session = True
                self.sound.stop_bgm()
                return GameStates.MENU

            # Quit Application
            if self.quit_app_btn.collidepoint(pos):
                self.sound.play('click')
                pygame.quit()
                sys.exit()

        return GameStates.PAUSE

    def draw(self, surface: pygame.Surface, game_state, screen_manager, virtual_mouse_pos: tuple = (0, 0)):
        """Renders the pause dialog modal overlay."""
        # 1. Dark semi-transparent backdrop
        overlay = pygame.Surface((VIRTUAL_WIDTH, VIRTUAL_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surface.blit(overlay, (0, 0))

        # 2. Main Dialog Panel
        panel = pygame.Surface((self.panel_rect.width, self.panel_rect.height), pygame.SRCALPHA)
        panel.fill(COLOR_PANEL_BG)
        surface.blit(panel, self.panel_rect.topleft)
        pygame.draw.rect(surface, COLOR_PANEL_BORDER, self.panel_rect, width=3, border_radius=12)

        # 3. Header Title
        title_surf = self.font_title.render("TẠM DỪNG TRẬN ĐẤU", True, COLOR_GOLD_TEXT)
        surface.blit(title_surf, (self.panel_rect.centerx - title_surf.get_width() // 2, self.panel_rect.top + 20))

        mx, my = virtual_mouse_pos

        # Button 1: TIẾP TỤC
        is_res_hover = self.resume_btn.collidepoint((mx, my))
        res_col = COLOR_GREEN_BTN_HOVER if is_res_hover else COLOR_GREEN_BTN
        pygame.draw.rect(surface, res_col, self.resume_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.resume_btn, width=2, border_radius=8)
        res_txt = self.font_btn.render("TIẾP TỤC (ESC / SPACE)", True, COLOR_WHITE)
        surface.blit(res_txt, (self.resume_btn.centerx - res_txt.get_width() // 2, self.resume_btn.centery - res_txt.get_height() // 2))

        # Button 2: CHƠI LẠI MÀN NÀY
        is_rst_hover = self.restart_btn.collidepoint((mx, my))
        rst_col = COLOR_BLUE_BTN_HOVER if is_rst_hover else COLOR_BLUE_BTN
        pygame.draw.rect(surface, rst_col, self.restart_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.restart_btn, width=2, border_radius=8)
        rst_txt = self.font_btn.render("CHƠI LẠI MÀN NÀY (R)", True, COLOR_WHITE)
        surface.blit(rst_txt, (self.restart_btn.centerx - rst_txt.get_width() // 2, self.restart_btn.centery - rst_txt.get_height() // 2))

        # Row 3: Audio Toggles
        is_bgm_hover = self.bgm_toggle_btn.collidepoint((mx, my))
        bgm_base = (40, 110, 70) if not self.sound.is_bgm_muted else (110, 45, 45)
        if is_bgm_hover:
            bgm_base = (55, 140, 90) if not self.sound.is_bgm_muted else (140, 60, 60)
        pygame.draw.rect(surface, bgm_base, self.bgm_toggle_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.bgm_toggle_btn, width=1, border_radius=8)
        bgm_label = "BẬT" if not self.sound.is_bgm_muted else "TẮT"
        bgm_txt = self.font_label.render(f"BGM: {bgm_label}", True, COLOR_WHITE)
        surface.blit(bgm_txt, (self.bgm_toggle_btn.centerx - bgm_txt.get_width() // 2, self.bgm_toggle_btn.centery - bgm_txt.get_height() // 2))

        is_sfx_hover = self.sfx_toggle_btn.collidepoint((mx, my))
        sfx_base = (40, 110, 70) if not self.sound.is_sfx_muted else (110, 45, 45)
        if is_sfx_hover:
            sfx_base = (55, 140, 90) if not self.sound.is_sfx_muted else (140, 60, 60)
        pygame.draw.rect(surface, sfx_base, self.sfx_toggle_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.sfx_toggle_btn, width=1, border_radius=8)
        sfx_label = "BẬT" if not self.sound.is_sfx_muted else "TẮT"
        sfx_txt = self.font_label.render(f"SFX: {sfx_label}", True, COLOR_WHITE)
        surface.blit(sfx_txt, (self.sfx_toggle_btn.centerx - sfx_txt.get_width() // 2, self.sfx_toggle_btn.centery - sfx_txt.get_height() // 2))

        # Row 4: Volume Bar (- [=======] +)
        pygame.draw.rect(surface, (60, 60, 70), self.vol_down_btn, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, self.vol_down_btn, width=1, border_radius=6)
        m_txt = self.font_label.render("-", True, COLOR_WHITE)
        surface.blit(m_txt, (self.vol_down_btn.centerx - m_txt.get_width() // 2, self.vol_down_btn.centery - m_txt.get_height() // 2))

        pygame.draw.rect(surface, (60, 60, 70), self.vol_up_btn, border_radius=6)
        pygame.draw.rect(surface, COLOR_WHITE, self.vol_up_btn, width=1, border_radius=6)
        p_txt = self.font_label.render("+", True, COLOR_WHITE)
        surface.blit(p_txt, (self.vol_up_btn.centerx - p_txt.get_width() // 2, self.vol_up_btn.centery - p_txt.get_height() // 2))

        vol_bar_rect = pygame.Rect(self.panel_rect.centerx - 110, 332, 220, 22)
        pygame.draw.rect(surface, (30, 25, 20), vol_bar_rect, border_radius=4)
        fill_w = int(220 * self.sound.volume_level)
        if fill_w > 0:
            fill_rect = pygame.Rect(self.panel_rect.centerx - 110, 332, fill_w, 22)
            pygame.draw.rect(surface, COLOR_GOLD_TEXT, fill_rect, border_radius=4)
        pygame.draw.rect(surface, COLOR_WHITE, vol_bar_rect, width=1, border_radius=4)

        pct_txt = get_font(13, bold=True).render(f"ÂM LƯỢNG: {int(self.sound.volume_level * 100)}%", True, COLOR_WHITE)
        surface.blit(pct_txt, (self.panel_rect.centerx - pct_txt.get_width() // 2, 360))

        # Button 5: VỀ MENU CHÍNH
        is_menu_hover = self.menu_btn.collidepoint((mx, my))
        menu_col = (180, 120, 40) if is_menu_hover else (140, 90, 30)
        pygame.draw.rect(surface, menu_col, self.menu_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.menu_btn, width=2, border_radius=8)
        menu_txt = self.font_btn.render("VỀ MENU CHÍNH", True, COLOR_WHITE)
        surface.blit(menu_txt, (self.menu_btn.centerx - menu_txt.get_width() // 2, self.menu_btn.centery - menu_txt.get_height() // 2))

        # Button 6: THOÁT GAME (Q)
        is_quit_hover = self.quit_app_btn.collidepoint((mx, my))
        quit_col = COLOR_RED_BTN_HOVER if is_quit_hover else COLOR_RED_BTN
        pygame.draw.rect(surface, quit_col, self.quit_app_btn, border_radius=8)
        pygame.draw.rect(surface, COLOR_WHITE, self.quit_app_btn, width=2, border_radius=8)
        quit_txt = self.font_btn.render("THOÁT GAME (Q)", True, COLOR_WHITE)
        surface.blit(quit_txt, (self.quit_app_btn.centerx - quit_txt.get_width() // 2, self.quit_app_btn.centery - quit_txt.get_height() // 2))
