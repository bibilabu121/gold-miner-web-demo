"""
Gold Miner Game - Main Entry Point
Modular OOP architecture with Virtual Canvas, Letterboxing, Native Fullscreen,
Strict Time-Up Rule, Resume Game Session, In-game HUD Controls, Pause Modal,
Audio Controller, and WebAssembly (Pygbag / WASM / Desktop) dual-runtime compatibility.
"""
import sys
import asyncio
import pygame
from constants import (
    FPS, GameStates, VIRTUAL_WIDTH, VIRTUAL_HEIGHT
)
from screen_manager import ScreenManager
from game_state import GameState
from sound_manager import SoundManager
from screens.menu_screen import MenuScreen
from screens.play_screen import PlayScreen
from screens.pause_modal import PauseModal
from screens.shop_screen import ShopScreen
from screens.result_screens import LevelWinScreen, GameOverScreen

class GoldMinerGame:
    """Main Game controller managing Display, Virtual Canvas projection, State Changes, and Game Loop."""
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Gold Miner - Đào Vàng Siêu Cấp")
        
        # Display & Virtual Canvas projection manager
        self.screen_manager = ScreenManager()
        self.clock = pygame.time.Clock()
        self.running = True

        # Initialize Game Components
        self.game_state = GameState()
        self.sound_manager = SoundManager.get_instance()

        # Initialize Screen Controllers
        self.current_state = GameStates.MENU
        self.menu_screen = MenuScreen()
        self.play_screen = PlayScreen()
        self.pause_modal = PauseModal()
        self.shop_screen = ShopScreen()
        self.level_win_screen = LevelWinScreen()
        self.game_over_screen = GameOverScreen()

    def set_state(self, new_state: str):
        """Switches game state and triggers state-entry initialization hooks."""
        old_state = self.current_state
        self.current_state = new_state

        if new_state == GameStates.PLAYING:
            if old_state in (GameStates.GAME_OVER, GameStates.SHOP) or len(self.play_screen.items) == 0:
                self.play_screen.start_level(self.game_state)
            else:
                self.sound_manager.start_bgm()
                
        elif new_state == GameStates.SHOP:
            self.shop_screen.generate_shop_inventory(self.game_state)

        elif new_state == GameStates.GAME_OVER:
            # Clear active session on Game Over
            self.game_state.has_saved_session = False

    def handle_events(self):
        """Routes Pygame events with Virtual Canvas mouse coordinate translation."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            # Global Hotkey: F11 for Fullscreen
            if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                self.screen_manager.toggle_fullscreen()
                continue

            # Transform mouse coordinates to Virtual Canvas space
            transformed_event = event
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                vx, vy = self.screen_manager.display_to_virtual(event.pos)
                if event.type == pygame.MOUSEMOTION:
                    transformed_event = pygame.event.Event(event.type, {'pos': (vx, vy), 'rel': event.rel, 'buttons': event.buttons})
                else:
                    transformed_event = pygame.event.Event(event.type, {'pos': (vx, vy), 'button': event.button})

            new_state = self.current_state
            
            if self.current_state == GameStates.MENU:
                new_state = self.menu_screen.handle_event(transformed_event, self.game_state, self.screen_manager, self.play_screen)
            elif self.current_state == GameStates.PLAYING:
                new_state = self.play_screen.handle_event(transformed_event, self.game_state, self.screen_manager)
            elif self.current_state == GameStates.PAUSE:
                new_state = self.pause_modal.handle_event(transformed_event, self.game_state, self.screen_manager, self.play_screen)
            elif self.current_state == GameStates.SHOP:
                new_state = self.shop_screen.handle_event(transformed_event, self.game_state)
            elif self.current_state == GameStates.LEVEL_WIN:
                new_state = self.level_win_screen.handle_event(transformed_event, self.game_state)
            elif self.current_state == GameStates.GAME_OVER:
                new_state = self.game_over_screen.handle_event(transformed_event, self.game_state)

            if new_state != self.current_state:
                self.set_state(new_state)

    def update(self, dt: float):
        """Updates animations and game logic for the current screen with Delta Time."""
        if self.current_state == GameStates.MENU:
            self.menu_screen.update(dt)
        elif self.current_state == GameStates.PLAYING:
            new_state = self.play_screen.update(dt, self.game_state)
            if new_state != self.current_state:
                self.set_state(new_state)
        elif self.current_state == GameStates.PAUSE:
            # Game is frozen during pause - do not advance physics or level timer
            pass

    def draw(self):
        """Renders to Virtual Canvas and projects letterboxed onto physical display."""
        v_surface = self.screen_manager.virtual_surface
        raw_mouse = pygame.mouse.get_pos()
        virtual_mouse_pos = self.screen_manager.display_to_virtual(raw_mouse)

        if self.current_state == GameStates.MENU:
            self.menu_screen.draw(v_surface, self.game_state, self.screen_manager, virtual_mouse_pos)
        elif self.current_state == GameStates.PLAYING:
            self.play_screen.draw(v_surface, self.game_state, virtual_mouse_pos)
        elif self.current_state == GameStates.PAUSE:
            # Draw frozen play screen under pause modal
            self.play_screen.draw(v_surface, self.game_state, virtual_mouse_pos)
            self.pause_modal.draw(v_surface, self.game_state, self.screen_manager, virtual_mouse_pos)
        elif self.current_state == GameStates.SHOP:
            self.shop_screen.draw(v_surface, self.game_state, virtual_mouse_pos)
        elif self.current_state == GameStates.LEVEL_WIN:
            self.play_screen.draw(v_surface, self.game_state)
            self.level_win_screen.draw(v_surface, self.game_state, virtual_mouse_pos)
        elif self.current_state == GameStates.GAME_OVER:
            self.play_screen.draw(v_surface, self.game_state)
            self.game_over_screen.draw(v_surface, self.game_state, virtual_mouse_pos)

        # Scale and project onto physical display surface with letterboxing
        self.screen_manager.render_to_display()

    async def run_async(self):
        """Main game execution loop with asyncio sleep for browser WebAssembly / Pygbag."""
        while self.running:
            raw_dt = self.clock.tick(FPS) / 1000.0
            dt = min(raw_dt, 0.1)

            self.handle_events()
            self.update(dt)
            self.draw()

            # Yield control to browser rendering loop
            await asyncio.sleep(0)

        pygame.quit()
        sys.exit()

async def main():
    """Main async entrypoint."""
    game = GoldMinerGame()
    await game.run_async()

if __name__ == "__main__":
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # WebAssembly / Pygbag active event loop
        asyncio.create_task(main())
    else:
        # Standalone Python execution
        asyncio.run(main())
