"""
Visual effects system: Particles, Explosions, Sparkles, and Floating Text indicators.
Includes Unicode font support for Vietnamese floating alerts.
"""
import math
import random
import pygame
from constants import COLOR_WHITE, COLOR_GOLD_TEXT, get_font

class Particle:
    """A generic visual particle for sparks, smoke, and debris."""
    def __init__(self, x: float, y: float, vx: float, vy: float, color: tuple, size: float, lifetime: float, is_smoke: bool = False):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.color = color
        self.original_size = size
        self.size = size
        self.lifetime = lifetime
        self.max_lifetime = lifetime
        self.is_smoke = is_smoke

    def update(self, dt: float) -> bool:
        """Updates particle position and life. Returns False when expired."""
        self.lifetime -= dt
        if self.lifetime <= 0:
            return False
        
        self.x += self.vx * dt
        self.y += self.vy * dt

        if self.is_smoke:
            self.vy -= 15.0 * dt  # float upwards
            self.vx *= 0.95
            self.size = self.original_size * (1.0 + (1.0 - self.lifetime / self.max_lifetime) * 1.5)
        else:
            self.vy += 200.0 * dt  # gravity
            self.size = max(1.0, self.original_size * (self.lifetime / self.max_lifetime))
            
        return True

    def draw(self, surface: pygame.Surface):
        """Draws the particle onto the given surface."""
        alpha_ratio = max(0.0, min(1.0, self.lifetime / self.max_lifetime))
        alpha = int(alpha_ratio * 255)
        
        surf = pygame.Surface((int(self.size * 2 + 2), int(self.size * 2 + 2)), pygame.SRCALPHA)
        col = (*self.color[:3], alpha)
        pygame.draw.circle(surf, col, (int(self.size + 1), int(self.size + 1)), int(self.size))
        surface.blit(surf, (self.x - self.size - 1, self.y - self.size - 1))

class Explosion:
    """An expanding fiery explosion with shockwaves and debris."""
    def __init__(self, x: float, y: float, radius: float = 100.0):
        self.x = x
        self.y = y
        self.max_radius = radius
        self.current_radius = 5.0
        self.duration = 0.45
        self.timer = self.duration
        self.particles = []
        
        # Spawn burst particles
        for _ in range(35):
            angle = random.uniform(0, 6.28)
            speed = random.uniform(80, 320)
            vx = speed * random.uniform(0.7, 1.0) * (1 if random.random() > 0.5 else -1)
            vy = speed * random.uniform(0.7, 1.0) * (1 if random.random() > 0.5 else -1)
            color = random.choice([
                (255, 220, 60),
                (255, 120, 20),
                (230, 40, 20),
                (80, 80, 80)
            ])
            self.particles.append(Particle(
                x, y, vx, vy, color,
                size=random.uniform(4, 9),
                lifetime=random.uniform(0.3, 0.6),
                is_smoke=(color == (80, 80, 80))
            ))

    def update(self, dt: float) -> bool:
        """Updates explosion animation."""
        self.timer -= dt
        if self.timer <= 0:
            return False
        
        progress = 1.0 - (self.timer / self.duration)
        self.current_radius = self.max_radius * (progress ** 0.5)

        # Update inner particles
        self.particles = [p for p in self.particles if p.update(dt)]
        return True

    def draw(self, surface: pygame.Surface):
        """Draws the fiery explosion blast and shockwave."""
        progress = 1.0 - (self.timer / self.duration)
        alpha = int(max(0, (1.0 - progress) * 220))
        
        # Shockwave / Blast surface
        size = int(self.current_radius * 2 + 10)
        blast_surf = pygame.Surface((size, size), pygame.SRCALPHA)
        center = (size // 2, size // 2)

        # Outer orange ring
        if self.current_radius > 6:
            pygame.draw.circle(blast_surf, (255, 140, 20, alpha), center, int(self.current_radius), int(max(2, self.current_radius * 0.25)))
        # Middle fiery core
        if self.current_radius * 0.7 > 3:
            pygame.draw.circle(blast_surf, (255, 230, 70, min(255, int(alpha * 1.3))), center, int(self.current_radius * 0.7))
        # Inner white flash
        if self.current_radius * 0.35 > 2:
            pygame.draw.circle(blast_surf, (255, 255, 240, min(255, int(alpha * 1.5))), center, int(self.current_radius * 0.35))

        surface.blit(blast_surf, (self.x - size // 2, self.y - size // 2))

        # Draw particles
        for p in self.particles:
            p.draw(surface)

class FloatingText:
    """Floating score or notification text that drifts up and fades out."""
    def __init__(self, text: str, x: float, y: float, color: tuple = COLOR_GOLD_TEXT, font_size: int = 24, duration: float = 1.2):
        self.text = text
        self.x = x
        self.y = y
        self.color = color
        self.duration = duration
        self.timer = duration
        self.font = get_font(font_size, bold=True)
        self.vy = -55.0  # float up

    def update(self, dt: float) -> bool:
        """Updates text position and lifetime."""
        self.timer -= dt
        if self.timer <= 0:
            return False
        self.y += self.vy * dt
        return True

    def draw(self, surface: pygame.Surface):
        """Renders text with dark outline and alpha fade."""
        alpha = int(max(0, min(255, (self.timer / self.duration) * 255)))
        
        # Outline for crisp readability
        text_outline = self.font.render(self.text, True, (0, 0, 0))
        text_core = self.font.render(self.text, True, self.color)
        
        surf = pygame.Surface((text_core.get_width() + 6, text_core.get_height() + 6), pygame.SRCALPHA)
        
        # Draw 4-way outline
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)]:
            surf.blit(text_outline, (dx + 3, dy + 3))
        surf.blit(text_core, (3, 3))
        
        surf.set_alpha(alpha)
        surface.blit(surf, (self.x - surf.get_width() // 2, self.y - surf.get_height() // 2))

class EffectManager:
    """Manages all active particles, explosions, and floating text."""
    def __init__(self):
        self.explosions = []
        self.floating_texts = []
        self.sparkles = []

    def add_explosion(self, x: float, y: float, radius: float = 100.0):
        self.explosions.append(Explosion(x, y, radius))

    def add_floating_text(self, text: str, x: float, y: float, color: tuple = COLOR_GOLD_TEXT, font_size: int = 26, duration: float = 1.6):
        self.floating_texts.append(FloatingText(text, x, y, color, font_size, duration=duration))

    def add_sparkle(self, x: float, y: float, color: tuple = (255, 255, 200)):
        for _ in range(6):
            ang = random.uniform(0, 6.28)
            spd = random.uniform(20, 80)
            self.sparkles.append(Particle(
                x, y, math.cos(ang) * spd, math.sin(ang) * spd,
                color=color, size=random.uniform(2, 4), lifetime=random.uniform(0.2, 0.5)
            ))

    def clear(self):
        self.explosions.clear()
        self.floating_texts.clear()
        self.sparkles.clear()

    def update(self, dt: float):
        self.explosions = [e for e in self.explosions if e.update(dt)]
        self.floating_texts = [ft for ft in self.floating_texts if ft.update(dt)]
        self.sparkles = [s for s in self.sparkles if s.update(dt)]

    def draw(self, surface: pygame.Surface):
        for s in self.sparkles:
            s.draw(surface)
        for e in self.explosions:
            e.draw(surface)
        for ft in self.floating_texts:
            ft.draw(surface)
