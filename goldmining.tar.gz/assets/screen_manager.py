"""
ScreenManager: Handles 16:9 Virtual Canvas rendering (1280x720),
letterboxing, and input coordinate translation with aspect ratio presets support.
"""
import pygame
from constants import VIRTUAL_WIDTH, VIRTUAL_HEIGHT, ASPECT_RATIO_PRESETS

class ScreenManager:
    """Manages the 1280x720 canvas rendering and input coordinate mapping."""
    def __init__(self):
        self.virtual_width = VIRTUAL_WIDTH
        self.virtual_height = VIRTUAL_HEIGHT
        
        # Fixed 1280x720 Virtual Canvas where all game graphics and physics are rendered
        self.virtual_surface = pygame.Surface((self.virtual_width, self.virtual_height))
        
        self.display_width = self.virtual_width
        self.display_height = self.virtual_height
        self.display_surface = pygame.display.set_mode((self.display_width, self.display_height), pygame.DOUBLEBUF)

        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.scaled_width = self.virtual_width
        self.scaled_height = self.virtual_height

    def set_aspect_ratio_preset(self, index: int):
        """Sets display dimensions and computes letterboxing."""
        if 0 <= index < len(ASPECT_RATIO_PRESETS):
            self.display_width = ASPECT_RATIO_PRESETS[index][1]
            self.display_height = ASPECT_RATIO_PRESETS[index][2]
            scale_x = self.display_width / self.virtual_width
            scale_y = self.display_height / self.virtual_height
            self.scale = min(scale_x, scale_y)
            self.scaled_width = int(self.virtual_width * self.scale)
            self.scaled_height = int(self.virtual_height * self.scale)
            self.offset_x = (self.display_width - self.scaled_width) // 2
            self.offset_y = (self.display_height - self.scaled_height) // 2

    def toggle_fullscreen(self):
        """Fullscreen toggle compatibility."""
        pass

    def display_to_virtual(self, pos: tuple) -> tuple:
        """Transforms window mouse coordinate to Virtual Canvas space."""
        dx, dy = pos
        if self.scale == 1.0 and self.offset_x == 0 and self.offset_y == 0:
            return (int(dx), int(dy))
        vx = (dx - self.offset_x) / self.scale
        vy = (dy - self.offset_y) / self.scale
        return (int(max(0, min(self.virtual_width, vx))), int(max(0, min(self.virtual_height, vy))))

    def render_to_display(self):
        """Draws the virtual canvas onto the display surface with letterboxing."""
        if self.display_width == self.virtual_width and self.display_height == self.virtual_height:
            self.display_surface.blit(self.virtual_surface, (0, 0))
        else:
            self.display_surface.fill((10, 11, 16))
            scaled = pygame.transform.smoothscale(self.virtual_surface, (self.scaled_width, self.scaled_height))
            self.display_surface.blit(scaled, (self.offset_x, self.offset_y))
        pygame.display.flip()
